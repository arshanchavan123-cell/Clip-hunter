package com.aiclip.hunter.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import java.io.File
import kotlin.math.min

/**
 * Foreground service that keeps the screen recording alive while the person watches in another app.
 * Android shows its own "recording" indicator, and this service adds a notification with Pause and Stop.
 */
class ScreenCaptureService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var recorder: ScreenRecorder? = null
    private var outFile: File? = null
    private var sessionId = 0L
    private var startWall = 0L
    private var pausedWall = 0L
    private var pauseAt = 0L
    private var stopping = false

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            main.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            ACTION_PAUSE -> pauseCapture()
            ACTION_RESUME -> resumeCapture()
            ACTION_STOP -> stopCapture("Capture finished.")
            else -> if (recorder == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacks(ticker)
        super.onDestroy()
    }

    // ------------------------------------------------------------ start

    private fun startCapture(intent: Intent) {
        if (recorder != null) return
        ensureChannel()
        try {
            val n = notification("Starting screen capture…", paused = false)
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            fail("Android didn't allow the capture service to start (${e.message}).")
            return
        }

        val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        val path = intent.getStringExtra(EXTRA_OUT)
        val wantAudio = intent.getBooleanExtra(EXTRA_AUDIO, false)
        if (code != Activity.RESULT_OK || data == null || path == null) {
            fail("Screen-capture permission was not granted.")
            return
        }

        try {
            val file = File(path)
            file.parentFile?.mkdirs()
            outFile = file

            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data)
                ?: throw IllegalStateException("Android didn't start a screen-capture session")
            projection = proj
            val cb = object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopCapture("Screen capture was stopped from the system or the status bar.") }
                }
            }
            projectionCallback = cb
            proj.registerCallback(cb, main) // must be registered before the display is created (Android 14+)

            val dm = resources.displayMetrics
            val scale = min(1f, 720f / min(dm.widthPixels, dm.heightPixels))
            val w = ((dm.widthPixels * scale).toInt() / 16 * 16).coerceAtLeast(160)
            val h = ((dm.heightPixels * scale).toInt() / 16 * 16).coerceAtLeast(160)

            val rec = ScreenRecorder(
                projection = proj,
                outFile = file,
                width = w,
                height = h,
                dpi = dm.densityDpi,
                wantAudio = wantAudio,
                onAudio = { mode, note -> CaptureHub.update { it.copy(audio = mode, audioNote = note) } },
                onLevel = { db -> CaptureHub.update { it.copy(levelDb = db) } },
                onError = { msg -> main.post { stopCapture(msg) } },
            )
            rec.start()
            recorder = rec

            sessionId = System.currentTimeMillis()
            startWall = SystemClock.elapsedRealtime()
            pausedWall = 0L
            pauseAt = 0L
            CaptureHub.update {
                CaptureState(
                    sessionId = sessionId,
                    phase = CapturePhase.Recording,
                    audio = if (wantAudio) AudioMode.Unknown else AudioMode.Unavailable,
                    audioNote = if (wantAudio) null else "Audio permission wasn't granted, so only video is recorded.",
                )
            }
            notify(notification("Recording the screen", paused = false))
            main.postDelayed(ticker, 1000)
        } catch (e: Exception) {
            runCatching { recorder?.stop() }
            runCatching { projection?.stop() }
            recorder = null
            fail("Screen capture couldn't start: ${e.message ?: "unknown error"}.")
        }
    }

    // ------------------------------------------------------------ controls

    private fun pauseCapture() {
        val rec = recorder ?: return
        if (pauseAt != 0L) return
        rec.pause()
        pauseAt = SystemClock.elapsedRealtime()
        CaptureHub.update { it.copy(phase = CapturePhase.Paused) }
        notify(notification("Paused", paused = true))
    }

    private fun resumeCapture() {
        val rec = recorder ?: return
        if (pauseAt == 0L) return
        pausedWall += SystemClock.elapsedRealtime() - pauseAt
        pauseAt = 0L
        rec.resume()
        CaptureHub.update { it.copy(phase = CapturePhase.Recording) }
        notify(notification("Recording the screen", paused = false))
    }

    private fun stopCapture(reason: String) {
        if (stopping) return
        if (recorder == null) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        stopping = true
        main.removeCallbacks(ticker)
        CaptureHub.update { it.copy(phase = CapturePhase.Stopping, message = reason) }
        val rec = recorder
        val proj = projection
        val file = outFile
        projectionCallback?.let { cb -> runCatching { proj?.unregisterCallback(cb) } }
        Thread {
            var ok = false
            try {
                ok = rec?.stop() ?: false
            } catch (e: Exception) {
                ok = false
            }
            runCatching { proj?.stop() }
            main.post {
                val valid = ok && file != null && file.exists() && file.length() > 0
                if (!valid) file?.delete()
                CaptureHub.update {
                    it.copy(
                        phase = if (valid) CapturePhase.Finished else CapturePhase.Failed,
                        file = if (valid) file else null,
                        message = if (valid) reason else "Nothing was captured. Make sure the video was playing on screen.",
                    )
                }
                recorder = null
                projection = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.start()
    }

    private fun fail(message: String) {
        CaptureHub.update { CaptureState(sessionId = System.currentTimeMillis(), phase = CapturePhase.Failed, message = message) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------ housekeeping

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val pausedNow = if (pauseAt != 0L) now - pauseAt else 0L
        val elapsed = now - startWall - pausedWall - pausedNow
        val size = outFile?.length() ?: 0L
        CaptureHub.update { it.copy(elapsedMs = elapsed, bytes = size) }
        val free = runCatching { StatFs(filesDir.path).availableBytes }.getOrDefault(Long.MAX_VALUE)
        when {
            free < MIN_FREE_BYTES -> stopCapture("Stopped because the phone is almost out of storage. Your recording so far is kept.")
            size > MAX_BYTES -> stopCapture("Stopped because the recording reached the 2 GB limit. Your recording so far is kept.")
        }
    }

    private fun ensureChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Screen capture", NotificationManager.IMPORTANCE_LOW),
            )
        }
    }

    private fun notify(n: Notification) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, n)
    }

    private fun action(code: Int, act: String): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, ScreenCaptureService::class.java).setAction(act),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun notification(text: String, paused: Boolean): Notification {
        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("AI Clip Hunter")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
        if (paused) b.addAction(0, "Resume", action(1, ACTION_RESUME)) else b.addAction(0, "Pause", action(2, ACTION_PAUSE))
        b.addAction(0, "Stop", action(3, ACTION_STOP))
        return b.build()
    }

    companion object {
        const val ACTION_START = "com.aiclip.hunter.capture.START"
        const val ACTION_PAUSE = "com.aiclip.hunter.capture.PAUSE"
        const val ACTION_RESUME = "com.aiclip.hunter.capture.RESUME"
        const val ACTION_STOP = "com.aiclip.hunter.capture.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_OUT = "out"
        const val EXTRA_AUDIO = "audio"
        private const val CHANNEL_ID = "capture"
        private const val NOTIF_ID = 4711
        private const val MIN_FREE_BYTES = 200L * 1024 * 1024
        private const val MAX_BYTES = 2L * 1024 * 1024 * 1024
    }
}
