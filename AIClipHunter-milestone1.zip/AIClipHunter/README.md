# AI Clip Hunter

Android app that will find the interesting moments in videos and live streams and turn them into short clips.
**This is Milestone 1 of 7: project, branding, navigation and all screens.** The analysis engine is not built yet.

- Package: `com.aiclip.hunter` | Kotlin + Jetpack Compose (Material 3) | MVVM | min Android 10 (API 29)

## Build

1. Install **Android Studio** (a version that supports AGP 9.3) with **JDK 17+** and the **Android SDK 36** platform.
2. Open this folder (`AIClipHunter/`). Android Studio reads `gradle/wrapper/gradle-wrapper.properties` and downloads Gradle 9.5.0.
3. Let Gradle sync, pick a device or emulator (Android 10+), and press Run.

Command line: this archive has no `gradlew` / `gradle-wrapper.jar`. With Gradle installed, run `gradle wrapper --gradle-version 9.5.0` once, then `./gradlew assembleDebug`.

> **Not yet compiled.** The project was written and checked statically (XML validity, bracket balance, imports) but could not be built in the environment that created it. Expect to fix a few small compile errors on first sync, and please report them so they can be fixed before Milestone 2.

## Versions (checked against developer.android.com release notes)

| Item | Version |
|---|---|
| Android Gradle Plugin | 9.3.0 (needs Gradle 9.5.0, JDK 17+). AGP 9 compiles Kotlin itself, so there is no `kotlin-android` plugin |
| Kotlin / Compose compiler plugin | 2.3.10 |
| Compose BOM | 2026.08.00 |
| Navigation Compose, Lifecycle, Activity Compose, DataStore, Core | 2.9.5, 2.9.4, 1.11.0, 1.1.7, 1.17.0 (not re-verified online, so bump them if Studio suggests newer ones) |

## What works in this version

| Area | Status |
|---|---|
| Splash with animated logo, adaptive launcher icon (incl. themed icon) | Working |
| Bottom navigation: Home, Discover, Library, Settings | Working |
| Import a local video (system file picker, no storage permission) | Working |
| Real metadata: name, size, duration, resolution, frame rate, audio track, thumbnail | Working |
| Clip editor: format (9:16 / 16:9 / 1:1) preview, start/end range slider, subtitle toggle | Working as UI. Shows one frame, not playback |
| Settings: clip length, format, subtitles, quality, scoring weights (saved with DataStore), storage info, clear cache | Working |
| Link analysis | Validates the link, then says it isn't supported yet. Nothing is downloaded |
| Audio, scene and speech analysis, highlight scoring | Not built (Milestones 3-4). Screens show "not started" and empty states |
| Clip generation, 9:16 smart crop, subtitles, export | Not built (Milestone 5). Export button is disabled |
| Library (list, rename, share, delete) | UI and actions exist but the list is empty until export exists |
| Live stream analysis | Not built (Milestone 7). Connect validates the URL and explains the limitation |

No screen shows invented results. Highlight, clip and project lists are empty until real engines fill them.

## Structure

```
app/src/main/java/com/aiclip/hunter/
  MainActivity.kt, AppViewModel.kt
  navigation/      routes + bottom bar
  ui/              theme, components, splash, home, analyzer, highlights, editor, live, library, discover, settings
  domain/models/   Highlight, Clip, SourceVideo, settings models
  data/settings/   DataStore repository
  engine/video/    VideoMetadataExtractor (real)
  engine/{audio,speech,vision,chat,scoring}/   empty, filled from Milestone 3
assets/logo/       ai_clip_hunter_logo.svg, .png (1024px), make_logo.py (regenerates both)
models/            future on-device model files
```

Planned modules (`clipping/`, `sources/`, `workers/`, Room database) are added when their milestone starts.

## Permissions

None in Milestone 1. Later: notifications for long exports, internet for online sources. The app never asks for the microphone.

## Next: Milestone 2

Media3 playback in the editor, persisted projects with Room, and a WorkManager pipeline skeleton with progress and cancellation.
