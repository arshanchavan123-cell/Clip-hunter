package com.aiclip.hunter.ui.editor

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.domain.models.AspectOption
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.EmptyState
import com.aiclip.hunter.ui.components.GradientButton
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.SectionTitle
import com.aiclip.hunter.ui.components.VideoThumbnail
import com.aiclip.hunter.utils.formatTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: AppViewModel, onBack: () -> Unit, onImport: () -> Unit) {
    val state by vm.importState.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val video = state.video

    var aspect by rememberSaveable { mutableStateOf(settings.defaultAspect) }
    var subtitles by rememberSaveable { mutableStateOf(settings.subtitlesDefault) }
    val durationSec = ((video?.durationMs ?: 1000L) / 1000f).coerceAtLeast(1f)
    var range by remember(video) { mutableStateOf(0f..minOf(durationSec, settings.clipDurationSec.toFloat())) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ScreenHeader("Clip editor", onBack = onBack) }

        if (video == null) {
            item {
                EmptyState(
                    Icons.Rounded.VideoFile, "No video loaded",
                    "Import a video to choose a clip range and a format.",
                    actionLabel = "Import video", onAction = onImport,
                )
            }
        } else {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    val shape = RoundedCornerShape(16.dp)
                    VideoThumbnail(
                        video.thumbnail,
                        Modifier
                            .fillMaxWidth(if (aspect == AspectOption.Vertical) 0.5f else 1f)
                            .aspectRatio(aspect.ratio)
                            .clip(shape)
                            .border(1.dp, MaterialTheme.colorScheme.outline, shape),
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Centre-crop preview of one frame. Playback arrives in Milestone 2 and smart crop in Milestone 5.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            item {
                AppCard {
                    SectionTitle("Timeline")
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Start ${formatTime((range.start * 1000).toLong())}", style = MaterialTheme.typography.bodyMedium)
                        Text("End ${formatTime((range.endInclusive * 1000).toLong())}", style = MaterialTheme.typography.bodyMedium)
                    }
                    RangeSlider(value = range, onValueChange = { range = it }, valueRange = 0f..durationSec)
                    Text(
                        "Clip length ${formatTime(((range.endInclusive - range.start) * 1000).toLong())} of ${formatTime(video.durationMs)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            item {
                AppCard {
                    SectionTitle("Format")
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AspectOption.entries.forEach { option ->
                            FilterChip(selected = aspect == option, onClick = { aspect = option }, label = { Text(option.label) })
                        }
                    }
                }
            }
            item {
                AppCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            SectionTitle("Subtitles")
                            Text(
                                "Burned into the clip at export (Milestone 5).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(checked = subtitles, onCheckedChange = { subtitles = it })
                    }
                }
            }
            item {
                Column {
                    GradientButton("Export clip", onClick = {}, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Upload, enabled = false)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Export is unavailable until clip generation ships in Milestone 5.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
