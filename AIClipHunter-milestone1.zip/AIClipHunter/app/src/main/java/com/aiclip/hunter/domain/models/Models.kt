package com.aiclip.hunter.domain.models

import android.graphics.Bitmap
import android.net.Uri
import kotlin.math.roundToInt

/** A video the user imported. Everything here was read from the real file, nothing is estimated. */
data class SourceVideo(
    val uri: Uri,
    val displayName: String,
    val sizeBytes: Long?,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val frameRate: Float?,
    val hasAudio: Boolean,
    val thumbnail: Bitmap?,
)

enum class HighlightCategory(val label: String) {
    Chat("Chat spike"),
    Audio("Audio peak"),
    Speech("Speech"),
    Visual("Scene change"),
    Combined("Multiple signals"),
}

/** A candidate moment produced by the analysis engine (Milestones 3-4). Score is 0-100. */
data class Highlight(
    val id: String,
    val startMs: Long,
    val endMs: Long,
    val score: Int,
    val category: HighlightCategory,
)

data class Clip(
    val id: String,
    val title: String,
    val uri: String,
    val durationMs: Long,
    val createdAtMs: Long,
)

enum class AspectOption(val label: String, val ratio: Float) {
    Vertical("9:16", 9f / 16f),
    Landscape("16:9", 16f / 9f),
    Square("1:1", 1f),
}

enum class ExportQuality(val label: String) {
    P720("720p"),
    P1080("1080p"),
}

/** Initial heuristic weights from the project brief. Missing signals are dropped and the rest renormalised. */
data class ScoreWeights(
    val chat: Int = 30,
    val audio: Int = 25,
    val speech: Int = 20,
    val visual: Int = 15,
    val retention: Int = 10,
) {
    val total: Int get() = chat + audio + speech + visual + retention
    fun percent(value: Int): Int = if (total == 0) 0 else (value * 100f / total).roundToInt()
}

data class AppSettings(
    val clipDurationSec: Int = 30,
    val quality: ExportQuality = ExportQuality.P1080,
    val defaultAspect: AspectOption = AspectOption.Vertical,
    val subtitlesDefault: Boolean = true,
    val weights: ScoreWeights = ScoreWeights(),
)
