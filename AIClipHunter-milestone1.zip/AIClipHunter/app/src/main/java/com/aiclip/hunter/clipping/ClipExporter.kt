package com.aiclip.hunter.clipping

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.aiclip.hunter.domain.models.AspectOption
import com.aiclip.hunter.domain.models.ExportQuality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

/** Cuts [startMs, endMs] from the source and re-encodes it as MP4 in the chosen shape (centre crop). */
@OptIn(UnstableApi::class)
class ClipExporter(private val context: Context) {

    suspend fun export(
        source: Uri,
        startMs: Long,
        endMs: Long,
        aspect: AspectOption,
        quality: ExportQuality,
        outFile: File,
        onProgress: (Float) -> Unit,
    ): Result<Unit> = withContext(Dispatchers.Main) {
        val high = quality == ExportQuality.P1080
        val (w, h) = when (aspect) {
            AspectOption.Vertical -> if (high) 1080 to 1920 else 720 to 1280
            AspectOption.Landscape -> if (high) 1920 to 1080 else 1280 to 720
            AspectOption.Square -> if (high) 1080 to 1080 else 720 to 720
        }
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()
        val mediaItem = MediaItem.Builder().setUri(source).setClippingConfiguration(clipping).build()
        val videoEffects = listOf<Effect>(
            Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP),
        )
        val edited = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        var transformer: Transformer? = null
        val holder = ProgressHolder()

        coroutineScope {
            val poller = launch {
                while (true) {
                    delay(300)
                    val t = transformer
                    if (t != null && t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                        onProgress(holder.progress / 100f)
                    }
                }
            }
            try {
                suspendCancellableCoroutine<Result<Unit>> { cont ->
                    val t = Transformer.Builder(context)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                if (cont.isActive) cont.resume(Result.success(Unit))
                            }

                            override fun onError(
                                composition: Composition,
                                exportResult: ExportResult,
                                exportException: ExportException,
                            ) {
                                if (cont.isActive) {
                                    cont.resume(Result.failure(IllegalStateException("Export failed (${exportException.errorCodeName})")))
                                }
                            }
                        })
                        .build()
                    transformer = t
                    cont.invokeOnCancellation { runCatching { t.cancel() } }
                    t.start(edited, outFile.absolutePath)
                }
            } finally {
                poller.cancel()
            }
        }
    }
}
