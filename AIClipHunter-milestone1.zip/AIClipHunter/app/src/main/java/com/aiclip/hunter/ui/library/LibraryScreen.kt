package com.aiclip.hunter.ui.library

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.domain.models.Clip
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.EmptyState
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.VideoThumbnail
import com.aiclip.hunter.utils.formatTime
import java.text.DateFormat
import java.util.Date

@Composable
fun LibraryScreen(vm: AppViewModel, onImport: () -> Unit) {
    val clips by vm.clips.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var renaming by remember { mutableStateOf<Clip?>(null) }
    var deleting by remember { mutableStateOf<Clip?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenHeader("Library", subtitle = "${clips.size} clips") }
        if (clips.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.VideoLibrary, "No clips yet",
                    "Clips you export are saved on your phone and listed here. Exporting arrives in Milestone 5.",
                    actionLabel = "Import video", onAction = onImport,
                )
            }
        } else {
            items(clips, key = { it.id }) { clip ->
                ClipCard(
                    clip,
                    onPreview = { openClip(context, clip) },
                    onRename = { renaming = clip },
                    onShare = { shareClip(context, clip) },
                    onDelete = { deleting = clip },
                )
            }
        }
    }

    renaming?.let { clip ->
        var name by remember(clip.id) { mutableStateOf(clip.title) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            title = { Text("Rename clip") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.renameClip(clip.id, name); renaming = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } },
        )
    }
    deleting?.let { clip ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            title = { Text("Delete clip?") },
            text = { Text("“${clip.title}” will be removed from your phone.") },
            confirmButton = { TextButton(onClick = { vm.deleteClip(clip); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ClipCard(clip: Clip, onPreview: () -> Unit, onRename: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit) {
    var menuOpen by remember { mutableStateOf(false) }
    AppCard(onClick = onPreview) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            VideoThumbnail(null, Modifier.size(width = 96.dp, height = 54.dp).clip(RoundedCornerShape(12.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(clip.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(clip.createdAtMs))
                Text(
                    "${formatTime(clip.durationMs)} • $date",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Rounded.MoreVert, contentDescription = "Clip actions") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Preview") }, onClick = { menuOpen = false; onPreview() })
                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menuOpen = false; onRename() })
                    DropdownMenuItem(text = { Text("Share") }, onClick = { menuOpen = false; onShare() })
                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menuOpen = false; onDelete() })
                }
            }
        }
    }
}

private fun openClip(context: Context, clip: Clip) {
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(clip.uri), "video/mp4")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { context.startActivity(intent) }
}

private fun shareClip(context: Context, clip: Clip) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, Uri.parse(clip.uri))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(Intent.createChooser(send, "Share clip")) }
}
