package com.aiclip.hunter

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aiclip.hunter.data.settings.SettingsRepository
import com.aiclip.hunter.domain.models.AppSettings
import com.aiclip.hunter.domain.models.Clip
import com.aiclip.hunter.domain.models.Highlight
import com.aiclip.hunter.domain.models.SourceVideo
import com.aiclip.hunter.engine.video.VideoMetadataExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Single app-level state holder for Milestone 1. Later milestones move project data into Room. */
class AppViewModel(application: Application) : AndroidViewModel(application) {

    data class ImportState(
        val loading: Boolean = false,
        val video: SourceVideo? = null,
        val error: String? = null,
    )

    private val extractor = VideoMetadataExtractor(application)
    private val settingsRepository = SettingsRepository(application)

    private val _importState = MutableStateFlow(ImportState())
    val importState: StateFlow<ImportState> = _importState.asStateFlow()

    // Both stay empty until the analysis and export engines exist (Milestones 3-5). Nothing is faked.
    private val _highlights = MutableStateFlow<List<Highlight>>(emptyList())
    val highlights: StateFlow<List<Highlight>> = _highlights.asStateFlow()

    private val _clips = MutableStateFlow<List<Clip>>(emptyList())
    val clips: StateFlow<List<Clip>> = _clips.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private var importJob: Job? = null

    fun importVideo(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        importJob?.cancel()
        _importState.value = ImportState(loading = true)
        importJob = viewModelScope.launch {
            extractor.extract(uri).fold(
                onSuccess = { _importState.value = ImportState(video = it) },
                onFailure = { _importState.value = ImportState(error = it.message ?: "This file couldn't be read.") },
            )
        }
    }

    fun clearVideo() {
        importJob?.cancel()
        _importState.value = ImportState()
    }

    fun renameClip(id: String, title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        _clips.value = _clips.value.map { if (it.id == id) it.copy(title = clean) else it }
    }

    fun deleteClip(clip: Clip) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                runCatching { getApplication<Application>().contentResolver.delete(Uri.parse(clip.uri), null, null) }
            }
            _clips.value = _clips.value.filterNot { it.id == clip.id }
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepository.save(transform(settings.value)) }
    }
}
