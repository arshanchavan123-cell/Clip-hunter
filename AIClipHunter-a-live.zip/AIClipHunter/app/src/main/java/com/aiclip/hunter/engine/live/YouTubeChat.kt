package com.aiclip.hunter.engine.live

import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** Reads the public live chat of a YouTube stream (no account needed). Only counts and hype words are used. */
class YouTubeChat(private val videoId: String) {

    private val chatPage get() = "https://www.youtube.com/live_chat?is_popout=1&v=$videoId"

    /** Runs until cancelled. Throws if the chat can't be read any more. */
    suspend fun run(onMessages: (List<ChatMsg>) -> Unit) {
        val page = Http.getText(chatPage)
        val key = Regex("\"INNERTUBE_API_KEY\":\"([^\"]+)\"").find(page)?.groupValues?.get(1)
            ?: "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        val version = Regex("\"INNERTUBE_CONTEXT_CLIENT_VERSION\":\"([^\"]+)\"").find(page)?.groupValues?.get(1)
            ?: "2.20250101.00.00"
        var cont = firstContinuation(page) ?: throw IllegalStateException("Chat page has no live chat (chat may be off).")
        val url = "https://www.youtube.com/youtubei/v1/live_chat/get_live_chat?key=$key&prettyPrint=false"
        val headers = mapOf("Origin" to "https://www.youtube.com", "Referer" to chatPage)

        var failures = 0
        while (true) {
            val body = JSONObject()
                .put("context", JSONObject().put("client", JSONObject().put("clientName", "WEB").put("clientVersion", version).put("hl", "en").put("gl", "US")))
                .put("continuation", cont)
                .toString()
            val resp = try {
                Http.postJson(url, body, Http.DESKTOP_UA, headers)
            } catch (e: Exception) {
                failures++
                if (failures >= 5) throw e
                delay(3_000)
                continue
            }
            failures = 0
            val lc = JSONObject(resp).optJSONObject("continuationContents")?.optJSONObject("liveChatContinuation")
                ?: throw IllegalStateException("The chat has closed.")
            val msgs = parse(lc.optJSONArray("actions"))
            if (msgs.isNotEmpty()) onMessages(msgs)
            val next = nextContinuation(lc.optJSONArray("continuations")) ?: throw IllegalStateException("The chat has ended.")
            cont = next.first
            delay(next.second.coerceIn(1_000L, 5_000L))
        }
    }

    private fun nextContinuation(arr: JSONArray?): Pair<String, Long>? {
        val first = arr?.optJSONObject(0) ?: return null
        for (k in listOf("invalidationContinuationData", "timedContinuationData", "reloadContinuationData")) {
            val o = first.optJSONObject(k) ?: continue
            val c = o.optString("continuation")
            if (c.isNotBlank()) return c to o.optLong("timeoutMs", 2_000L)
        }
        return null
    }

    private fun firstContinuation(page: String): String? {
        val m = Regex("""(?:window\["ytInitialData"\]|var ytInitialData)\s*=\s*(\{.*?\});\s*</script>""", RegexOption.DOT_MATCHES_ALL).find(page)
        if (m != null) {
            runCatching {
                val arr = JSONObject(m.groupValues[1]).optJSONObject("contents")?.optJSONObject("liveChatRenderer")?.optJSONArray("continuations")
                nextContinuation(arr)?.first
            }.getOrNull()?.let { return it }
        }
        val idx = page.indexOf("liveChatRenderer")
        if (idx >= 0) Regex("\"continuation\":\"([^\"]+)\"").find(page, idx)?.let { return it.groupValues[1] }
        return null
    }

    private fun parse(actions: JSONArray?): List<ChatMsg> {
        val out = ArrayList<ChatMsg>()
        if (actions == null) return out
        for (i in 0 until actions.length()) {
            val item = actions.optJSONObject(i)?.optJSONObject("addChatItemAction")?.optJSONObject("item") ?: continue
            val key = item.keys().asSequence().firstOrNull() ?: continue
            if (!key.contains("Message") && !key.contains("Sticker") && !key.contains("Membership")) continue
            val r = item.optJSONObject(key) ?: continue
            val paid = key.contains("Paid")
            val runs = r.optJSONObject("message")?.optJSONArray("runs")
            val text = StringBuilder()
            var emoji = 0
            if (runs != null) {
                for (j in 0 until runs.length()) {
                    val run = runs.optJSONObject(j) ?: continue
                    if (run.has("text")) text.append(run.optString("text")) else if (run.has("emoji")) emoji++
                }
            }
            if (text.isBlank() && emoji == 0 && !paid) continue
            out.add(ChatMsg(text.toString().trim(), paid, emoji))
        }
        return out
    }
}
