package com.aiclip.hunter.engine.live

import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class Trigger(val label: String, val score: Float)

/**
 * Watches chat speed, hype words, Super Chats and how loud the streamer is.
 * It learns what is normal for this stream and fires when something clearly jumps above it.
 */
class LiveDetector {

    private class Ev(val t: Long, val hype: Boolean, val paid: Boolean)

    private val lock = Any()
    private val events = ArrayDeque<Ev>()
    private val startMs = System.currentTimeMillis()
    private var base = 1.0
    private var loudBase = -45f
    private var loud = -90f
    private var loudSeen = false
    private var lastMoment = 0L

    @Volatile var chatActive = false
    @Volatile var perMin = 0
        private set
    @Volatile var hype = 0f
        private set

    private val hypeRe = Regex(
        """(?i)\b(w+|pog+(gers)?|lul+|kekw+|omg+|wtf+|gg+|clip( it)?|insane|crazy|let'?s? ?go+|hype|ez|rip|no ?way|holy|bruh|wah+|op|gajab|pagal|zabardast|kya baat)\b""",
    )

    private fun isHype(m: ChatMsg): Boolean {
        if (m.emoji >= 2 || m.paid) return true
        val t = m.text
        if (t.length >= 4 && t.any { it.isLetter() } && t == t.uppercase()) return true
        return hypeRe.containsMatchIn(t)
    }

    fun onChat(msgs: List<ChatMsg>, now: Long) = synchronized(lock) {
        for (m in msgs) events.addLast(Ev(now, isHype(m), m.paid))
    }

    fun onLoud(db: Float) = synchronized(lock) {
        loud = db
        if (!loudSeen) {
            loudBase = db
            loudSeen = true
        } else if (db - loudBase < 6f) {
            loudBase += (db - loudBase) * 0.05f
        }
    }

    /** Call about once a second. Returns a Trigger when a moment is worth clipping. */
    fun tick(now: Long): Trigger? = synchronized(lock) {
        while (events.isNotEmpty() && now - events.first().t > 60_000) events.removeFirst()
        perMin = events.size
        var n = 0
        var hypeN = 0
        var paidN = 0
        for (e in events) {
            if (now - e.t <= 10_000) {
                n++
                if (e.hype) hypeN++
                if (e.paid) paidN++
            }
        }
        // What is normal for this chat: follows slowly, and hardly moves while chat is spiking.
        base += (n - base) * (if (n <= base * 1.5 + 2) 0.03 else 0.003)
        base = max(base, 0.5)
        val z = (n - base) / (sqrt(base) + 1.0)
        val loudDelta = if (loudSeen) loud - loudBase else 0f

        hype = min(1f, max(max((z / 6.0).toFloat(), if (n >= 4) hypeN.toFloat() / n else 0f), max(0f, loudDelta / 15f))).coerceAtLeast(0f)

        if (now - startMs < 30_000 || now - lastMoment < 40_000) return@synchronized null

        val reasons = ArrayList<String>()
        if (z >= 3.0 && n >= 6) reasons.add(String.format(Locale.US, "Chat spike %.1fx", n / max(base, 1.0)))
        if (n >= 8 && hypeN.toDouble() / n >= 0.4) reasons.add("Hype chat")
        if (paidN >= 3) reasons.add("Super Chats")
        if (loudDelta >= 9f && loud > -35f && (reasons.isNotEmpty() || z >= 1.5 || !chatActive)) {
            reasons.add("Loud moment (+${loudDelta.toInt()} dB)")
        }
        if (reasons.isEmpty()) return@synchronized null
        lastMoment = now
        Trigger(reasons.joinToString(" + "), hype.coerceIn(0.2f, 1f))
    }
}
