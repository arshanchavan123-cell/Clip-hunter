package com.aiclip.hunter.engine.live

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

internal object Http {
    const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun open(url: String, ua: String, extra: Map<String, String>, timeoutMs: Int): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs
        c.readTimeout = timeoutMs
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        if (url.contains("youtube.com")) c.setRequestProperty("Cookie", "CONSENT=YES+cb; SOCS=CAI")
        for ((k, v) in extra) c.setRequestProperty(k, v)
        return c
    }

    fun get(url: String, ua: String = DESKTOP_UA, extra: Map<String, String> = emptyMap(), timeoutMs: Int = 15_000): ByteArray {
        val c = open(url, ua, extra, timeoutMs)
        try {
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    fun getText(url: String, ua: String = DESKTOP_UA, extra: Map<String, String> = emptyMap()): String =
        String(get(url, ua, extra), Charsets.UTF_8)

    fun postJson(url: String, body: String, ua: String = DESKTOP_UA, extra: Map<String, String> = emptyMap(), timeoutMs: Int = 15_000): String {
        val c = open(url, ua, extra, timeoutMs)
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }
        } finally {
            c.disconnect()
        }
    }

    /** Resolves a playlist entry against the playlist address. */
    fun resolve(base: String, ref: String): String =
        if (ref.startsWith("http://") || ref.startsWith("https://")) ref else URL(URL(base), ref).toString()
}
