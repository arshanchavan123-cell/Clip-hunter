package com.aiclip.hunter.engine.live

import org.json.JSONObject

/** Turns what the person pasted into a stream (HLS) address the recorder can read. */
object LiveResolver {

    class Resolved(val hlsUrl: String, val title: String?, val videoId: String?, val ua: String)

    private class Client(
        val name: String,
        val version: String,
        val ua: String,
        val id: String,
        val extra: JSONObject.() -> Unit,
    )

    private val clients = listOf(
        Client(
            "IOS", "20.10.4",
            "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)", "5",
        ) {
            put("deviceMake", "Apple")
            put("deviceModel", "iPhone16,2")
            put("osName", "iPhone")
            put("osVersion", "18.3.2.22D82")
        },
        Client(
            "ANDROID_VR", "1.62.27",
            "com.google.android.apps.youtube.vr.oculus/1.62.27 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip", "28",
        ) {
            put("deviceMake", "Oculus")
            put("deviceModel", "Quest 3")
            put("osName", "Android")
            put("osVersion", "12L")
            put("androidSdkVersion", 32)
        },
    )

    private val idRe = Regex("""(?:[?&]v=|/live/|youtu\.be/|/embed/|/shorts/)([A-Za-z0-9_-]{11})""")

    fun youtubeId(text: String): String? = idRe.find(text)?.groupValues?.get(1)

    fun resolve(raw: String): Resolved {
        val text = raw.trim()
        if (text.contains(".m3u8")) return Resolved(text, null, null, Http.DESKTOP_UA)
        val id = youtubeId(text)
            ?: error("Only YouTube Live links and direct .m3u8 stream links work right now.")
        var reason = "no stream address was returned"
        for (c in clients) {
            try {
                val client = JSONObject().put("clientName", c.name).put("clientVersion", c.version)
                    .put("hl", "en").put("gl", "US")
                c.extra(client)
                val body = JSONObject()
                    .put("context", JSONObject().put("client", client))
                    .put("videoId", id)
                    .put("contentCheckOk", true)
                    .put("racyCheckOk", true)
                    .toString()
                val resp = Http.postJson(
                    "https://www.youtube.com/youtubei/v1/player?prettyPrint=false", body, c.ua,
                    mapOf("X-YouTube-Client-Name" to c.id, "X-YouTube-Client-Version" to c.version),
                )
                val json = JSONObject(resp)
                val hls = json.optJSONObject("streamingData")?.optString("hlsManifestUrl").orEmpty()
                if (hls.isNotBlank()) {
                    val title = json.optJSONObject("videoDetails")?.optString("title")?.takeIf { it.isNotBlank() }
                    return Resolved(hls, title, id, c.ua)
                }
                val ps = json.optJSONObject("playabilityStatus")
                val why = ps?.optString("reason").orEmpty().ifBlank { ps?.optString("status").orEmpty() }
                if (why.isNotBlank()) reason = why
            } catch (e: Exception) {
                reason = e.message ?: "network error"
            }
        }
        error("YouTube did not give a stream address ($reason). The video may not be live, or YouTube blocked this app.")
    }
}
