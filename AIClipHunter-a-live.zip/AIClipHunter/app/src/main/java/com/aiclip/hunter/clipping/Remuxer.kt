package com.aiclip.hunter.clipping

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

/** Rewraps joined stream pieces into a normal MP4 file (with a proper length) without re-encoding where possible. */
@OptIn(UnstableApi::class)
class Remuxer(private val context: Context) {

    suspend fun toMp4(input: File, output: File): Result<Unit> = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Result<Unit>> { cont ->
            val t = Transformer.Builder(context)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Result.success(Unit))
                    }

                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        if (cont.isActive) {
                            cont.resume(Result.failure(IllegalStateException("Clip conversion failed (${exportException.errorCodeName})")))
                        }
                    }
                })
                .build()
            cont.invokeOnCancellation { runCatching { t.cancel() } }
            t.start(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input))).build(), output.absolutePath)
        }
    }
}
