package com.aiclip.hunter.engine.live

import java.io.File
import kotlin.math.max

/** Follows an HLS live playlist, keeps the last few minutes on disk and cuts clips out of them. */
class HlsRecorder(val dir: File, private val ua: String) {

    private val lock = Any()
    private val segs = ArrayList<Seg>()
    private var mediaUrl = ""
    var initFile: File? = null
        private set
    private var nextSeq = -1L
    private var clock = 0.0

    @Volatile var ended = false
        private set
    @Volatile var pollDelayMs = 2000L
        private set
    var quality = "auto"
        private set

    val extension: String get() = if (initFile != null) "mp4" else "ts"
    val endSec: Double get() = synchronized(lock) { segs.lastOrNull()?.endSec ?: 0.0 }
    val bufferedSec: Double get() = synchronized(lock) { if (segs.isEmpty()) 0.0 else segs.last().endSec - segs.first().startSec }

    fun open(url: String) {
        dir.mkdirs()
        val text = Http.getText(url, ua)
        mediaUrl = if (text.contains("#EXT-X-STREAM-INF")) pickVariant(url, text) else url
    }

    private fun pickVariant(base: String, text: String): String {
        class V(val height: Int, val bw: Long, val uri: String)
        val lines = text.lines().map { it.trim() }
        val vs = ArrayList<V>()
        for ((i, l) in lines.withIndex()) {
            if (!l.startsWith("#EXT-X-STREAM-INF")) continue
            val uri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: continue
            val height = Regex("RESOLUTION=\\d+x(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            vs.add(V(height, bw, uri))
        }
        check(vs.isNotEmpty()) { "The stream has no playable quality." }
        val okay = vs.filter { it.height in 1..720 }
        val pick = if (okay.isNotEmpty()) okay.maxWith(compareBy<V>({ it.height }, { it.bw })) else vs.minBy { it.bw }
        quality = if (pick.height > 0) "${pick.height}p" else "auto"
        return Http.resolve(base, pick.uri)
    }

    /** Downloads any new pieces. Returns only the pieces that are new. */
    fun poll(): List<Seg> {
        val text = Http.getText(mediaUrl, ua)
        var mediaSeq = 0L
        var target = 4.0
        var mapUri: String? = null
        var pending = -1.0
        val entries = ArrayList<Triple<Long, Double, String>>()
        for (raw in text.lines()) {
            val l = raw.trim()
            when {
                l.startsWith("#EXT-X-MEDIA-SEQUENCE:") -> mediaSeq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
                l.startsWith("#EXT-X-TARGETDURATION:") -> target = l.substringAfter(':').trim().toDoubleOrNull() ?: 4.0
                l.startsWith("#EXT-X-MAP:") -> mapUri = Regex("URI=\"([^\"]+)\"").find(l)?.groupValues?.get(1)
                l.startsWith("#EXT-X-ENDLIST") -> ended = true
                l.startsWith("#EXTINF:") -> pending = l.substringAfter(':').substringBefore(',').trim().toDoubleOrNull() ?: target
                l.isNotEmpty() && !l.startsWith("#") -> if (pending >= 0) {
                    entries.add(Triple(mediaSeq + entries.size, pending, l))
                    pending = -1.0
                }
            }
        }
        pollDelayMs = (target * 500).toLong().coerceIn(1000L, 3000L)

        if (mapUri != null && initFile == null) {
            val f = File(dir, "init.bin")
            f.writeBytes(Http.get(Http.resolve(mediaUrl, mapUri), ua))
            initFile = f
        }

        val wanted: List<Triple<Long, Double, String>> = if (nextSeq < 0) {
            // First look: start with roughly the last 40 seconds so a clip is possible straight away.
            var sum = 0.0
            val take = ArrayList<Triple<Long, Double, String>>()
            for (e in entries.asReversed()) {
                take.add(0, e)
                sum += e.second
                if (sum >= 40.0) break
            }
            take
        } else {
            entries.filter { it.first >= nextSeq }
        }

        val fresh = ArrayList<Seg>()
        for ((seq, dur, uri) in wanted) {
            val f = File(dir, "s$seq.seg")
            try {
                f.writeBytes(Http.get(Http.resolve(mediaUrl, uri), ua))
            } catch (e: Exception) {
                f.delete()
                if (fresh.isEmpty()) throw e
                break
            }
            val seg = Seg(seq, dur, clock, f)
            clock += dur
            nextSeq = seq + 1
            synchronized(lock) { segs.add(seg) }
            fresh.add(seg)
        }
        trim()
        return fresh
    }

    private fun trim() {
        val old = synchronized(lock) {
            val cutoff = (segs.lastOrNull()?.endSec ?: 0.0) - RETENTION_SEC
            val gone = segs.filter { it.endSec < cutoff }
            segs.removeAll(gone.toSet())
            gone
        }
        old.forEach { it.file.delete() }
    }

    /** Joins the pieces that cover [fromSec, toSec] into one file. False if nothing is left in the buffer. */
    fun cut(fromSec: Double, toSec: Double, out: File): Boolean {
        val pick = synchronized(lock) { segs.filter { it.endSec > max(0.0, fromSec) && it.startSec < toSec } }
        if (pick.isEmpty()) return false
        out.parentFile?.mkdirs()
        out.outputStream().buffered().use { o ->
            initFile?.let { f -> f.inputStream().use { it.copyTo(o) } }
            for (s in pick) if (s.file.exists()) s.file.inputStream().use { it.copyTo(o) }
        }
        return true
    }

    private companion object {
        const val RETENTION_SEC = 240.0
    }
}
