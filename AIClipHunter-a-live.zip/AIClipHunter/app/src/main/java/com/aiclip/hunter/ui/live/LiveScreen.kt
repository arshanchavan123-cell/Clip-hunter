package com.aiclip.hunter.ui.live

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.engine.live.MomentState
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.GradientButton
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.SecondaryButton
import com.aiclip.hunter.ui.components.SectionTitle
import com.aiclip.hunter.ui.components.StatusPill
import com.aiclip.hunter.ui.theme.Brand
import com.aiclip.hunter.utils.formatTime
import com.aiclip.hunter.utils.isWebUrl

@Composable
fun LiveScreen(vm: AppViewModel, onBack: () -> Unit, onOpenEditor: () -> Unit) {
    val state by vm.live.state.collectAsStateWithLifecycle()
    val saved by vm.liveUrl.collectAsStateWithLifecycle()

    var url by rememberSaveable(saved) { mutableStateOf(saved) }
    var allowed by rememberSaveable { mutableStateOf(false) }
    var urlError by rememberSaveable { mutableStateOf<String?>(null) }

    // Recording only works while the app is open, so keep the screen awake during a session.
    val view = LocalView.current
    DisposableEffect(state.running) {
        view.keepScreenOn = state.running
        onDispose { view.keepScreenOn = false }
    }

    val connect = {
        val text = url.trim()
        urlError = when {
            text.isEmpty() -> "Paste the link of the live stream."
            !isWebUrl(text) -> "Enter a full link that starts with http:// or https://."
            !allowed -> "Confirm that you may analyse this stream."
            else -> null
        }
        if (urlError == null) {
            vm.setLiveUrl(text)
            vm.startLive(text)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ScreenHeader("Live analysis", onBack = onBack) }

        item {
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("Stream link")
                    if (state.running) StatusPill("Live", Brand.Success)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Works with YouTube Live links and direct .m3u8 stream links. Keep the app open while it records.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; urlError = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    enabled = !state.running,
                    shape = RoundedCornerShape(16.dp),
                    placeholder = { Text("Live stream link") },
                    leadingIcon = { androidx.compose.material3.Icon(Icons.Rounded.Link, contentDescription = null) },
                    isError = urlError != null,
                    supportingText = urlError?.let { msg -> { Text(msg) } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { if (!state.running) connect() }),
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "This is my stream, or the streamer allows clipping it.",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Switch(checked = allowed, onCheckedChange = { allowed = it; urlError = null }, enabled = !state.running)
                }
                Spacer(Modifier.height(12.dp))
                if (state.running) {
                    SecondaryButton("Stop", onClick = { vm.stopLive() }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Stop)
                } else {
                    GradientButton("Start", onClick = { connect() }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Sensors)
                }
                state.error?.let {
                    Spacer(Modifier.height(10.dp))
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                }
            }
        }

        item {
            AppCard {
                SectionTitle("Status")
                Spacer(Modifier.height(8.dp))
                IndicatorRow("Connection", state.status, if (state.running) Brand.Success else Brand.TextSecondary)
                if (state.title != null) IndicatorRow("Stream", state.title.orEmpty().take(36), Brand.Cyan)
                IndicatorRow("Saved video", formatTime(state.bufferSec * 1000L), if (state.bufferSec > 0) Brand.Cyan else Brand.TextSecondary)
                IndicatorRow(
                    "Chat",
                    if (state.chatStatus == "Live") "Live, ${state.chatPerMin} per min" else state.chatStatus,
                    if (state.chatStatus == "Live") Brand.Success else Brand.TextSecondary,
                )
                IndicatorRow("Sound", state.loudDb?.let { "${it.toInt()} dB" } ?: "No data", Brand.TextSecondary)
                Spacer(Modifier.height(8.dp))
                Text("Hype level", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { state.hype.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = Brand.Violet,
                )
            }
        }

        item {
            AppCard {
                SectionTitle("Moments")
                Spacer(Modifier.height(4.dp))
                if (state.moments.isEmpty()) {
                    Text(
                        if (state.running) "Watching chat and sound. Exciting moments appear here and are cut into clips automatically." else "Moments found during a live stream appear here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        items(state.moments.size) { i ->
            val m = state.moments[i]
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("#${m.id}  ·  ${m.clock}", style = MaterialTheme.typography.titleMedium)
                    when (m.state) {
                        MomentState.Waiting -> StatusPill("Recording the end", Brand.Warning)
                        MomentState.Cutting -> StatusPill("Cutting", Brand.Warning)
                        MomentState.Ready -> StatusPill("Ready", Brand.Success)
                        MomentState.Failed -> StatusPill("Failed", Color(0xFFEF4444))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(m.label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                m.note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                val file = m.file
                if (m.state == MomentState.Ready && file != null) {
                    Spacer(Modifier.height(10.dp))
                    GradientButton(
                        "Edit, add captions and export",
                        onClick = {
                            vm.openClip(file)
                            onOpenEditor()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        icon = Icons.Rounded.ContentCut,
                    )
                }
            }
        }

        item {
            AppCard {
                SectionTitle("Activity log")
                Spacer(Modifier.height(6.dp))
                if (state.log.isEmpty()) {
                    Text("Nothing yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Column {
                        state.log.forEach {
                            Text(
                                it,
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IndicatorRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = color)
    }
}
