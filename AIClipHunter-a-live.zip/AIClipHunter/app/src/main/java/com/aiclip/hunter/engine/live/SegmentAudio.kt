package com.aiclip.hunter.engine.live

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.nio.ByteOrder
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/** How loud one piece of the stream is, in dB (0 = loudest possible, about -20 = loud talking). */
object SegmentAudio {

    fun levelDb(initFile: File?, seg: File, tmpDir: File): Float? {
        val src: File = if (initFile != null) {
            File(tmpDir, "probe_${seg.name}.mp4").also { f ->
                f.outputStream().use { o ->
                    initFile.inputStream().use { it.copyTo(o) }
                    seg.inputStream().use { it.copyTo(o) }
                }
            }
        } else {
            seg
        }
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(src.absolutePath)
            val track = (0 until extractor.trackCount).firstOrNull { i ->
                extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: return null
            extractor.selectTrack(track)
            val format = extractor.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            val decoder = MediaCodec.createDecoderByType(mime)
            codec = decoder
            decoder.configure(format, null, null, 0)
            decoder.start()

            val info = MediaCodec.BufferInfo()
            var sumSq = 0.0
            var count = 0L
            var inputDone = false
            var outputDone = false
            var idle = 0
            while (!outputDone && idle < 300) {
                if (!inputDone) {
                    val inIdx = decoder.dequeueInputBuffer(5_000)
                    if (inIdx >= 0) {
                        val buf = decoder.getInputBuffer(inIdx)
                        val size = if (buf != null) extractor.readSampleData(buf, 0) else -1
                        if (size < 0) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = decoder.dequeueOutputBuffer(info, 5_000)
                if (outIdx >= 0) {
                    idle = 0
                    val out = decoder.getOutputBuffer(outIdx)
                    if (out != null && info.size > 0) {
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val pcm = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        while (pcm.hasRemaining()) {
                            val v = pcm.get().toInt()
                            sumSq += v.toDouble() * v
                            count++
                        }
                    }
                    decoder.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else {
                    idle++
                }
            }
            if (count == 0L) return null
            val rms = sqrt(sumSq / count)
            return (20.0 * log10(max(rms, 1.0) / 32768.0)).toFloat()
        } catch (e: Exception) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            extractor.release()
            if (src != seg) src.delete()
        }
    }
}
