package com.aiclip.hunter.engine.live

import java.io.File

enum class MomentState { Waiting, Cutting, Ready, Failed }

/** One exciting moment found in the stream. [atSec] is on the recorder's own timeline. */
data class Moment(
    val id: Int,
    val atSec: Double,
    val clock: String,
    val label: String,
    val score: Float,
    val state: MomentState,
    val file: File? = null,
    val note: String? = null,
)

data class LiveUiState(
    val running: Boolean = false,
    val status: String = "Idle",
    val error: String? = null,
    val title: String? = null,
    val bufferSec: Int = 0,
    val chatStatus: String = "Off",
    val chatPerMin: Int = 0,
    val loudDb: Float? = null,
    val hype: Float = 0f,
    val moments: List<Moment> = emptyList(),
    val log: List<String> = emptyList(),
)

class ChatMsg(val text: String, val paid: Boolean, val emoji: Int)

/** One downloaded piece of the stream. */
class Seg(val seq: Long, val dur: Double, val startSec: Double, val file: File) {
    val endSec: Double get() = startSec + dur
}
