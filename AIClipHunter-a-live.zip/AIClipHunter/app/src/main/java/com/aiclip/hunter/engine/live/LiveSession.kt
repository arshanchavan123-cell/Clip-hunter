package com.aiclip.hunter.engine.live

import android.content.Context
import com.aiclip.hunter.clipping.Remuxer
import com.aiclip.hunter.utils.formatTime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

/**
 * One live session: follows the stream, listens to chat and sound, and saves a clip each time
 * something exciting happens. Works while the app is open.
 */
class LiveSession(private val context: Context, private val scope: CoroutineScope) {

    private val _state = MutableStateFlow(LiveUiState())
    val state: StateFlow<LiveUiState> = _state.asStateFlow()

    private var job: Job? = null
    private val clipsDir = File(context.filesDir, "live/clips")
    private val workDir = File(context.cacheDir, "live")
    private val remuxer = Remuxer(context)
    private var momentCounter = 0
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    private fun mutate(change: (LiveUiState) -> LiveUiState) = _state.update(change)

    private fun log(msg: String) {
        val line = "${timeFmt.format(Date())} $msg"
        mutate { it.copy(log = (it.log + line).takeLast(14)) }
    }

    fun start(url: String) {
        if (_state.value.running) return
        job = scope.launch(Dispatchers.IO) { runSession(url) }
    }

    fun stop() {
        job?.cancel()
    }

    private suspend fun runSession(url: String) {
        workDir.deleteRecursively()
        momentCounter = 0
        _state.value = LiveUiState(running = true, status = "Finding the stream…")
        val sessionStart = System.currentTimeMillis()
        try {
            log("Link received")
            val resolved = LiveResolver.resolve(url)
            log("Stream found" + (resolved.title?.let { ": ${it.take(40)}" } ?: ""))
            val dir = File(workDir, "s$sessionStart")
            val rec = HlsRecorder(dir, resolved.ua)
            rec.open(resolved.hlsUrl)
            log("Recording at ${rec.quality}")
            mutate { it.copy(status = "Recording", title = resolved.title) }
            val det = LiveDetector()

            coroutineScope {
                val videoId = resolved.videoId
                if (videoId != null) {
                    mutate { it.copy(chatStatus = "Connecting…") }
                    launch {
                        try {
                            YouTubeChat(videoId).run { msgs ->
                                det.chatActive = true
                                det.onChat(msgs, System.currentTimeMillis())
                                mutate { it.copy(chatStatus = "Live") }
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            det.chatActive = false
                            log("Chat off: ${e.message}")
                            mutate { it.copy(chatStatus = "Unavailable (sound only)") }
                        }
                    }
                } else {
                    mutate { it.copy(chatStatus = "Not available for this link (sound only)") }
                }

                launch {
                    while (isActive) {
                        delay(1_000)
                        try {
                            val now = System.currentTimeMillis()
                            val trig = det.tick(now)
                            mutate { it.copy(bufferSec = rec.bufferedSec.toInt(), chatPerMin = det.perMin, hype = det.hype) }
                            if (trig != null) addMoment(rec, trig, now - sessionStart)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            log("Detector: ${e.message}")
                        }
                    }
                }

                var failSince = 0L
                while (isActive) {
                    try {
                        val fresh = rec.poll()
                        failSince = 0L
                        for (s in fresh) {
                            SegmentAudio.levelDb(rec.initFile, s.file, dir)?.let { db ->
                                det.onLoud(db)
                                mutate { it.copy(loudDb = db) }
                            }
                        }
                        if (rec.ended) {
                            log("The stream has ended")
                            break
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        if (failSince == 0L) failSince = System.currentTimeMillis()
                        log("Network: ${e.message}")
                        if (System.currentTimeMillis() - failSince > 30_000) {
                            throw IllegalStateException("Lost the stream for 30 seconds.")
                        }
                    }
                    delay(rec.pollDelayMs)
                }
                coroutineContext.cancelChildrenSafely()
            }
        } catch (e: CancellationException) {
            log("Stopped")
        } catch (e: Exception) {
            log("Error: ${e.message}")
            mutate { it.copy(error = e.message ?: "Live analysis failed.") }
        } finally {
            mutate { it.copy(running = false, status = if (it.error != null) "Stopped with an error" else "Stopped", chatStatus = "Off") }
        }
    }

    private fun kotlin.coroutines.CoroutineContext.cancelChildrenSafely() {
        this[Job]?.children?.forEach { it.cancel() }
    }

    private fun addMoment(rec: HlsRecorder, trig: Trigger, sinceStartMs: Long) {
        val id = ++momentCounter
        val at = max(0.0, rec.endSec - 5.0) // chat reacts a few seconds after the event
        val m = Moment(id, at, formatTime(sinceStartMs), trig.label, trig.score, MomentState.Waiting)
        mutate { it.copy(moments = listOf(m) + it.moments) }
        log("Moment #$id: ${trig.label}")
        scope.launch(Dispatchers.IO) { makeClip(rec, m) }
    }

    private fun setMoment(id: Int, change: (Moment) -> Moment) {
        mutate { s -> s.copy(moments = s.moments.map { if (it.id == id) change(it) else it }) }
    }

    private suspend fun makeClip(rec: HlsRecorder, m: Moment) {
        try {
            var waited = 0
            while (rec.endSec < m.atSec + POST_SEC && waited < 45 && !rec.ended) {
                delay(1_000)
                waited++
            }
            setMoment(m.id) { it.copy(state = MomentState.Cutting) }
            val raw = File(rec.dir, "cut_${m.id}.${rec.extension}")
            if (!rec.cut(m.atSec - PRE_SEC, m.atSec + POST_SEC, raw)) {
                setMoment(m.id) { it.copy(state = MomentState.Failed, note = "That part had already left the saved video.") }
                return
            }
            clipsDir.mkdirs()
            val out = File(clipsDir, "moment_${System.currentTimeMillis()}_${m.id}.mp4")
            val result = remuxer.toMp4(raw, out)
            raw.delete()
            result.fold(
                onSuccess = {
                    setMoment(m.id) { it.copy(state = MomentState.Ready, file = out) }
                    log("Clip #${m.id} is ready")
                    pruneClips()
                },
                onFailure = { e ->
                    out.delete()
                    setMoment(m.id) { it.copy(state = MomentState.Failed, note = e.message) }
                    log("Clip #${m.id} failed: ${e.message}")
                },
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            setMoment(m.id) { it.copy(state = MomentState.Failed, note = e.message) }
        }
    }

    private fun pruneClips() {
        val files = clipsDir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
        files.drop(MAX_CLIPS).forEach { it.delete() }
    }

    private companion object {
        const val PRE_SEC = 25.0
        const val POST_SEC = 12.0
        const val MAX_CLIPS = 20
    }
}
