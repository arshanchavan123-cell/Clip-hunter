package com.aiclip.hunter.capture

import com.aiclip.hunter.engine.youtube.VideoInfo

enum class LiveStatus(val label: String) {
    WaitingForUrl("Waiting for URL"),
    ValidatingUrl("Validating URL"),
    VideoDetected("Video detected"),
    WaitingForPermission("Waiting for screen-capture permission"),
    CaptureActive("Screen capture active"),
    CapturePaused("Screen capture paused"),
    Analyzing("Analyzing video"),
    MomentsDetected("Moments detected"),
    GeneratingClips("Generating clips"),
    Completed("Completed"),
    Error("Error"),
}

data class LiveUi(
    val status: LiveStatus = LiveStatus.WaitingForUrl,
    val error: String? = null,
    val info: VideoInfo? = null,
    val apiKey: String = "",
    val capture: CaptureState = CaptureState(),
    val autoClips: Boolean = true,
    val clipCount: Int = 5,
    val clipsMade: Int = 0,
    val clipsTotal: Int = 0,
    val note: String? = null,
    val log: List<String> = emptyList(),
) {
    /** True when a capture can be started for the checked link. */
    val canStart: Boolean
        get() = info != null && info.kind != com.aiclip.hunter.engine.youtube.VideoKind.Upcoming &&
            status !in setOf(
                LiveStatus.WaitingForPermission, LiveStatus.CaptureActive, LiveStatus.CapturePaused,
                LiveStatus.Analyzing, LiveStatus.GeneratingClips, LiveStatus.ValidatingUrl,
            )

    val busy: Boolean
        get() = status in setOf(
            LiveStatus.WaitingForPermission, LiveStatus.CaptureActive, LiveStatus.CapturePaused,
            LiveStatus.Analyzing, LiveStatus.GeneratingClips,
        )
}
