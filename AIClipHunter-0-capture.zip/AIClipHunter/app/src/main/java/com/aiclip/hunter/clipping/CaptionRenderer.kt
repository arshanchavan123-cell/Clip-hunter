package com.aiclip.hunter.clipping

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.aiclip.hunter.domain.models.AspectOption
import com.aiclip.hunter.domain.models.CaptionAnimation
import com.aiclip.hunter.domain.models.CaptionFont
import com.aiclip.hunter.domain.models.CaptionLanguage
import com.aiclip.hunter.domain.models.CaptionStyle
import com.aiclip.hunter.domain.models.CaptionWord
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** A few words that are on screen together. */
class CaptionPage(val words: List<CaptionWord>, val startMs: Long, val endMs: Long)

/** Draws one caption page onto a canvas. Used for the export overlay and for the live preview. */
class CaptionRenderer(private val cs: CaptionStyle, private val width: Int, private val height: Int) {

    private val base = min(width, height) * 0.085f * cs.size.scale

    private val face: Typeface = when (cs.font) {
        CaptionFont.Black -> Typeface.create("sans-serif-black", Typeface.NORMAL)
        CaptionFont.Condensed -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
        CaptionFont.Bold -> Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = base
        typeface = face
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = base
        typeface = face
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeWidth = base * cs.outline.width * 2f
        color = 0xFF000000.toInt()
    }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun label(w: CaptionWord): String = if (cs.uppercase) w.text.uppercase() else w.text

    private fun ease(x: Float): Float {
        val c = x.coerceIn(0f, 1f)
        return 1f - (1f - c) * (1f - c) * (1f - c)
    }

    private fun withAlpha(color: Int, alpha: Float): Int {
        val a = ((color ushr 24) * alpha.coerceIn(0f, 1f)).toInt()
        return (color and 0x00FFFFFF) or (a shl 24)
    }

    fun draw(canvas: Canvas, page: CaptionPage, tMs: Long) {
        val ws = page.words
        if (ws.isEmpty()) return
        var cur = 0
        for (i in ws.indices) if (ws[i].startMs <= tMs) cur = i
        val sinceWord = (tMs - ws[cur].startMs).coerceAtLeast(0L).toFloat()
        val sincePage = (tMs - page.startMs).coerceAtLeast(0L).toFloat()
        val toEnd = (page.endMs - tMs).coerceAtLeast(0L).toFloat()

        var alpha = 1f
        var dx = 0f
        var dy = 0f
        when (cs.animation) {
            CaptionAnimation.SlideUp -> {
                val e = ease(sincePage / 200f)
                dy = (1f - e) * height * 0.04f
                alpha = e
            }
            CaptionAnimation.Fade -> alpha = min(1f, min(sincePage / 150f, toEnd / 150f))
            CaptionAnimation.Shake -> {
                val d = max(0f, 1f - sinceWord / 260f)
                dx = sin(tMs / 21f) * base * 0.10f * d
                dy = cos(tMs / 17f) * base * 0.08f * d
            }
            else -> Unit
        }

        // Lay the words out in lines that fit 90% of the width.
        val maxW = width * 0.9f
        val space = fill.measureText(" ")
        val labels = ws.map { label(it) }
        val widths = labels.map { fill.measureText(it) }
        val lines = ArrayList<ArrayList<Int>>()
        val lineWidths = ArrayList<Float>()
        var line = ArrayList<Int>()
        var lw = 0f
        for (i in ws.indices) {
            val add = if (line.isEmpty()) widths[i] else space + widths[i]
            if (line.isNotEmpty() && lw + add > maxW) {
                lines.add(line)
                lineWidths.add(lw)
                line = ArrayList()
                lw = widths[i]
            } else {
                lw += add
            }
            line.add(i)
        }
        if (line.isNotEmpty()) {
            lines.add(line)
            lineWidths.add(lw)
        }

        val lineH = base * 1.18f
        val blockH = lines.size * lineH
        val top = height * cs.position.y - blockH / 2f + dy

        if (cs.box) {
            val pad = base * 0.35f
            val bw = (lineWidths.maxOrNull() ?: 0f) + pad * 2f
            val rect = RectF((width - bw) / 2f + dx, top - pad * 0.4f, (width + bw) / 2f + dx, top + blockH + pad * 0.4f)
            boxPaint.color = withAlpha(0xB3000000.toInt(), alpha)
            canvas.drawRoundRect(rect, base * 0.3f, base * 0.3f, boxPaint)
        }

        for ((k, idxs) in lines.withIndex()) {
            var x = (width - lineWidths[k]) / 2f + dx
            val baseline = top + k * lineH + base * 0.82f
            for (i in idxs) {
                val isCur = i == cur
                val color = if (isCur && cs.animation != CaptionAnimation.None) cs.highlightColor else cs.textColor
                var scale = 1f
                if (isCur && cs.animation == CaptionAnimation.Pop) {
                    val q = (sinceWord / 150f).coerceIn(0f, 1f)
                    scale = 1f + 0.32f * (1f - q) * (1f - q)
                }
                val cx = x + widths[i] / 2f
                val cy = baseline - base * 0.3f
                canvas.save()
                canvas.translate(cx, cy)
                canvas.scale(scale, scale)
                canvas.translate(-cx, -cy)
                if (cs.outline.width > 0f) {
                    stroke.alpha = (255 * alpha).toInt()
                    canvas.drawText(labels[i], x, baseline, stroke)
                }
                if (cs.glow) fill.setShadowLayer(base * 0.35f, 0f, 0f, withAlpha(color, alpha))
                fill.color = withAlpha(color, alpha)
                canvas.drawText(labels[i], x, baseline, fill)
                if (cs.glow) fill.clearShadowLayer()
                canvas.restore()
                x += widths[i] + space
            }
        }
    }

    companion object {
        fun buildPages(words: List<CaptionWord>, perPage: Int): List<CaptionPage> {
            val raw = ArrayList<CaptionPage>()
            var cur = ArrayList<CaptionWord>()
            fun flush() {
                if (cur.isEmpty()) return
                raw.add(CaptionPage(cur.toList(), max(0L, cur.first().startMs - 60), cur.last().endMs + 300))
                cur = ArrayList()
            }
            for (w in words) {
                if (cur.isNotEmpty() && (cur.size >= perPage || w.startMs - cur.last().endMs > 700)) flush()
                cur.add(w)
            }
            flush()
            return raw.mapIndexed { i, p ->
                val nextStart = raw.getOrNull(i + 1)?.startMs ?: Long.MAX_VALUE
                CaptionPage(p.words, p.startMs, min(p.endMs, nextStart - 20))
            }
        }

        /** A still picture of the caption style, shown over the thumbnail in the editor. */
        fun preview(cs: CaptionStyle, aspect: AspectOption): Bitmap {
            val ratio = aspect.ratio
            val w = when {
                ratio > 1.2f -> 960
                ratio < 0.8f -> 540
                else -> 720
            }
            val h = (w / ratio).toInt()
            val sample = when (cs.language) {
                CaptionLanguage.English -> listOf("THIS", "CLUTCH", "IS", "INSANE")
                CaptionLanguage.Hindi -> listOf("ये", "क्लच", "पागल", "है")
                CaptionLanguage.Hinglish -> listOf("YE", "CLUTCH", "PAGAL", "HAI")
            }
            val words = sample.mapIndexed { i, s -> CaptionWord(s, i * 380L, i * 380L + 340L) }
            val page = buildPages(words, cs.wordsPerLine).first()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val second = page.words.getOrElse(1) { page.words[0] }
            CaptionRenderer(cs, w, h).draw(Canvas(bmp), page, second.startMs + 70L)
            return bmp
        }
    }
}
