package com.aiclip.hunter.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aiclip.hunter.domain.models.CaptionAnimation
import com.aiclip.hunter.domain.models.CaptionColors
import com.aiclip.hunter.domain.models.CaptionFont
import com.aiclip.hunter.domain.models.CaptionLanguage
import com.aiclip.hunter.domain.models.CaptionOutline
import com.aiclip.hunter.domain.models.CaptionPosition
import com.aiclip.hunter.domain.models.CaptionPreset
import com.aiclip.hunter.domain.models.CaptionSize
import com.aiclip.hunter.domain.models.CaptionStyle
import com.aiclip.hunter.domain.models.withPreset
import com.aiclip.hunter.ui.theme.Brand

/** All caption options. The picture above the editor shows the result straight away. */
@Composable
fun CaptionOptions(style: CaptionStyle, onChange: ((CaptionStyle) -> CaptionStyle) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Spacer(Modifier.height(6.dp))

        OptionLabel("Language")
        ChipRow(CaptionLanguage.entries, style.language, { it.label }) { v -> onChange { it.copy(language = v) } }
        if (style.language != CaptionLanguage.English) {
            Text(
                "Best for Hindi speech. English words said inside Hindi may be written approximately.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        OptionLabel("Style")
        ChipRow(CaptionPreset.entries, style.preset, { it.label }) { v -> onChange { it.withPreset(v) } }

        OptionLabel("Animation")
        ChipRow(CaptionAnimation.entries, style.animation, { it.label }) { v -> onChange { it.copy(animation = v) } }

        OptionLabel("Position")
        ChipRow(CaptionPosition.entries, style.position, { it.label }) { v -> onChange { it.copy(position = v) } }

        OptionLabel("Font")
        ChipRow(CaptionFont.entries, style.font, { it.label }) { v -> onChange { it.copy(font = v) } }

        OptionLabel("Size")
        ChipRow(CaptionSize.entries, style.size, { it.label }) { v -> onChange { it.copy(size = v) } }

        OptionLabel("Words on screen")
        ChipRow(listOf(1, 2, 3, 4), style.wordsPerLine, { it.toString() }) { v -> onChange { it.copy(wordsPerLine = v) } }

        OptionLabel("Text colour")
        ColorRow(style.textColor) { c -> onChange { it.copy(textColor = c) } }

        OptionLabel("Highlight colour (word being spoken)")
        ColorRow(style.highlightColor) { c -> onChange { it.copy(highlightColor = c) } }

        OptionLabel("Outline")
        ChipRow(CaptionOutline.entries, style.outline, { it.label }) { v -> onChange { it.copy(outline = v) } }

        ToggleRow("CAPITAL LETTERS", style.uppercase) { v -> onChange { it.copy(uppercase = v) } }
        ToggleRow("Dark box behind text", style.box) { v -> onChange { it.copy(box = v) } }
        ToggleRow("Neon glow", style.glow) { v -> onChange { it.copy(glow = v) } }
    }
}

@Composable
private fun OptionLabel(text: String) {
    Spacer(Modifier.height(4.dp))
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> ChipRow(items: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items.forEach { item ->
            FilterChip(
                selected = item == selected,
                onClick = { onSelect(item) },
                label = { Text(label(item)) },
            )
        }
    }
}

@Composable
private fun ColorRow(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        CaptionColors.all.forEach { c ->
            val chosen = c == selected
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(
                        if (chosen) 3.dp else 1.dp,
                        if (chosen) Brand.Violet else MaterialTheme.colorScheme.outline,
                        CircleShape,
                    )
                    .clickable { onSelect(c) },
            )
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
