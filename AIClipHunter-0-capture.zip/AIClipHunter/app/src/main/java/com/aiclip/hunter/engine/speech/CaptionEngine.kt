package com.aiclip.hunter.engine.speech

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.aiclip.hunter.domain.models.CaptionLanguage
import com.aiclip.hunter.domain.models.CaptionWord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteOrder
import java.util.zip.ZipInputStream
import kotlin.math.max

/**
 * Turns speech into timed words on the phone (Vosk, no account, no cloud). The speech model is
 * downloaded once (about 40 MB) and kept in the app's private storage.
 */
class CaptionEngine(private val context: Context) {

    private fun modelName(lang: CaptionLanguage) =
        if (lang.model == "hi") "vosk-model-small-hi-0.22" else "vosk-model-small-en-us-0.15"

    private val root get() = File(context.filesDir, "vosk")
    private fun modelDir(lang: CaptionLanguage) = File(root, modelName(lang))

    fun isReady(lang: CaptionLanguage): Boolean = File(modelDir(lang), "am").isDirectory

    suspend fun ensureModel(lang: CaptionLanguage, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        if (isReady(lang)) return@withContext
        root.mkdirs()
        val name = modelName(lang)
        val zip = File(root, "$name.zip.part")
        val conn = URL("https://alphacephei.com/vosk/models/$name.zip").openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        try {
            conn.connect()
            if (conn.responseCode !in 200..299) error("Model download failed (HTTP ${conn.responseCode})")
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                zip.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress(0.9f * done / total)
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
        unzip(zip, root)
        zip.delete()
        check(isReady(lang)) { "Speech model files are missing after download" }
        onProgress(1f)
    }

    private fun unzip(zip: File, dest: File) {
        val destPath = dest.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                val out = File(dest, entry.name)
                require(out.canonicalPath.startsWith(destPath)) { "Bad file in model download" }
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zin.copyTo(it) }
                }
                zin.closeEntry()
                entry = zin.nextEntry
            }
        }
    }

    /**
     * Words spoken inside [parts] (source times, in ms). Returned times are on the exported clip's
     * timeline, so parts joined into one montage line up with the final video.
     */
    suspend fun transcribe(
        source: Uri,
        parts: List<Pair<Long, Long>>,
        lang: CaptionLanguage,
        onProgress: (Float) -> Unit,
    ): List<CaptionWord> = withContext(Dispatchers.Default) {
        val model = Model(modelDir(lang).absolutePath)
        try {
            val words = ArrayList<CaptionWord>()
            val total = parts.sumOf { it.second - it.first }.coerceAtLeast(1L)
            var offset = 0L
            for ((s, e) in parts) {
                val recognizer = Recognizer(model, 16000f)
                recognizer.setWords(true)
                try {
                    val doneBefore = offset
                    decodeRange(
                        source, s, e,
                        onPcm = { pcm, n ->
                            if (recognizer.acceptWaveForm(pcm, n)) collect(recognizer.result, offset, lang, words)
                        },
                        onRange = { f -> onProgress(((doneBefore + (e - s) * f) / total).coerceIn(0f, 1f)) },
                    )
                    collect(recognizer.finalResult, offset, lang, words)
                } finally {
                    recognizer.close()
                }
                offset += e - s
            }
            words
        } finally {
            model.close()
        }
    }

    private fun collect(json: String, offsetMs: Long, lang: CaptionLanguage, out: MutableList<CaptionWord>) {
        val arr = runCatching { JSONObject(json).optJSONArray("result") }.getOrNull() ?: return
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            var text = o.optString("word")
            if (text.isBlank()) continue
            if (lang == CaptionLanguage.Hinglish) text = Transliterator.toRoman(text)
            val start = (o.optDouble("start", 0.0) * 1000).toLong() + offsetMs
            val end = (o.optDouble("end", 0.0) * 1000).toLong() + offsetMs
            out.add(CaptionWord(text, start, max(end, start + 120)))
        }
    }

    /** Decodes the audio between [startMs] and [endMs] to 16 kHz mono and hands it over in small pieces. */
    private suspend fun decodeRange(
        uri: Uri,
        startMs: Long,
        endMs: Long,
        onPcm: (ShortArray, Int) -> Unit,
        onRange: (Float) -> Unit,
    ) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            val track = (0 until extractor.trackCount).firstOrNull { i ->
                extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: return
            extractor.selectTrack(track)
            val format = extractor.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return
            val startUs = startMs * 1000
            val endUs = endMs * 1000
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val decoder = MediaCodec.createDecoderByType(mime)
            codec = decoder
            decoder.configure(format, null, null, 0)
            decoder.start()

            var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
            var resampler = Resampler(sampleRate)

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var idleRounds = 0
            while (!outputDone) {
                currentCoroutineContext().ensureActive()
                if (!inputDone) {
                    val inIdx = decoder.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val inBuf = decoder.getInputBuffer(inIdx)
                        val st = extractor.sampleTime
                        val size = if (inBuf != null && st in 0..(endUs + 500_000)) extractor.readSampleData(inBuf, 0) else -1
                        if (size < 0) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIdx, 0, size, st, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = decoder.dequeueOutputBuffer(info, 10_000)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = decoder.outputFormat
                    sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    resampler = Resampler(sampleRate)
                } else if (outIdx >= 0) {
                    idleRounds = 0
                    val out = decoder.getOutputBuffer(outIdx)
                    val ptsUs = info.presentationTimeUs
                    if (out != null && info.size > 0) {
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val pcm = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val frames = pcm.remaining() / channels
                        val from = if (ptsUs >= startUs) 0 else
                            (((startUs - ptsUs) * sampleRate + 999_999L) / 1_000_000L).toInt().coerceIn(0, frames)
                        val to = (((endUs - ptsUs) * sampleRate) / 1_000_000L).toInt().coerceIn(0, frames)
                        if (to > from) {
                            val mono = FloatArray(to - from)
                            for (f in from until to) {
                                var sum = 0
                                for (ch in 0 until channels) sum += pcm.get(f * channels + ch)
                                mono[f - from] = sum / (channels * 32768f)
                            }
                            val converted = resampler.process(mono, mono.size)
                            if (converted.isNotEmpty()) onPcm(converted, converted.size)
                        }
                    }
                    decoder.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || ptsUs >= endUs) outputDone = true
                    onRange(((ptsUs - startUs).toFloat() / (endUs - startUs).coerceAtLeast(1)).coerceIn(0f, 1f))
                } else if (inputDone) {
                    idleRounds++
                    if (idleRounds > 300) outputDone = true
                }
            }
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            extractor.release()
        }
    }

    /** Streaming linear resampler to 16 kHz. */
    private class Resampler(inRate: Int) {
        private val step = inRate / 16000.0
        private var prev = 0f
        private var p = 1.0
        private var first = true

        fun process(x: FloatArray, n: Int): ShortArray {
            if (n == 0) return ShortArray(0)
            if (first) {
                prev = x[0]
                first = false
            }
            val out = ShortArray((n / step).toInt() + 3)
            var k = 0
            while (p < n && k < out.size) {
                val i = p.toInt()
                val f = (p - i).toFloat()
                val a = if (i == 0) prev else x[i - 1]
                val b = x[i]
                val v = (a + (b - a) * f).coerceIn(-1f, 1f)
                out[k++] = (v * 32767f).toInt().toShort()
                p += step
            }
            p -= n
            prev = x[n - 1]
            return out.copyOf(k)
        }
    }
}
