package com.aiclip.hunter.domain.models

/** Speech language for auto captions. Hinglish = Hindi speech written in English letters. */
enum class CaptionLanguage(val label: String, val model: String) {
    English("English", "en"),
    Hindi("Hindi (हिन्दी)", "hi"),
    Hinglish("Hinglish (Roman)", "hi"),
}

enum class CaptionPreset(val label: String) { Hype("Hype"), Neon("Neon"), Box("Box"), Rage("Rage"), Clean("Clean") }

enum class CaptionAnimation(val label: String) {
    Pop("Pop"),
    Karaoke("Karaoke"),
    SlideUp("Slide up"),
    Shake("Shake"),
    Fade("Fade"),
    None("None"),
}

/** [y] is the vertical centre of the caption block as a fraction of the video height. */
enum class CaptionPosition(val label: String, val y: Float) {
    Top("Top", 0.16f),
    Center("Center", 0.5f),
    Lower("Lower", 0.7f),
    Bottom("Bottom", 0.86f),
}

enum class CaptionFont(val label: String) { Black("Black"), Condensed("Condensed"), Bold("Bold") }

enum class CaptionSize(val label: String, val scale: Float) {
    Small("S", 0.75f),
    Medium("M", 1f),
    Large("L", 1.3f),
    XL("XL", 1.6f),
}

/** [width] is the outline thickness as a fraction of the text size. */
enum class CaptionOutline(val label: String, val width: Float) {
    None("None", 0f),
    Thin("Thin", 0.07f),
    Thick("Thick", 0.15f),
}

object CaptionColors {
    val White = 0xFFFFFFFF.toInt()
    val Yellow = 0xFFFFE600.toInt()
    val Cyan = 0xFF00E5FF.toInt()
    val Green = 0xFF39FF14.toInt()
    val Orange = 0xFFFF8A00.toInt()
    val Red = 0xFFFF2D2D.toInt()
    val Pink = 0xFFFF3DDB.toInt()
    val Violet = 0xFF8B5CF6.toInt()
    val Black = 0xFF000000.toInt()
    val all: List<Int> = listOf(White, Yellow, Cyan, Green, Orange, Red, Pink, Violet, Black)
}

data class CaptionWord(val text: String, val startMs: Long, val endMs: Long)

data class CaptionStyle(
    val enabled: Boolean = false,
    val language: CaptionLanguage = CaptionLanguage.Hinglish,
    val preset: CaptionPreset = CaptionPreset.Hype,
    val animation: CaptionAnimation = CaptionAnimation.Pop,
    val position: CaptionPosition = CaptionPosition.Lower,
    val font: CaptionFont = CaptionFont.Black,
    val size: CaptionSize = CaptionSize.Large,
    val textColor: Int = CaptionColors.White,
    val highlightColor: Int = CaptionColors.Yellow,
    val outline: CaptionOutline = CaptionOutline.Thick,
    val box: Boolean = false,
    val glow: Boolean = false,
    val uppercase: Boolean = true,
    val wordsPerLine: Int = 2,
)

/** Applies a ready-made look. The user can still change every option afterwards. */
fun CaptionStyle.withPreset(p: CaptionPreset): CaptionStyle = when (p) {
    CaptionPreset.Hype -> copy(
        preset = p, font = CaptionFont.Black, uppercase = true, textColor = CaptionColors.White,
        highlightColor = CaptionColors.Yellow, outline = CaptionOutline.Thick, box = false, glow = false,
        animation = CaptionAnimation.Pop, position = CaptionPosition.Lower, size = CaptionSize.Large, wordsPerLine = 2,
    )
    CaptionPreset.Neon -> copy(
        preset = p, font = CaptionFont.Condensed, uppercase = true, textColor = CaptionColors.White,
        highlightColor = CaptionColors.Cyan, outline = CaptionOutline.Thin, box = false, glow = true,
        animation = CaptionAnimation.Karaoke, position = CaptionPosition.Lower, size = CaptionSize.Large, wordsPerLine = 3,
    )
    CaptionPreset.Box -> copy(
        preset = p, font = CaptionFont.Bold, uppercase = false, textColor = CaptionColors.White,
        highlightColor = CaptionColors.Yellow, outline = CaptionOutline.None, box = true, glow = false,
        animation = CaptionAnimation.Karaoke, position = CaptionPosition.Bottom, size = CaptionSize.Medium, wordsPerLine = 4,
    )
    CaptionPreset.Rage -> copy(
        preset = p, font = CaptionFont.Black, uppercase = true, textColor = CaptionColors.Yellow,
        highlightColor = CaptionColors.Red, outline = CaptionOutline.Thick, box = false, glow = false,
        animation = CaptionAnimation.Shake, position = CaptionPosition.Center, size = CaptionSize.XL, wordsPerLine = 2,
    )
    CaptionPreset.Clean -> copy(
        preset = p, font = CaptionFont.Bold, uppercase = false, textColor = CaptionColors.White,
        highlightColor = CaptionColors.Green, outline = CaptionOutline.Thin, box = false, glow = false,
        animation = CaptionAnimation.Fade, position = CaptionPosition.Lower, size = CaptionSize.Medium, wordsPerLine = 3,
    )
}
