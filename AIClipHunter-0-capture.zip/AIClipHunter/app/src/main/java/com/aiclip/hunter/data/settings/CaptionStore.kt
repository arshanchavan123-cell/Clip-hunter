package com.aiclip.hunter.data.settings

import android.content.Context
import com.aiclip.hunter.domain.models.CaptionAnimation
import com.aiclip.hunter.domain.models.CaptionFont
import com.aiclip.hunter.domain.models.CaptionLanguage
import com.aiclip.hunter.domain.models.CaptionOutline
import com.aiclip.hunter.domain.models.CaptionPosition
import com.aiclip.hunter.domain.models.CaptionPreset
import com.aiclip.hunter.domain.models.CaptionSize
import com.aiclip.hunter.domain.models.CaptionStyle

/** Remembers the caption style between launches. */
class CaptionStore(context: Context) {
    private val prefs = context.getSharedPreferences("captions", Context.MODE_PRIVATE)

    private inline fun <reified T : Enum<T>> pick(key: String, default: T): T {
        val name = prefs.getString(key, null)
        return enumValues<T>().firstOrNull { it.name == name } ?: default
    }

    fun load(): CaptionStyle {
        val d = CaptionStyle()
        return CaptionStyle(
            enabled = prefs.getBoolean("enabled", d.enabled),
            language = pick("language", d.language),
            preset = pick("preset", d.preset),
            animation = pick("animation", d.animation),
            position = pick("position", d.position),
            font = pick("font", d.font),
            size = pick("size", d.size),
            textColor = prefs.getInt("textColor", d.textColor),
            highlightColor = prefs.getInt("highlightColor", d.highlightColor),
            outline = pick("outline", d.outline),
            box = prefs.getBoolean("box", d.box),
            glow = prefs.getBoolean("glow", d.glow),
            uppercase = prefs.getBoolean("uppercase", d.uppercase),
            wordsPerLine = prefs.getInt("wordsPerLine", d.wordsPerLine).coerceIn(1, 4),
        )
    }

    fun save(s: CaptionStyle) {
        prefs.edit()
            .putBoolean("enabled", s.enabled)
            .putString("language", s.language.name)
            .putString("preset", s.preset.name)
            .putString("animation", s.animation.name)
            .putString("position", s.position.name)
            .putString("font", s.font.name)
            .putString("size", s.size.name)
            .putInt("textColor", s.textColor)
            .putInt("highlightColor", s.highlightColor)
            .putString("outline", s.outline.name)
            .putBoolean("box", s.box)
            .putBoolean("glow", s.glow)
            .putBoolean("uppercase", s.uppercase)
            .putInt("wordsPerLine", s.wordsPerLine)
            .apply()
    }
}
