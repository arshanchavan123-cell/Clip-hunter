package com.aiclip.hunter.engine.speech

/** Writes Hindi (Devanagari) words in English letters, the way people type Hinglish. */
object Transliterator {

    /** Gaming and internet words the Hindi model writes in Devanagari. */
    private val common = mapOf(
        "गेम" to "game", "गेमिंग" to "gaming", "क्लच" to "clutch", "किल" to "kill", "नूब" to "noob",
        "हेडशॉट" to "headshot", "स्नाइपर" to "sniper", "लाइव" to "live", "स्ट्रीम" to "stream",
        "स्ट्रीमर" to "streamer", "चैट" to "chat", "टीम" to "team", "प्लेयर" to "player", "लेवल" to "level",
        "बॉस" to "boss", "वाह" to "wah", "ओके" to "ok", "सॉरी" to "sorry", "प्लीज" to "please",
        "थैंक्स" to "thanks", "गन" to "gun", "रश" to "rush", "फाइट" to "fight", "मैच" to "match",
        "लॉबी" to "lobby", "लैग" to "lag", "रैंक" to "rank", "वीडियो" to "video", "सब्सक्राइब" to "subscribe",
        "लाइक" to "like", "शेयर" to "share", "कमेंट" to "comment", "चैनल" to "channel", "हेल्प" to "help",
        "अटैक" to "attack", "डिफेंड" to "defend", "मोड" to "mode", "सर्वर" to "server", "फोन" to "phone",
        "मोबाइल" to "mobile", "बग" to "bug", "हैक" to "hack", "चीटर" to "cheater", "चीट" to "cheat",
        "लूट" to "loot", "ड्रॉप" to "drop", "भाई" to "bhai", "नहीं" to "nahi", "ठीक" to "theek",
        "बिल्कुल" to "bilkul", "ज़बरदस्त" to "zabardast", "जबरदस्त" to "zabardast", "पागल" to "pagal",
    )

    private val cons = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n", 'च' to "ch", 'छ' to "chh", 'ज' to "j",
        'झ' to "jh", 'ञ' to "n", 'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n", 'त' to "t",
        'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n", 'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh",
        'म' to "m", 'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh", 'स' to "s",
        'ह' to "h", 'ळ' to "l",
    )
    private val nukta = mapOf('क' to "q", 'ख' to "kh", 'ग' to "g", 'ज' to "z", 'ड' to "r", 'ढ' to "rh", 'फ' to "f")
    private val vowels = mapOf(
        'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo", 'ऋ' to "ri", 'ए' to "e",
        'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o",
    )
    private val matras = mapOf(
        'ा' to "aa", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'ृ' to "ri", 'े' to "e", 'ै' to "ai",
        'ो' to "o", 'ौ' to "au", 'ॉ' to "o", 'ॅ' to "e",
    )

    private const val VIRAMA = '\u094D'
    private const val NUKTA = '\u093C'
    private const val ANUSVARA = '\u0902'
    private const val CHANDRABINDU = '\u0901'
    private const val VISARGA = '\u0903'

    private fun shorten(v: String) = when (v) {
        "aa" -> "a"
        "ee" -> "i"
        "oo" -> "u"
        else -> v
    }

    fun toRoman(word: String): String {
        common[word]?.let { return it }
        if (word.none { it in '\u0900'..'\u097F' }) return word
        val sb = StringBuilder()
        val n = word.length
        var i = 0
        while (i < n) {
            val c = word[i]
            val base = cons[c]
            if (base != null) {
                i++
                var b: String = base
                if (i < n && word[i] == NUKTA) {
                    nukta[c]?.let { b = it }
                    i++
                }
                if (i < n && word[i] == VIRAMA) { // conjunct: no vowel after this consonant
                    sb.append(b)
                    i++
                    continue
                }
                val m = if (i < n) matras[word[i]] else null
                if (m != null) {
                    i++
                    val atEnd = i >= n || (i == n - 1 && (word[i] == ANUSVARA || word[i] == CHANDRABINDU))
                    sb.append(b).append(if (atEnd) shorten(m) else m)
                } else {
                    sb.append(b)
                    if (i < n) sb.append('a') // the hidden "a" is dropped at the end of a word
                }
                continue
            }
            val v = vowels[c]
            when {
                v != null -> sb.append(v)
                c == ANUSVARA || c == CHANDRABINDU -> sb.append('n')
                c == VISARGA -> sb.append('h')
                c == '\u0964' || c == '\u0965' -> Unit
                c in '\u0966'..'\u096F' -> sb.append('0' + (c - '\u0966'))
                c == NUKTA || c == VIRAMA -> Unit
                else -> sb.append(c)
            }
            i++
        }
        return sb.toString()
    }
}
