package com.aiclip.hunter.data.settings

import android.content.Context

/** The person's own YouTube Data API key. It is only stored on this phone and never hard-coded in the app. */
class ApiKeyStore(context: Context) {
    private val prefs = context.getSharedPreferences("youtube", Context.MODE_PRIVATE)

    fun get(): String = prefs.getString("apiKey", "").orEmpty()

    fun set(key: String) {
        prefs.edit().putString("apiKey", key.trim()).apply()
    }
}
