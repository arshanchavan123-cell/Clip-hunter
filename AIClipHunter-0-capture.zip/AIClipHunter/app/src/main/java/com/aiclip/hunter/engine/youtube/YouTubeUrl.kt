package com.aiclip.hunter.engine.youtube

import android.net.Uri

sealed class UrlResult {
    data class Valid(val id: String, val canonical: String, val livePath: Boolean) : UrlResult()
    data class Invalid(val message: String) : UrlResult()
}

/** Reads a pasted YouTube link and extracts the video ID. Tracking parameters are ignored. */
object YouTubeUrl {
    private val idRe = Regex("^[A-Za-z0-9_-]{11}$")
    private val hosts = setOf("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be", "www.youtu.be")

    fun parse(input: String): UrlResult {
        val text = input.trim()
        if (text.isEmpty()) return UrlResult.Invalid("Paste a YouTube link first.")
        if (text.contains(' ')) return UrlResult.Invalid("That doesn't look like a single link.")
        val uri = runCatching { Uri.parse(if (text.startsWith("http://") || text.startsWith("https://")) text else "https://$text") }.getOrNull()
        val host = uri?.host?.lowercase()
        if (uri == null || host.isNullOrBlank() || !host.contains('.')) {
            return UrlResult.Invalid("That doesn't look like a valid link.")
        }
        if (host !in hosts) return UrlResult.Invalid("Only YouTube links are supported. $host isn't supported.")

        val segs = uri.pathSegments
        var id: String? = null
        var livePath = false
        when {
            host.endsWith("youtu.be") -> id = segs.firstOrNull()
            segs.firstOrNull() == "watch" -> id = uri.getQueryParameter("v")
            segs.firstOrNull() == "live" -> {
                id = segs.getOrNull(1)
                livePath = true
            }
            segs.firstOrNull() in setOf("shorts", "embed", "v") -> id = segs.getOrNull(1)
        }
        if (id == null) {
            return UrlResult.Invalid(
                "This YouTube link doesn't point to a video. Use a watch, live, shorts or youtu.be link. " +
                    "Channel, playlist and search pages aren't supported.",
            )
        }
        if (!idRe.matches(id)) return UrlResult.Invalid("The video ID in this link isn't valid.")
        return UrlResult.Valid(id, "https://www.youtube.com/watch?v=$id", livePath)
    }
}
