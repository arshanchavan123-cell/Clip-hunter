package com.aiclip.hunter.capture

import android.annotation.SuppressLint
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.os.Bundle
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Records the screen the person allowed (and the sound of the playing app, when Android and that app
 * allow it) into one MP4 file with MediaCodec and MediaMuxer. Nothing is uploaded.
 */
class ScreenRecorder(
    private val projection: MediaProjection,
    private val outFile: File,
    private val width: Int,
    private val height: Int,
    private val dpi: Int,
    private val wantAudio: Boolean,
    private val onAudio: (AudioMode, String?) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onError: (String) -> Unit,
) {
    private class Pending(val video: Boolean, val data: ByteArray, val flags: Int, val ptsUs: Long)

    private val lock = Any()
    private var muxer: MediaMuxer? = null
    private var videoEnc: MediaCodec? = null
    private var audioEnc: MediaCodec? = null
    private var audioRecord: AudioRecord? = null
    private var display: VirtualDisplay? = null
    private var surface: Surface? = null
    private var videoThread: Thread? = null
    private var audioThread: Thread? = null

    private var videoTrack = -1
    private var audioTrack = -1
    private var muxerStarted = false
    private var audioExpected = false
    private val pending = ArrayList<Pending>()

    @Volatile private var running = false
    @Volatile private var stopAtUs = 0L
    @Volatile private var paused = false
    private var needKey = false
    private var pausedTotalUs = 0L
    private var pauseStartUs = 0L
    private var baseUs = -1L
    private var videoShiftUs = Long.MIN_VALUE
    private var lastVideoPts = -1L
    private var lastAudioPts = -1L
    private var startUs = 0L
    private var frames = 0

    private fun nowUs() = System.nanoTime() / 1000

    fun start() {
        muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        startUs = nowUs()

        val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, if (max(width, height) > 1300) 3_000_000 else 2_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 500_000L)
        }
        val venc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val s = venc.createInputSurface()
        venc.start()
        videoEnc = venc
        surface = s
        display = projection.createVirtualDisplay(
            "AIClipHunterCapture", width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, s, null, null,
        ) ?: throw IllegalStateException("Android couldn't create the capture display.")

        if (wantAudio) setupAudio()

        running = true
        videoThread = Thread({ videoLoop() }, "capture-video").also { it.start() }
        audioThread?.start()
    }

    @SuppressLint("MissingPermission")
    private fun setupAudio() {
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(max(minBuf * 2, 32 * 1024))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                throw IllegalStateException("Android refused to start audio capture")
            }
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024)
            }
            val aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            aenc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aenc.start()
            rec.startRecording()
            audioRecord = rec
            audioEnc = aenc
            audioExpected = true
            audioThread = Thread({ audioLoop() }, "capture-audio")
            onAudio(AudioMode.Unknown, null)
        } catch (e: Exception) {
            audioExpected = false
            onAudio(
                AudioMode.Unavailable,
                "Audio capture isn't available (${e.message ?: "blocked by Android or the playing app"}). Only video is recorded.",
            )
        }
    }

    // ---------------------------------------------------------------- video

    private fun videoLoop() {
        val enc = videoEnc ?: return
        val info = MediaCodec.BufferInfo()
        try {
            while (true) {
                if (!running && stopAtUs != 0L && nowUs() - stopAtUs > 4_000_000) break
                // If sound never starts, stop waiting for it so the video is still saved.
                if (!muxerStarted && audioExpected && videoTrack >= 0 && nowUs() - startUs > 4_000_000) {
                    synchronized(lock) {
                        audioExpected = false
                        tryStartMuxer()
                    }
                    onAudio(AudioMode.Unavailable, "Audio capture didn't start, so only video is recorded.")
                }
                val idx = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> synchronized(lock) {
                        if (!muxerStarted) {
                            videoTrack = muxer!!.addTrack(enc.outputFormat)
                            tryStartMuxer()
                        }
                    }
                    idx >= 0 -> {
                        val buf = enc.getOutputBuffer(idx)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        if (buf != null && info.size > 0) onSample(true, buf, info)
                        enc.releaseOutputBuffer(idx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            }
        } catch (e: Exception) {
            onError("Recording stopped: ${e.message ?: "video encoder error"}")
        }
    }

    // ---------------------------------------------------------------- audio

    private fun audioLoop() {
        val rec = audioRecord ?: return
        val enc = audioEnc ?: return
        val info = MediaCodec.BufferInfo()
        val buf = ByteArray(4096)
        var anchorUs = -1L
        var fed = 0L
        var heard = false
        var warned = false
        var lastLevelUs = 0L
        try {
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) {
                    onAudio(AudioMode.Unavailable, "Audio capture stopped (error $n). Only video is kept from now on.")
                    break
                }
                if (n == 0) continue

                var sum = 0.0
                var i = 0
                while (i + 1 < n) {
                    val v = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()
                    sum += v.toDouble() * v
                    i += 2
                }
                val rms = sqrt(sum / max(1, n / 2))
                val now = nowUs()
                if (rms > 3.0 && !heard) {
                    heard = true
                    onAudio(AudioMode.Capturing, null)
                }
                if (!heard && !warned && now - startUs > 10_000_000) {
                    warned = true
                    onAudio(
                        AudioMode.Unavailable,
                        "No sound captured yet. Nothing may be playing, or the app doesn't allow audio capture.",
                    )
                }
                if (now - lastLevelUs > 250_000) {
                    lastLevelUs = now
                    onLevel((20.0 * log10(max(rms, 1.0) / 32768.0)).toFloat())
                }

                if (paused) {
                    anchorUs = -1L
                    continue
                }
                if (anchorUs < 0) {
                    anchorUs = now - (n / 4) * 1_000_000L / SAMPLE_RATE
                    fed = 0L
                }
                val pts = anchorUs + fed * 1_000_000L / SAMPLE_RATE
                fed += n / 4
                val idx = enc.dequeueInputBuffer(20_000)
                if (idx >= 0) {
                    val ib = enc.getInputBuffer(idx)
                    if (ib != null) {
                        ib.clear()
                        val len = minOf(n, ib.remaining())
                        ib.put(buf, 0, len)
                        enc.queueInputBuffer(idx, 0, len, pts, 0)
                    }
                }
                drainAudio(enc, info, 0)
            }
            // end of stream
            val idx = enc.dequeueInputBuffer(50_000)
            if (idx >= 0) enc.queueInputBuffer(idx, 0, 0, nowUs(), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            var tries = 0
            while (tries < 100 && !drainAudio(enc, info, 20_000)) tries++
        } catch (e: Exception) {
            onAudio(AudioMode.Unavailable, "Audio capture stopped (${e.message}). Only video is kept from now on.")
        }
    }

    /** Returns true when the end of the stream was reached. */
    private fun drainAudio(enc: MediaCodec, info: MediaCodec.BufferInfo, timeoutUs: Long): Boolean {
        while (true) {
            val idx = enc.dequeueOutputBuffer(info, timeoutUs)
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> synchronized(lock) {
                    if (!muxerStarted && audioExpected) {
                        audioTrack = muxer!!.addTrack(enc.outputFormat)
                        tryStartMuxer()
                    }
                }
                idx >= 0 -> {
                    val ob = enc.getOutputBuffer(idx)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (ob != null && info.size > 0) onSample(false, ob, info)
                    enc.releaseOutputBuffer(idx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return true
                }
            }
        }
    }

    // ---------------------------------------------------------------- muxer

    private fun tryStartMuxer() {
        if (muxerStarted || videoTrack < 0) return
        if (audioExpected && audioTrack < 0) return
        muxer!!.start()
        muxerStarted = true
        for (p in pending) {
            val track = if (p.video) videoTrack else audioTrack
            if (track < 0) continue
            val bi = MediaCodec.BufferInfo().apply { set(0, p.data.size, p.ptsUs, p.flags) }
            muxer!!.writeSampleData(track, ByteBuffer.wrap(p.data), bi)
            if (p.video) frames++
        }
        pending.clear()
    }

    private fun onSample(video: Boolean, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        synchronized(lock) {
            // Video time stamps come from the display; move them onto the same clock as the audio.
            val raw: Long = if (video) {
                if (videoShiftUs == Long.MIN_VALUE) videoShiftUs = nowUs() - info.presentationTimeUs
                info.presentationTimeUs + videoShiftUs
            } else {
                info.presentationTimeUs
            }
            if (baseUs < 0) baseUs = raw
            if (paused) {
                if (video) needKey = true
                return
            }
            if (video && needKey) {
                if ((info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) == 0) return
                needKey = false
            }
            if (!video && audioTrack < 0 && muxerStarted) return
            var adj = raw - baseUs - pausedTotalUs
            val last = if (video) lastVideoPts else lastAudioPts
            if (adj <= last) adj = last + 1
            if (adj < 0) adj = 0
            if (video) lastVideoPts = adj else lastAudioPts = adj

            buf.position(info.offset)
            buf.limit(info.offset + info.size)
            if (!muxerStarted) {
                if (pending.size < 600) {
                    val bytes = ByteArray(info.size)
                    buf.get(bytes)
                    pending.add(Pending(video, bytes, info.flags, adj))
                }
                return
            }
            info.set(info.offset, info.size, adj, info.flags)
            muxer!!.writeSampleData(if (video) videoTrack else audioTrack, buf, info)
            if (video) frames++
        }
    }

    // ---------------------------------------------------------------- controls

    fun pause() {
        synchronized(lock) {
            if (paused) return
            paused = true
            pauseStartUs = nowUs()
        }
    }

    fun resume() {
        synchronized(lock) {
            if (!paused) return
            pausedTotalUs += nowUs() - pauseStartUs
            paused = false
            needKey = true
        }
        runCatching {
            videoEnc?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        }
    }

    /** Finishes the file. Returns true when the recording contains video. Call from a background thread. */
    fun stop(): Boolean {
        if (!running && muxer == null) return false
        stopAtUs = nowUs()
        running = false
        runCatching { display?.release() }
        runCatching { videoEnc?.signalEndOfInputStream() }
        runCatching { audioThread?.join(5_000) }
        runCatching { videoThread?.join(6_000) }

        runCatching { audioRecord?.stop() }
        runCatching { audioRecord?.release() }
        runCatching { audioEnc?.stop() }
        runCatching { audioEnc?.release() }
        runCatching { videoEnc?.stop() }
        runCatching { videoEnc?.release() }
        runCatching { surface?.release() }

        var ok = false
        synchronized(lock) {
            try {
                if (muxerStarted && frames > 0) {
                    muxer?.stop()
                    ok = true
                }
            } catch (e: Exception) {
                ok = false
            }
            runCatching { muxer?.release() }
            muxer = null
        }
        return ok
    }

    private companion object {
        const val SAMPLE_RATE = 44_100
    }
}
