package com.aiclip.hunter

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.StatFs
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aiclip.hunter.clipping.ClipExporter
import com.aiclip.hunter.capture.CaptureHub
import com.aiclip.hunter.capture.CapturePhase
import com.aiclip.hunter.capture.LiveStatus
import com.aiclip.hunter.capture.LiveUi
import com.aiclip.hunter.capture.ScreenCaptureService
import com.aiclip.hunter.data.settings.ApiKeyStore
import com.aiclip.hunter.engine.youtube.UrlResult
import com.aiclip.hunter.engine.youtube.VideoInfoException
import com.aiclip.hunter.engine.youtube.VideoKind
import com.aiclip.hunter.engine.youtube.YouTubeInfoClient
import com.aiclip.hunter.engine.youtube.YouTubeUrl
import com.aiclip.hunter.data.settings.CaptionStore
import com.aiclip.hunter.domain.models.CaptionStyle
import com.aiclip.hunter.domain.models.CaptionWord
import com.aiclip.hunter.engine.speech.CaptionEngine
import com.aiclip.hunter.data.clips.ClipRepository
import com.aiclip.hunter.data.settings.SettingsRepository
import com.aiclip.hunter.domain.models.AnalysisState
import com.aiclip.hunter.domain.models.AppSettings
import com.aiclip.hunter.domain.models.AspectOption
import com.aiclip.hunter.domain.models.Clip
import com.aiclip.hunter.domain.models.ExportState
import com.aiclip.hunter.domain.models.Highlight
import com.aiclip.hunter.domain.models.SourceVideo
import com.aiclip.hunter.domain.models.StageStatus
import com.aiclip.hunter.engine.audio.AudioAnalyzer
import com.aiclip.hunter.engine.scoring.HighlightDetector
import com.aiclip.hunter.engine.video.VideoMetadataExtractor
import com.aiclip.hunter.engine.vision.SceneAnalyzer
import com.aiclip.hunter.utils.formatTime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.ceil

/** App-level state holder. Analysis and export run while the app is open and can be cancelled. */
class AppViewModel(application: Application) : AndroidViewModel(application) {

    data class ImportState(
        val loading: Boolean = false,
        val video: SourceVideo? = null,
        val error: String? = null,
    )

    private val extractor = VideoMetadataExtractor(application)
    private val audioAnalyzer = AudioAnalyzer(application)
    private val sceneAnalyzer = SceneAnalyzer(application)
    private val exporter = ClipExporter(application)
    private val captionEngine = CaptionEngine(application)
    private val captionStore = CaptionStore(application)
    private val _captionStyle = MutableStateFlow(captionStore.load())
    val captionStyle: StateFlow<CaptionStyle> = _captionStyle.asStateFlow()

    fun updateCaptionStyle(change: (CaptionStyle) -> CaptionStyle) {
        val next = change(_captionStyle.value)
        _captionStyle.value = next
        captionStore.save(next)
    }
    private val clipRepository = ClipRepository(application)
    private val settingsRepository = SettingsRepository(application)

    private val _importState = MutableStateFlow(ImportState())
    val importState: StateFlow<ImportState> = _importState.asStateFlow()

    private val _analysis = MutableStateFlow(AnalysisState())
    val analysis: StateFlow<AnalysisState> = _analysis.asStateFlow()

    private val _highlights = MutableStateFlow<List<Highlight>>(emptyList())
    val highlights: StateFlow<List<Highlight>> = _highlights.asStateFlow()

    private val _clips = MutableStateFlow<List<Clip>>(emptyList())
    val clips: StateFlow<List<Clip>> = _clips.asStateFlow()

    private val _export = MutableStateFlow(ExportState())
    val exportState: StateFlow<ExportState> = _export.asStateFlow()

    /** Start/end (ms) chosen from a highlight, picked up by the clip editor. */
    private val _editorRange = MutableStateFlow<Pair<Long, Long>?>(null)
    val editorRange: StateFlow<Pair<Long, Long>?> = _editorRange.asStateFlow()

    /** Cuts chosen for one montage clip, joined in this order. Empty means "use the slider range". */
    private val _segments = MutableStateFlow<List<Pair<Long, Long>>>(emptyList())
    val segments: StateFlow<List<Pair<Long, Long>>> = _segments.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private companion object {
        const val MAX_CUTS = 10
    }

    // ---------- Live analysis (YouTube link + screen capture) ----------

    private val apiKeyStore = ApiKeyStore(application)
    private val _live = MutableStateFlow(LiveUi(apiKey = apiKeyStore.get()))
    val live: StateFlow<LiveUi> = _live.asStateFlow()
    private val _liveUrl = MutableStateFlow("")
    val liveUrl: StateFlow<String> = _liveUrl.asStateFlow()
    private var liveJob: Job? = null
    private var handledSession = 0L
    private var lastPhase = CapturePhase.Idle

    fun setLiveUrl(url: String) {
        _liveUrl.value = url
    }

    private fun liveLog(msg: String) {
        val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        _live.update { it.copy(log = (it.log + "$t $msg").takeLast(20)) }
    }

    private fun setStatus(status: LiveStatus, error: String? = null) {
        _live.update { it.copy(status = status, error = error) }
    }

    fun setApiKey(key: String) {
        apiKeyStore.set(key)
        _live.update { it.copy(apiKey = key.trim()) }
        liveLog(if (key.isBlank()) "API key removed" else "API key saved")
    }

    fun setAutoClips(on: Boolean) = _live.update { it.copy(autoClips = on) }

    fun setClipCount(n: Int) = _live.update { it.copy(clipCount = n) }

    /** Step 1: check the pasted link and show what YouTube says about it. */
    fun checkLink(text: String) {
        if (_live.value.busy) return
        liveJob?.cancel()
        setLiveUrl(text)
        _live.update { it.copy(status = LiveStatus.ValidatingUrl, error = null, info = null, note = null) }
        when (val r = YouTubeUrl.parse(text)) {
            is UrlResult.Invalid -> {
                setStatus(LiveStatus.WaitingForUrl, r.message)
                liveLog("Link rejected: ${r.message}")
            }
            is UrlResult.Valid -> liveJob = viewModelScope.launch {
                try {
                    val info = YouTubeInfoClient.fetch(r, _live.value.apiKey)
                    _live.update { it.copy(info = info) }
                    if (info.kind == VideoKind.Upcoming) {
                        setStatus(LiveStatus.Error, "This live stream hasn't started yet. Come back when it is live.")
                    } else {
                        setStatus(LiveStatus.VideoDetected)
                    }
                    liveLog("Video ${r.id}: ${info.kind.label}${info.title?.let { " - ${it.take(40)}" } ?: ""}")
                } catch (e: CancellationException) {
                    throw e
                } catch (e: VideoInfoException) {
                    setStatus(LiveStatus.Error, e.message)
                    liveLog("Error: ${e.message}")
                } catch (e: Exception) {
                    setStatus(LiveStatus.Error, "Couldn't check this link (${e.message ?: "unknown error"}).")
                }
            }
        }
    }

    /** Called while Android shows its screen-capture permission dialog. */
    fun capturePermissionPending() {
        setStatus(LiveStatus.WaitingForPermission)
        liveLog("Waiting for screen-capture permission")
    }

    fun capturePermissionDenied() {
        setStatus(LiveStatus.Error, "Screen-capture permission was denied. Nothing is recorded. Tap Start analysis to try again.")
        liveLog("Screen-capture permission denied")
    }

    /** Step 2: the person allowed screen capture, so start the foreground service. Returns true if it started. */
    fun beginCapture(resultCode: Int, data: Intent, audioAllowed: Boolean): Boolean {
        val app = getApplication<Application>()
        val dir = File(app.filesDir, "captures").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val free = runCatching { StatFs(app.filesDir.path).availableBytes }.getOrDefault(Long.MAX_VALUE)
        if (free < 1L * 1024 * 1024 * 1024) {
            setStatus(LiveStatus.Error, "Not enough free storage. Free up at least 1 GB and try again.")
            liveLog("Not enough storage")
            return false
        }
        val file = File(dir, "capture_${System.currentTimeMillis()}.mp4")
        CaptureHub.reset()
        CaptureHub.update { it.copy(phase = CapturePhase.Starting) }
        _live.update { it.copy(clipsMade = 0, clipsTotal = 0, note = null) }
        val intent = Intent(app, ScreenCaptureService::class.java)
            .setAction(ScreenCaptureService.ACTION_START)
            .putExtra(ScreenCaptureService.EXTRA_CODE, resultCode)
            .putExtra(ScreenCaptureService.EXTRA_DATA, data)
            .putExtra(ScreenCaptureService.EXTRA_OUT, file.absolutePath)
            .putExtra(ScreenCaptureService.EXTRA_AUDIO, audioAllowed)
        return try {
            ContextCompat.startForegroundService(app, intent)
            true
        } catch (e: Exception) {
            setStatus(LiveStatus.Error, "Android didn't allow the capture to start (${e.message}). Check that background restrictions are off for this app.")
            false
        }
    }

    private fun sendCaptureAction(action: String) {
        val app = getApplication<Application>()
        runCatching { app.startService(Intent(app, ScreenCaptureService::class.java).setAction(action)) }
    }

    fun pauseCapture() = sendCaptureAction(ScreenCaptureService.ACTION_PAUSE)

    fun resumeCapture() = sendCaptureAction(ScreenCaptureService.ACTION_RESUME)

    fun stopCapture() = sendCaptureAction(ScreenCaptureService.ACTION_STOP)

    private fun onCapture(cs: com.aiclip.hunter.capture.CaptureState) {
        _live.update { u ->
            val status = when (cs.phase) {
                CapturePhase.Recording -> LiveStatus.CaptureActive
                CapturePhase.Paused -> LiveStatus.CapturePaused
                CapturePhase.Starting -> LiveStatus.WaitingForPermission
                else -> u.status
            }
            u.copy(capture = cs, status = status)
        }
        if (cs.phase != lastPhase) {
            when (cs.phase) {
                CapturePhase.Recording -> liveLog("Screen capture started")
                CapturePhase.Paused -> liveLog("Capture paused")
                CapturePhase.Stopping -> liveLog(cs.message ?: "Stopping capture")
                CapturePhase.Failed -> {
                    liveLog("Capture failed: ${cs.message}")
                    setStatus(LiveStatus.Error, cs.message)
                }
                else -> Unit
            }
            lastPhase = cs.phase
        }
        val file = cs.file
        if (cs.phase == CapturePhase.Finished && file != null && cs.sessionId != handledSession) {
            handledSession = cs.sessionId
            analyseCapture(file)
        }
    }

    /** Step 3: the recording is saved, so find moments with the same engine used for imported videos. */
    private fun analyseCapture(file: File) {
        liveJob?.cancel()
        liveJob = viewModelScope.launch {
            try {
                setStatus(LiveStatus.Analyzing)
                liveLog("Recording saved. Analysing…")
                importVideo(Uri.fromFile(file))
                val imported = _importState.first { it.video != null || it.error != null }
                if (imported.video == null) {
                    setStatus(LiveStatus.Error, imported.error ?: "The recording couldn't be read.")
                    return@launch
                }
                startAnalysis()
                val result = _analysis.first { it.finished || it.error != null }
                if (result.error != null) {
                    setStatus(LiveStatus.Error, result.error)
                    return@launch
                }
                val found = _highlights.value
                if (found.isEmpty()) {
                    _live.update { it.copy(note = "No clear highlights were found in this recording.") }
                    setStatus(LiveStatus.Completed)
                    liveLog("No moments found")
                    return@launch
                }
                setStatus(LiveStatus.MomentsDetected)
                liveLog("${found.size} moments found")
                if (_live.value.autoClips) runClipGeneration(_live.value.clipCount)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setStatus(LiveStatus.Error, "Analysis failed: ${e.message ?: "unknown error"}")
            }
        }
    }

    /** Makes clips from the best moments, using the normal exporter (so captions and quality settings apply). */
    fun generateClips() {
        if (_live.value.status == LiveStatus.GeneratingClips || _highlights.value.isEmpty()) return
        liveJob = viewModelScope.launch { runClipGeneration(_live.value.clipCount) }
    }

    private suspend fun runClipGeneration(count: Int) {
        val top = _highlights.value.sortedByDescending { it.score }.take(count).sortedBy { it.startMs }
        if (top.isEmpty()) return
        setStatus(LiveStatus.GeneratingClips)
        _live.update { it.copy(clipsTotal = top.size, clipsMade = 0) }
        var made = 0
        for ((i, h) in top.withIndex()) {
            exportClips(listOf(h.startMs to h.endMs), settings.value.defaultAspect)
            exportJob?.join()
            val err = _export.value.error
            if (err != null) {
                liveLog("Clip ${i + 1} failed: $err")
            } else {
                made++
                liveLog("Clip ${i + 1} of ${top.size} saved")
            }
            _live.update { it.copy(clipsMade = made) }
        }
        setStatus(LiveStatus.Completed)
        liveLog("$made clips saved to your Library")
    }

    /** Opens a clip saved from a live moment in the normal editor flow. */
    fun openClip(file: File) {
        importVideo(Uri.fromFile(file))
    }

    private var importJob: Job? = null
    private var analysisJob: Job? = null
    private var exportJob: Job? = null

    init {
        refreshClips()
        viewModelScope.launch { CaptureHub.state.collect { onCapture(it) } }
    }

    // ---------- Import ----------

    fun importVideo(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        resetProject()
        _importState.value = ImportState(loading = true)
        importJob = viewModelScope.launch {
            extractor.extract(uri).fold(
                onSuccess = { _importState.value = ImportState(video = it) },
                onFailure = { _importState.value = ImportState(error = it.message ?: "This file couldn't be read.") },
            )
        }
    }

    fun clearVideo() {
        importJob?.cancel()
        resetProject()
        _importState.value = ImportState()
    }

    private fun resetProject() {
        analysisJob?.cancel()
        exportJob?.cancel()
        _analysis.value = AnalysisState()
        _highlights.value = emptyList()
        _editorRange.value = null
        _segments.value = emptyList()
        _export.value = ExportState()
    }

    // ---------- Analysis ----------

    fun startAnalysis() {
        val video = _importState.value.video ?: return
        if (_analysis.value.running) return
        val weights = settings.value.weights
        val clipSec = settings.value.clipDurationSec

        analysisJob = viewModelScope.launch {
            _highlights.value = emptyList()
            _analysis.value = AnalysisState(running = true, stage = "Analysing audio", audio = StageStatus.Running)

            var audio: FloatArray? = null
            var audioStatus = StageStatus.Skipped
            if (video.hasAudio) {
                audio = try {
                    audioAnalyzer.analyze(video.uri, video.durationMs) { p ->
                        _analysis.update { it.copy(progress = p * 0.5f) }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    null
                }
                audioStatus = if (audio != null) StageStatus.Done else StageStatus.Failed
            }

            _analysis.update {
                it.copy(progress = 0.5f, stage = "Analysing scenes", audio = audioStatus, visual = StageStatus.Running)
            }
            val stepSec = ceil(video.durationMs / 1000.0 / 300.0).toInt().coerceAtLeast(1)
            val visual = try {
                sceneAnalyzer.analyze(video.uri, video.durationMs, stepSec) { p ->
                    _analysis.update { it.copy(progress = 0.5f + p * 0.5f) }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            val visualStatus = if (visual != null) StageStatus.Done else StageStatus.Failed

            _analysis.update { it.copy(stage = "Scoring moments") }
            val found = if (audio == null && visual == null) {
                emptyList()
            } else {
                HighlightDetector.detect(video.durationMs, audio, visual, stepSec, weights, clipSec)
            }
            _highlights.value = found

            _analysis.value = AnalysisState(
                finished = true,
                progress = 1f,
                stage = when {
                    audio == null && visual == null -> "Couldn't analyse this video"
                    found.isEmpty() -> "No clear highlights found"
                    else -> "Done"
                },
                audio = audioStatus,
                visual = visualStatus,
                error = if (audio == null && visual == null) "Neither audio nor video frames could be read from this file." else null,
            )
        }
    }

    fun cancelAnalysis() {
        analysisJob?.cancel()
        _analysis.value = AnalysisState(stage = "Cancelled")
    }

    fun addSegment(startMs: Long, endMs: Long) {
        if (endMs - startMs < 1000 || _segments.value.size >= MAX_CUTS) return
        _segments.update { it + (startMs to endMs) }
    }

    fun removeSegment(index: Int) {
        _segments.update { list -> list.filterIndexed { i, _ -> i != index } }
    }

    fun clearSegments() {
        _segments.value = emptyList()
    }

    fun toggleHighlight(h: Highlight) {
        val range = h.startMs to h.endMs
        if (_segments.value.contains(range)) _segments.update { it - range } else addSegment(h.startMs, h.endMs)
    }

    fun openHighlight(h: Highlight) {
        _editorRange.value = h.startMs to h.endMs
    }

    // ---------- Export ----------

    fun exportClips(parts: List<Pair<Long, Long>>, aspect: AspectOption) {
        val video = _importState.value.video ?: return
        if (_export.value.running || parts.isEmpty() || parts.any { it.second - it.first < 1000 }) return
        val startMs = parts.first().first
        val totalMs = parts.sumOf { it.second - it.first }
        val app = getApplication<Application>()

        exportJob = viewModelScope.launch {
            if (StatFs(app.cacheDir.path).availableBytes < 300L * 1024 * 1024) {
                _export.value = ExportState(error = "Not enough free storage. Free up at least 300 MB and try again.")
                return@launch
            }
            _export.value = ExportState(running = true, message = "Exporting…")
            val temp = File(app.cacheDir, "export_${System.currentTimeMillis()}.mp4")
            val capStyle = _captionStyle.value
            var capWords: List<CaptionWord> = emptyList()
            var capNote: String? = null
            if (capStyle.enabled) {
                try {
                    if (!captionEngine.isReady(capStyle.language)) {
                        _export.value = ExportState(running = true, message = "Downloading speech model (one time)…")
                        captionEngine.ensureModel(capStyle.language) { p -> _export.update { it.copy(progress = p) } }
                    }
                    _export.value = ExportState(running = true, message = "Writing captions…")
                    capWords = captionEngine.transcribe(video.uri, parts, capStyle.language) { p ->
                        _export.update { it.copy(progress = p) }
                    }
                    if (capWords.isEmpty()) capNote = "No speech was found, so no captions were added."
                } catch (e: CancellationException) {
                    _export.value = ExportState(message = "Export cancelled.")
                    temp.delete()
                    throw e
                } catch (e: Throwable) {
                    capNote = "Captions were skipped: ${e.message ?: "speech recognition failed"}."
                }
                _export.value = ExportState(running = true, message = "Exporting…")
            }
            try {
                val result = exporter.export(video.uri, parts, aspect, settings.value.quality, temp, capWords, capStyle) { p ->
                    _export.update { it.copy(progress = p) }
                }
                if (result.isSuccess) {
                    val base = video.displayName.substringBeforeLast('.')
                    val suffix = if (parts.size > 1) "montage ${parts.size} cuts" else formatTime(startMs).replace(':', '-')
                    val name = "$base $suffix".replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    val clip = clipRepository.save(temp, name, totalMs)
                    _clips.value = listOf(clip) + _clips.value
                    _export.value = ExportState(
                        message = "Saved to Movies/AIClipHunter. Find it in your Library." + (capNote?.let { " $it" } ?: ""),
                    )
                } else {
                    _export.value = ExportState(error = result.exceptionOrNull()?.message ?: "Export failed.")
                }
            } catch (e: CancellationException) {
                _export.value = ExportState(message = "Export cancelled.")
                throw e
            } catch (e: Exception) {
                _export.value = ExportState(error = e.message ?: "Export failed.")
            } finally {
                temp.delete()
            }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
    }

    // ---------- Library ----------

    fun refreshClips() {
        viewModelScope.launch {
            val list = try {
                clipRepository.list()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (list != null) _clips.value = list
        }
    }

    fun renameClip(clip: Clip, title: String) {
        val clean = title.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (clean.isEmpty()) return
        viewModelScope.launch {
            runCatching { clipRepository.rename(clip, clean) }
            refreshClips()
        }
    }

    fun deleteClip(clip: Clip) {
        viewModelScope.launch {
            runCatching { clipRepository.delete(clip) }
            _clips.value = _clips.value.filterNot { it.id == clip.id }
        }
    }

    // ---------- Settings ----------

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepository.save(transform(settings.value)) }
    }
}
