package com.aiclip.hunter.engine.youtube

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

enum class VideoKind(val label: String) {
    Live("Live now"),
    Upcoming("Upcoming live stream"),
    CompletedStream("Finished live stream"),
    Regular("Video"),
    Unknown("Type unknown"),
}

data class VideoInfo(
    val id: String,
    val canonicalUrl: String,
    val title: String?,
    val channel: String?,
    val kind: VideoKind,
    val viewers: Long?,
    val scheduledStart: String?,
    val ageRestricted: Boolean,
    val fromApi: Boolean,
    val note: String?,
)

class VideoInfoException(message: String) : Exception(message)

/**
 * Details about a video. Uses the YouTube Data API v3 when the person added a key,
 * and YouTube's public oEmbed address (title and channel only) when not.
 */
object YouTubeInfoClient {

    private class Reply(val code: Int, val body: String)

    private fun request(url: String): Reply {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 12_000
        c.setRequestProperty("Accept", "application/json")
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            return Reply(code, stream?.use { String(it.readBytes(), Charsets.UTF_8) }.orEmpty())
        } finally {
            c.disconnect()
        }
    }

    suspend fun fetch(link: UrlResult.Valid, apiKey: String): VideoInfo = withContext(Dispatchers.IO) {
        try {
            if (apiKey.isBlank()) {
                fromOEmbed(link, "Add a free YouTube API key to see whether this is live, upcoming or a finished stream.")
            } else {
                fromApi(link, apiKey.trim())
            }
        } catch (e: IOException) {
            throw VideoInfoException("Couldn't reach YouTube. Check your internet connection.")
        }
    }

    private fun fromApi(link: UrlResult.Valid, key: String): VideoInfo {
        val url = "https://www.googleapis.com/youtube/v3/videos?part=snippet,liveStreamingDetails,contentDetails,status" +
            "&id=${link.id}&key=${Uri.encode(key)}"
        val r = request(url)
        if (r.code !in 200..299) {
            val err = runCatching { JSONObject(r.body).optJSONObject("error") }.getOrNull()
            val reason = err?.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty()
            val msg = err?.optString("message").orEmpty()
            val note = when {
                reason in setOf("quotaExceeded", "dailyLimitExceeded", "rateLimitExceeded") ->
                    "The YouTube API quota is used up for today, so details are limited. It resets at midnight Pacific Time."
                reason == "keyInvalid" || msg.contains("API key not valid", ignoreCase = true) ->
                    "The YouTube API key isn't valid, so details are limited."
                reason in setOf("accessNotConfigured", "forbidden") || msg.contains("has not been used", ignoreCase = true) ->
                    "YouTube Data API v3 isn't enabled for this key, so details are limited."
                else -> "The YouTube API returned an error (HTTP ${r.code}), so details are limited."
            }
            return fromOEmbed(link, note)
        }

        val items = JSONObject(r.body).optJSONArray("items")
        if (items == null || items.length() == 0) {
            throw VideoInfoException("This video is unavailable. It may be private, deleted or blocked in your country.")
        }
        val item = items.getJSONObject(0)
        val sn = item.optJSONObject("snippet")
        val lsd = item.optJSONObject("liveStreamingDetails")
        val privacy = item.optJSONObject("status")?.optString("privacyStatus").orEmpty()
        if (privacy == "private") throw VideoInfoException("This video is private.")
        val age = item.optJSONObject("contentDetails")?.optJSONObject("contentRating")
            ?.optString("ytRating") == "ytAgeRestricted"
        val lbc = sn?.optString("liveBroadcastContent").orEmpty()
        val kind = when {
            lbc == "live" -> VideoKind.Live
            lbc == "upcoming" -> VideoKind.Upcoming
            lsd != null && (lsd.has("actualStartTime") || lsd.has("actualEndTime")) -> VideoKind.CompletedStream
            else -> VideoKind.Regular
        }
        val notes = ArrayList<String>()
        if (age) notes.add("This video is age-restricted. Capturing it may show a sign-in screen instead of the video.")
        if (kind == VideoKind.CompletedStream) notes.add("This live stream has ended, so it plays like a normal video.")
        return VideoInfo(
            id = link.id,
            canonicalUrl = link.canonical,
            title = sn?.optString("title")?.takeIf { it.isNotBlank() },
            channel = sn?.optString("channelTitle")?.takeIf { it.isNotBlank() },
            kind = kind,
            viewers = lsd?.optString("concurrentViewers")?.toLongOrNull(),
            scheduledStart = lsd?.optString("scheduledStartTime")?.takeIf { it.isNotBlank() },
            ageRestricted = age,
            fromApi = true,
            note = notes.joinToString(" ").ifBlank { null },
        )
    }

    private fun fromOEmbed(link: UrlResult.Valid, note: String): VideoInfo {
        val r = request("https://www.youtube.com/oembed?format=json&url=${Uri.encode(link.canonical)}")
        when (r.code) {
            in 200..299 -> {
                val o = JSONObject(r.body)
                return VideoInfo(
                    id = link.id,
                    canonicalUrl = link.canonical,
                    title = o.optString("title").takeIf { it.isNotBlank() },
                    channel = o.optString("author_name").takeIf { it.isNotBlank() },
                    kind = VideoKind.Unknown,
                    viewers = null,
                    scheduledStart = null,
                    ageRestricted = false,
                    fromApi = false,
                    note = note,
                )
            }
            404 -> throw VideoInfoException("This video is unavailable. It may be private, deleted or not exist.")
            401, 403 -> return VideoInfo(
                id = link.id,
                canonicalUrl = link.canonical,
                title = null,
                channel = null,
                kind = VideoKind.Unknown,
                viewers = null,
                scheduledStart = null,
                ageRestricted = false,
                fromApi = false,
                note = "YouTube won't share details for this video. It may be age-restricted or have embedding turned off. You can still try to capture it.",
            )
            else -> throw VideoInfoException("YouTube couldn't check this link right now (HTTP ${r.code}). Try again in a moment.")
        }
    }
}
