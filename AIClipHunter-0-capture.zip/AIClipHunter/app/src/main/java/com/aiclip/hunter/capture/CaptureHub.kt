package com.aiclip.hunter.capture

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

enum class CapturePhase { Idle, Starting, Recording, Paused, Stopping, Finished, Failed }

enum class AudioMode { Unknown, Capturing, Unavailable }

data class CaptureState(
    val sessionId: Long = 0L,
    val phase: CapturePhase = CapturePhase.Idle,
    val elapsedMs: Long = 0L,
    val bytes: Long = 0L,
    val audio: AudioMode = AudioMode.Unknown,
    val audioNote: String? = null,
    val levelDb: Float? = null,
    val file: File? = null,
    val message: String? = null,
)

/** Shared between the capture service and the screens. */
object CaptureHub {
    private val _state = MutableStateFlow(CaptureState())
    val state: StateFlow<CaptureState> = _state.asStateFlow()

    fun update(change: (CaptureState) -> CaptureState) {
        _state.update(change)
    }

    fun reset() {
        _state.value = CaptureState()
    }
}
