package com.aiclip.hunter.clipping

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import com.aiclip.hunter.domain.models.CaptionAnimation
import com.aiclip.hunter.domain.models.CaptionStyle
import com.aiclip.hunter.domain.models.CaptionWord

/**
 * Full-frame transparent picture that changes with the video time, so the captions are burned
 * into the exported file. [words] are on the exported clip's timeline.
 */
@OptIn(UnstableApi::class)
class CaptionOverlay(
    words: List<CaptionWord>,
    private val cs: CaptionStyle,
    private val frameW: Int,
    private val frameH: Int,
) : BitmapOverlay() {

    private val renderer = CaptionRenderer(cs, frameW, frameH)
    private val pages = CaptionRenderer.buildPages(words, cs.wordsPerLine)
    private val empty: Bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

    private var lastPage = -1
    private var lastWord = -1
    private var lastPhase = -1L
    private var last: Bitmap = empty

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val t = presentationTimeUs / 1000
        val idx = pages.indexOfFirst { t >= it.startMs && t < it.endMs }
        if (idx < 0) {
            lastPage = -1
            last = empty
            return empty
        }
        val page = pages[idx]
        var cur = 0
        for (i in page.words.indices) if (page.words[i].startMs <= t) cur = i
        val moving = cs.animation != CaptionAnimation.None && cs.animation != CaptionAnimation.Karaoke
        val active = t - page.words[cur].startMs < 450 || t - page.startMs < 450 || page.endMs - t < 350
        val phase = if (moving && active) t / 50 else 0L
        if (idx == lastPage && cur == lastWord && phase == lastPhase) return last
        val bmp = Bitmap.createBitmap(frameW, frameH, Bitmap.Config.ARGB_8888)
        renderer.draw(Canvas(bmp), page, t)
        lastPage = idx
        lastWord = cur
        lastPhase = phase
        last = bmp
        return bmp
    }
}
