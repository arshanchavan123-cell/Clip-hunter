package com.aiclip.hunter.ui.live

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.capture.AudioMode
import com.aiclip.hunter.capture.CapturePhase
import com.aiclip.hunter.capture.LiveStatus
import com.aiclip.hunter.domain.models.Highlight
import com.aiclip.hunter.engine.youtube.VideoKind
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.GradientButton
import com.aiclip.hunter.ui.components.RangePlayerDialog
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.SecondaryButton
import com.aiclip.hunter.ui.components.SectionTitle
import com.aiclip.hunter.ui.components.StatusPill
import com.aiclip.hunter.ui.theme.Brand
import com.aiclip.hunter.utils.formatBytes
import com.aiclip.hunter.utils.formatTime
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveScreen(vm: AppViewModel, onBack: () -> Unit, onOpenEditor: () -> Unit) {
    val ui by vm.live.collectAsStateWithLifecycle()
    val saved by vm.liveUrl.collectAsStateWithLifecycle()
    val highlights by vm.highlights.collectAsStateWithLifecycle()
    val importState by vm.importState.collectAsStateWithLifecycle()
    val export by vm.exportState.collectAsStateWithLifecycle()

    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var url by rememberSaveable(saved) { mutableStateOf(saved) }
    var allowed by rememberSaveable { mutableStateOf(false) }
    var keyText by rememberSaveable(ui.apiKey) { mutableStateOf(ui.apiKey) }
    var audioGranted by remember { mutableStateOf(false) }
    var previewing by remember { mutableStateOf<Highlight?>(null) }
    var localError by rememberSaveable { mutableStateOf<String?>(null) }

    // Keep the screen awake while capturing, so the video keeps playing.
    val capturing = ui.status == LiveStatus.CaptureActive
    val view = LocalView.current
    DisposableEffect(capturing) {
        view.keepScreenOn = capturing
        onDispose { view.keepScreenOn = false }
    }

    val openYoutube = {
        val link = ui.info?.canonicalUrl
        if (link != null) {
            runCatching {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == Activity.RESULT_OK && data != null) {
            if (vm.beginCapture(res.resultCode, data, audioGranted)) {
                scope.launch {
                    delay(1500) // let the capture service start before YouTube comes to the front
                    openYoutube()
                }
            }
        } else {
            vm.capturePermissionDenied()
        }
    }

    val askProjection = {
        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            mpm.createScreenCaptureIntent()
        }
        projectionLauncher.launch(intent)
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        audioGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        askProjection()
    }

    val check = {
        localError = null
        vm.checkLink(url)
    }

    val start = {
        localError = when {
            !allowed -> "Confirm that you own this video or have permission to process it."
            else -> null
        }
        if (localError == null) {
            val wanted = buildList {
                add(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            }
            val missing = wanted.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
            vm.capturePermissionPending()
            if (missing.isEmpty()) {
                audioGranted = true
                askProjection()
            } else {
                permissionLauncher.launch(missing.toTypedArray())
            }
        }
    }

    val shownError = localError ?: ui.error

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ScreenHeader("Live analysis", onBack = onBack) }

        // ------------------------------------------------------------ link
        item {
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("Stream link")
                    if (ui.status == LiveStatus.CaptureActive) StatusPill("Recording", Brand.Success)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Paste a YouTube video or live link. The app records your screen while it plays, then finds the best moments. Use only videos you own or have permission to process.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; localError = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    enabled = !ui.busy,
                    shape = RoundedCornerShape(16.dp),
                    placeholder = { Text("YouTube link") },
                    leadingIcon = { Icon(Icons.Rounded.Link, contentDescription = null) },
                    isError = shownError != null && !ui.busy,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { if (!ui.busy) check() }),
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "I own this video or have permission to process it.",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Switch(checked = allowed, onCheckedChange = { allowed = it; localError = null }, enabled = !ui.busy)
                }
                Spacer(Modifier.height(12.dp))

                if (ui.status == LiveStatus.CaptureActive || ui.status == LiveStatus.CapturePaused) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (ui.status == LiveStatus.CapturePaused) {
                            SecondaryButton("Resume", onClick = { vm.resumeCapture() }, modifier = Modifier.weight(1f), icon = Icons.Rounded.PlayArrow)
                        } else {
                            SecondaryButton("Pause", onClick = { vm.pauseCapture() }, modifier = Modifier.weight(1f), icon = Icons.Rounded.Pause)
                        }
                        GradientButton("Stop", onClick = { vm.stopCapture() }, modifier = Modifier.weight(1f), icon = Icons.Rounded.Stop)
                    }
                } else if (!ui.busy) {
                    SecondaryButton("Check link", onClick = { check() }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Link)
                    Spacer(Modifier.height(8.dp))
                    GradientButton(
                        "Start analysis",
                        onClick = { start() },
                        modifier = Modifier.fillMaxWidth(),
                        icon = Icons.Rounded.Sensors,
                        enabled = ui.canStart,
                    )
                    if (ui.info == null) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Check the link first. Android will then ask for audio and notification access, and for screen capture. Choose the entire screen.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                shownError?.let {
                    Spacer(Modifier.height(10.dp))
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                }
            }
        }

        // ------------------------------------------------------------ video details
        ui.info?.let { info ->
            item {
                AppCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        SectionTitle("Video")
                        val color = when (info.kind) {
                            VideoKind.Live -> Color(0xFFEF4444)
                            VideoKind.Upcoming -> Brand.Warning
                            VideoKind.CompletedStream, VideoKind.Regular -> Brand.Cyan
                            VideoKind.Unknown -> Brand.TextSecondary
                        }
                        StatusPill(info.kind.label, color)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(info.title ?: "Title not available", style = MaterialTheme.typography.titleMedium)
                    info.channel?.let {
                        Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    info.viewers?.let {
                        Text("$it watching now", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    info.note?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            AppCard {
                SectionTitle("YouTube API key (optional)")
                Spacer(Modifier.height(4.dp))
                Text(
                    "A free key from Google Cloud (YouTube Data API v3) lets the app tell live, upcoming and finished streams apart. Without it, only the title is shown. The key stays on this phone.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = keyText,
                    onValueChange = { keyText = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    enabled = !ui.busy,
                    shape = RoundedCornerShape(16.dp),
                    placeholder = { Text("API key") },
                )
                Spacer(Modifier.height(8.dp))
                SecondaryButton("Save key", onClick = { vm.setApiKey(keyText) }, modifier = Modifier.fillMaxWidth(), enabled = !ui.busy && keyText.trim() != ui.apiKey)
            }
        }

        // ------------------------------------------------------------ status
        item {
            AppCard {
                SectionTitle("Status")
                Spacer(Modifier.height(8.dp))
                val statusColor = when (ui.status) {
                    LiveStatus.Error -> MaterialTheme.colorScheme.error
                    LiveStatus.Completed, LiveStatus.MomentsDetected, LiveStatus.CaptureActive -> Brand.Success
                    LiveStatus.WaitingForUrl -> Brand.TextSecondary
                    else -> Brand.Cyan
                }
                IndicatorRow("Status", ui.status.label, statusColor)
                val phaseText = when (ui.capture.phase) {
                    CapturePhase.Idle -> "Not started"
                    CapturePhase.Starting -> "Starting"
                    CapturePhase.Recording -> "Recording"
                    CapturePhase.Paused -> "Paused"
                    CapturePhase.Stopping -> "Finishing"
                    CapturePhase.Finished -> "Saved"
                    CapturePhase.Failed -> "Stopped"
                }
                IndicatorRow("Screen capture", phaseText, if (ui.capture.phase == CapturePhase.Recording) Brand.Success else Brand.TextSecondary)
                val audioText = when (ui.capture.audio) {
                    AudioMode.Unknown -> if (ui.capture.phase == CapturePhase.Idle) "Not started" else "Listening"
                    AudioMode.Capturing -> "Capturing"
                    AudioMode.Unavailable -> "Unavailable"
                }
                IndicatorRow("Audio capture", audioText, if (ui.capture.audio == AudioMode.Capturing) Brand.Success else Brand.TextSecondary)
                IndicatorRow("Recorded", "${formatTime(ui.capture.elapsedMs)}  ·  ${formatBytes(ui.capture.bytes)}", Brand.Cyan)
                IndicatorRow("Sound", ui.capture.levelDb?.let { "${it.toInt()} dB" } ?: "No data", Brand.TextSecondary)
                ui.capture.audioNote?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(8.dp))
                Text("Sound level", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (((ui.capture.levelDb ?: -60f) + 60f) / 60f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = Brand.Violet,
                )
                if (ui.status == LiveStatus.GeneratingClips || ui.clipsTotal > 0) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Clips: ${ui.clipsMade} of ${ui.clipsTotal}" + (export.message?.takeIf { export.running }?.let { "  ·  $it" } ?: ""),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    if (export.running) {
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(progress = { export.progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Brand.Violet)
                    }
                }
            }
        }

        // ------------------------------------------------------------ moments
        item {
            AppCard {
                SectionTitle("Moments")
                Spacer(Modifier.height(4.dp))
                if (highlights.isEmpty()) {
                    Text(
                        ui.note ?: if (ui.busy) "Moments appear here after you stop the recording." else "Moments found in a recording appear here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Make clips automatically", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = ui.autoClips, onCheckedChange = { vm.setAutoClips(it) }, enabled = !ui.busy)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Clips:", style = MaterialTheme.typography.bodyMedium)
                        listOf(3, 5, 8).forEach { n ->
                            FilterChip(selected = ui.clipCount == n, onClick = { vm.setClipCount(n) }, label = { Text("$n") }, enabled = !ui.busy)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    GradientButton(
                        "Generate clips now",
                        onClick = { vm.generateClips() },
                        modifier = Modifier.fillMaxWidth(),
                        icon = Icons.Rounded.ContentCut,
                        enabled = !ui.busy,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Clip length and captions follow your Settings and the Auto captions options in the editor. Clips are saved on this phone only.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        val sorted = highlights.sortedBy { it.startMs }
        items(sorted.size) { i ->
            val h = sorted[i]
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${formatTime(h.startMs)} – ${formatTime(h.endMs)}", style = MaterialTheme.typography.titleMedium)
                    StatusPill("${h.score}%", if (h.score >= 70) Brand.Success else Brand.Warning)
                }
                Text(
                    "${h.category.label}  ·  ${(h.endMs - h.startMs) / 1000} s",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SecondaryButton("Preview", onClick = { previewing = h }, modifier = Modifier.weight(1f), icon = Icons.Rounded.PlayArrow, enabled = importState.video != null)
                    GradientButton(
                        "Edit",
                        onClick = {
                            vm.openHighlight(h)
                            onOpenEditor()
                        },
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.ContentCut,
                        enabled = importState.video != null && !ui.busy,
                    )
                }
            }
        }

        // ------------------------------------------------------------ log
        item {
            AppCard {
                SectionTitle("Activity log")
                Spacer(Modifier.height(6.dp))
                if (ui.log.isEmpty()) {
                    Text("Nothing yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Column {
                        ui.log.forEach {
                            Text(
                                it,
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }

    val playing = previewing
    val video = importState.video
    if (playing != null && video != null) {
        RangePlayerDialog(video.uri, playing.startMs, playing.endMs) { previewing = null }
    }
}

@Composable
private fun IndicatorRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = color)
    }
}
