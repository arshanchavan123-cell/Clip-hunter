package com.aiclip.hunter.navigation

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.ui.analyzer.AnalysisScreen
import com.aiclip.hunter.ui.discover.DiscoverScreen
import com.aiclip.hunter.ui.editor.EditorScreen
import com.aiclip.hunter.ui.highlights.HighlightsScreen
import com.aiclip.hunter.ui.home.HomeScreen
import com.aiclip.hunter.ui.library.LibraryScreen
import com.aiclip.hunter.ui.live.LiveScreen
import com.aiclip.hunter.ui.settings.SettingsScreen
import com.aiclip.hunter.ui.splash.SplashScreen
import com.aiclip.hunter.ui.theme.Brand

object Routes {
    const val Splash = "splash"
    const val Home = "home"
    const val Discover = "discover"
    const val Library = "library"
    const val Settings = "settings"
    const val Analysis = "analysis"
    const val Highlights = "highlights"
    const val Editor = "editor"
    const val Live = "live"
}

private data class NavItem(val route: String, val label: String, val icon: ImageVector)

private val navItems = listOf(
    NavItem(Routes.Home, "Home", Icons.Rounded.Home),
    NavItem(Routes.Discover, "Discover", Icons.Rounded.Explore),
    NavItem(Routes.Library, "Library", Icons.Rounded.VideoLibrary),
    NavItem(Routes.Settings, "Settings", Icons.Rounded.Settings),
)

@Composable
fun AppNavigation(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    // System file picker: access is limited to the file the person chooses, so no storage permission is needed.
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            vm.importVideo(uri)
            nav.navigate(Routes.Analysis) { launchSingleTop = true }
        }
    }
    val importVideo: () -> Unit = { picker.launch(arrayOf("video/*")) }

    val goBack: () -> Unit = { nav.popBackStack() }
    val open: (String) -> Unit = { route -> nav.navigate(route) { launchSingleTop = true } }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (navItems.any { it.route == currentRoute }) {
                NavigationBar {
                    navItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                nav.navigate(item.route) {
                                    popUpTo(Routes.Home) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Color.White,
                                indicatorColor = Brand.Violet.copy(alpha = 0.30f),
                                unselectedIconColor = Brand.TextSecondary,
                                unselectedTextColor = Brand.TextSecondary,
                            ),
                        )
                    }
                }
            }
        },
    ) { inner ->
        NavHost(
            navController = nav,
            startDestination = Routes.Splash,
            modifier = Modifier.padding(inner),
            enterTransition = { fadeIn(tween(220)) },
            exitTransition = { fadeOut(tween(160)) },
            popEnterTransition = { fadeIn(tween(220)) },
            popExitTransition = { fadeOut(tween(160)) },
        ) {
            composable(Routes.Splash) {
                SplashScreen {
                    nav.navigate(Routes.Home) { popUpTo(Routes.Splash) { inclusive = true } }
                }
            }
            composable(Routes.Home) {
                HomeScreen(
                    vm = vm,
                    onImport = importVideo,
                    onOpenLive = { open(Routes.Live) },
                    onOpenAnalysis = { open(Routes.Analysis) },
                    onOpenHighlights = { open(Routes.Highlights) },
                    onOpenEditor = { open(Routes.Editor) },
                )
            }
            composable(Routes.Discover) { DiscoverScreen(onImport = importVideo, onOpenLive = { open(Routes.Live) }) }
            composable(Routes.Library) { LibraryScreen(vm = vm, onImport = importVideo) }
            composable(Routes.Settings) { SettingsScreen(vm = vm) }
            composable(Routes.Analysis) {
                AnalysisScreen(
                    vm = vm,
                    onBack = goBack,
                    onImport = importVideo,
                    onOpenEditor = { open(Routes.Editor) },
                    onOpenHighlights = { open(Routes.Highlights) },
                )
            }
            composable(Routes.Highlights) {
                HighlightsScreen(vm = vm, onBack = goBack, onImport = importVideo, onOpenEditor = { open(Routes.Editor) })
            }
            composable(Routes.Editor) {
                EditorScreen(
                    vm = vm,
                    onBack = goBack,
                    onImport = importVideo,
                    onOpenLibrary = {
                        nav.navigate(Routes.Library) {
                            popUpTo(Routes.Home) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                )
            }
            composable(Routes.Live) { LiveScreen(vm = vm, onBack = goBack, onOpenEditor = { open(Routes.Editor) }) }
        }
    }
}
