package com.aiclip.hunter.ui.editor

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.domain.models.AspectOption
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.EmptyState
import com.aiclip.hunter.ui.components.GradientButton
import com.aiclip.hunter.ui.components.RangePlayerDialog
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.SecondaryButton
import com.aiclip.hunter.ui.components.SectionTitle
import com.aiclip.hunter.clipping.CaptionRenderer
import com.aiclip.hunter.ui.components.VideoThumbnail
import com.aiclip.hunter.ui.theme.Brand
import com.aiclip.hunter.utils.formatTime

private fun initialRange(chosen: Pair<Long, Long>?, durationSec: Float, defaultSec: Int): ClosedFloatingPointRange<Float> {
    if (chosen != null) {
        return (chosen.first / 1000f).coerceIn(0f, durationSec)..(chosen.second / 1000f).coerceIn(0f, durationSec)
    }
    return 0f..minOf(durationSec, defaultSec.toFloat())
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: AppViewModel, onBack: () -> Unit, onImport: () -> Unit, onOpenLibrary: () -> Unit) {
    val state by vm.importState.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val export by vm.exportState.collectAsStateWithLifecycle()
    val chosen by vm.editorRange.collectAsStateWithLifecycle()
    val segments by vm.segments.collectAsStateWithLifecycle()
    val captionStyle by vm.captionStyle.collectAsStateWithLifecycle()
    val video = state.video

    var aspect by rememberSaveable { mutableStateOf(settings.defaultAspect) }
    var showPreview by rememberSaveable { mutableStateOf(false) }
    val durationSec = ((video?.durationMs ?: 1000L) / 1000f).coerceAtLeast(1f)
    var range by remember(video, chosen) { mutableStateOf(initialRange(chosen, durationSec, settings.clipDurationSec)) }
    val startMs = (range.start * 1000).toLong()
    val endMs = (range.endInclusive * 1000).toLong()
    val parts = if (segments.isNotEmpty()) segments else listOf(startMs to endMs)
    val totalMs = parts.sumOf { it.second - it.first }
    val canExport = parts.all { it.second - it.first >= 1000 }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ScreenHeader("Clip editor", onBack = onBack) }

        if (video == null) {
            item {
                EmptyState(
                    Icons.Rounded.VideoFile, "No video loaded",
                    "Import a video to choose a clip range and a format.",
                    actionLabel = "Import video", onAction = onImport,
                )
            }
        } else {
            item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    val shape = RoundedCornerShape(16.dp)
                    Box(
                        Modifier
                            .fillMaxWidth(if (aspect == AspectOption.Vertical) 0.5f else 1f)
                            .aspectRatio(aspect.ratio)
                            .clip(shape)
                            .border(1.dp, MaterialTheme.colorScheme.outline, shape),
                    ) {
                        VideoThumbnail(video.thumbnail, Modifier.fillMaxSize())
                        if (captionStyle.enabled) {
                            val sample = remember(captionStyle, aspect) { CaptionRenderer.preview(captionStyle, aspect) }
                            Image(
                                bitmap = sample.asImageBitmap(),
                                contentDescription = null,
                                contentScale = ContentScale.FillBounds,
                                modifier = Modifier.fillMaxSize(),
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Preview of the centre crop. Export keeps the middle of the picture.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            item {
                AppCard {
                    SectionTitle("Timeline")
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Start ${formatTime(startMs)}", style = MaterialTheme.typography.bodyMedium)
                        Text("End ${formatTime(endMs)}", style = MaterialTheme.typography.bodyMedium)
                    }
                    RangeSlider(value = range, onValueChange = { range = it }, valueRange = 0f..durationSec)
                    Text(
                        "Clip length ${formatTime(endMs - startMs)} of ${formatTime(video.durationMs)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(12.dp))
                    SecondaryButton(
                        "Play selection",
                        onClick = { showPreview = true },
                        modifier = Modifier.fillMaxWidth(),
                        icon = Icons.Rounded.PlayArrow,
                        enabled = endMs - startMs >= 1000,
                    )
                }
            }
            item {
                AppCard {
                    SectionTitle("Cuts")
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (segments.isEmpty()) {
                            "Move the sliders, then add the part as a cut. Add as many cuts as you like and they are joined in order into one clip."
                        } else {
                            "${segments.size} cuts, ${formatTime(totalMs)} in total. They are joined in this order."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    segments.forEachIndexed { index, cut ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Cut ${index + 1}: ${formatTime(cut.first)} – ${formatTime(cut.second)}",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f),
                            )
                            TextButton(onClick = { vm.removeSegment(index) }) { Text("Remove") }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SecondaryButton(
                            "Add this range as a cut",
                            onClick = { vm.addSegment(startMs, endMs) },
                            modifier = Modifier.weight(1f),
                            enabled = endMs - startMs >= 1000 && segments.size < 10,
                        )
                        if (segments.isNotEmpty()) {
                            SecondaryButton("Clear", onClick = { vm.clearSegments() }, modifier = Modifier.weight(0.5f))
                        }
                    }
                }
            }
            item {
                AppCard {
                    SectionTitle("Format")
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AspectOption.entries.forEach { option ->
                            FilterChip(selected = aspect == option, onClick = { aspect = option }, label = { Text(option.label) })
                        }
                    }
                }
            }
            item {
                AppCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            SectionTitle("Auto captions")
                            Text(
                                if (captionStyle.enabled) {
                                    "On. Made on your phone while exporting. The first time it downloads a ~40 MB speech model."
                                } else {
                                    "Add gaming-style subtitles to your clip."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(
                            checked = captionStyle.enabled,
                            onCheckedChange = { on -> vm.updateCaptionStyle { it.copy(enabled = on) } },
                        )
                    }
                    if (captionStyle.enabled) {
                        CaptionOptions(captionStyle) { change -> vm.updateCaptionStyle(change) }
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (export.running) {
                        AppCard {
                            Text(export.message ?: "Exporting clip…", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { export.progress },
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)),
                                color = Brand.Violet,
                                trackColor = MaterialTheme.colorScheme.outline,
                            )
                            Spacer(Modifier.height(12.dp))
                            SecondaryButton("Cancel export", onClick = { vm.cancelExport() }, modifier = Modifier.fillMaxWidth())
                        }
                    } else {
                        GradientButton(
                            if (parts.size > 1) "Export ${parts.size} cuts as one clip" else "Export clip",
                            onClick = { vm.exportClips(parts, aspect) },
                            modifier = Modifier.fillMaxWidth(),
                            icon = Icons.Rounded.Upload,
                            enabled = canExport,
                        )
                    }
                    val problem = export.error
                    if (problem != null) {
                        Text(problem, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                    }
                    val note = export.message
                    if (note != null && !export.running) {
                        Text(note, style = MaterialTheme.typography.bodyMedium, color = Brand.Success)
                        SecondaryButton("Open library", onClick = onOpenLibrary, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }

    if (showPreview && video != null) {
        RangePlayerDialog(video.uri, startMs, endMs) { showPreview = false }
    }
}
