# AI Clip Hunter

Android app that will find the interesting moments in videos and live streams and turn them into short clips.
**Current build: Milestones 1-5 plus auto captions and a first live-stream mode (YouTube Live and direct .m3u8 links).**

- Package: `com.aiclip.hunter` | Kotlin + Jetpack Compose (Material 3) | MVVM | min Android 10 (API 29)

## Build

1. Install **Android Studio** (a version that supports AGP 9.3) with **JDK 17+** and the **Android SDK 36** platform.
2. Open this folder (`AIClipHunter/`). Android Studio reads `gradle/wrapper/gradle-wrapper.properties` and downloads Gradle 9.5.0.
3. Let Gradle sync, pick a device or emulator (Android 10+), and press Run.

Command line: this archive has no `gradlew` / `gradle-wrapper.jar`. With Gradle installed, run `gradle wrapper --gradle-version 9.5.0` once, then `./gradlew assembleDebug`.

> **Not yet compiled.** The project was written and checked statically (XML validity, bracket balance, imports) but could not be built in the environment that created it. Expect to fix a few small compile errors on first sync, and please report them so they can be fixed before Milestone 2.

## Get an APK without Android Studio

1. Create a GitHub repository and upload this project (including the `.github` folder).
2. Open the **Actions** tab, choose **Build APK**, press **Run workflow**.
3. When it finishes, download `AIClipHunter-debug-apk` from the run page, unzip it, and install `app-debug.apk` on your phone (allow installs from your browser or file manager).

If the run fails, open the log and send me the red error lines.

## Versions (checked against developer.android.com release notes)

| Item | Version |
|---|---|
| Android Gradle Plugin | 9.3.0 (needs Gradle 9.5.0, JDK 17+). AGP 9 compiles Kotlin itself, so there is no `kotlin-android` plugin |
| Kotlin / Compose compiler plugin | 2.3.10 |
| Compose BOM | 2026.08.00 |
| Navigation Compose, Lifecycle, Activity Compose, DataStore, Core | 2.9.5, 2.9.4, 1.11.0, 1.1.7, 1.17.0 (not re-verified online, so bump them if Studio suggests newer ones) |

## What works in this version (Milestone 5 build)

| Area | Status |
|---|---|
| Splash, adaptive launcher icon, bottom navigation | Working |
| Import a local video (system file picker, no permission) with real metadata and thumbnail | Working |
| Audio analysis: decodes the audio track in small buffers and measures loudness per second | Working, not yet tested on real phones |
| Scene analysis: compares small frames over time to find cuts and motion | Working, not yet tested on real phones |
| Highlight scoring: audio 25 / visual 15 weights from Settings, missing signals dropped and renormalised, nearby moments merged | Working |
| Highlights list with sort, preview (plays only that range) and "Generate clip" | Working |
| Clip editor: range slider, 9:16 / 16:9 / 1:1, preview, export with progress and cancel | Working. Centre crop, not smart crop |
| Library: clips saved to Movies/AIClipHunter, thumbnails, rename, share, delete, survives restarts | Working |
| Auto captions (English, Hindi, Hinglish; styles, colours, animations) | Built. Speech runs on the phone (Vosk); the first use downloads a ~40 MB model |
| Smart crop that follows the subject | Not built (centre crop only) |
| Live analysis: paste a YouTube link, record the screen with Android's own permission, find moments, make clips | Built (screen capture runs in a foreground service; audio capture depends on the playing app and Android) |
| Background service / WorkManager | Not built. Analysis and export run while the app is open |

Limits: analysis time grows with video length (long videos are slow on a phone), and the highlight scores are heuristics, not a prediction of what goes viral.

## Structure

```
app/src/main/java/com/aiclip/hunter/
  MainActivity.kt, AppViewModel.kt
  navigation/      routes + bottom bar
  ui/              theme, components, splash, home, analyzer, highlights, editor, live, library, discover, settings
  domain/models/   Highlight, Clip, SourceVideo, settings models
  data/settings/   DataStore repository
  engine/video/    VideoMetadataExtractor
  engine/audio/    AudioAnalyzer
  engine/vision/   SceneAnalyzer
  engine/scoring/  HighlightDetector
  clipping/        ClipExporter (Media3 Transformer)
  data/clips/      ClipRepository (MediaStore)
  engine/{speech,chat}/   empty
assets/logo/       ai_clip_hunter_logo.svg, .png (1024px), make_logo.py (regenerates both)
models/            future on-device model files
```

Planned modules (`clipping/`, `sources/`, `workers/`, Room database) are added when their milestone starts.

## Permissions

None in Milestone 1. Later: notifications for long exports, internet for online sources. The app never asks for the microphone.



Media3 playback in the editor, persisted projects with Room, and a WorkManager pipeline skeleton with progress and cancellation.
