Place on-device model files here (whisper.cpp ggml model, LiteRT/ONNX models) from Milestone 3 onward.
Nothing is bundled in Milestone 1.
