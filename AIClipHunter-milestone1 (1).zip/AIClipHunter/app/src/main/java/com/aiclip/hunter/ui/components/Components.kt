package com.aiclip.hunter.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aiclip.hunter.ui.theme.Brand

/**
 * The AI Clip Hunter mark: targeting ring + play button + scissors. Same geometry as the launcher
 * icon (108 unit grid). [progress] 0..1 draws it in for the splash screen.
 */
@Composable
fun LogoMark(
    modifier: Modifier = Modifier,
    logoSize: Dp = 96.dp,
    progress: Float = 1f,
    haloColor: Color = Brand.Background,
) {
    Canvas(modifier.size(logoSize)) {
        val k = this.size.minDimension / 108f
        fun p(x: Float, y: Float) = Offset(x * k, y * k)
        val t = progress.coerceIn(0f, 1f)
        val ticksAlpha = ((t - 0.4f) / 0.3f).coerceIn(0f, 1f)
        val playScale = ((t - 0.2f) / 0.5f).coerceIn(0f, 1f)
        val cutAlpha = ((t - 0.65f) / 0.35f).coerceIn(0f, 1f)

        drawArc(
            color = Brand.Cyan, startAngle = -90f, sweepAngle = 360f * t, useCenter = false,
            topLeft = p(29f, 29f), size = Size(50f * k, 50f * k),
            style = Stroke(3.5f * k, cap = StrokeCap.Round),
        )
        listOf(
            p(54f, 22f) to p(54f, 35f), p(54f, 73f) to p(54f, 86f),
            p(22f, 54f) to p(35f, 54f), p(73f, 54f) to p(86f, 54f),
        ).forEach { (a, b) ->
            drawLine(Brand.Cyan, a, b, 3.5f * k, StrokeCap.Round, alpha = ticksAlpha)
        }
        val tri = Path().apply {
            moveTo(45f * k, 41f * k); lineTo(45f * k, 67f * k); lineTo(68f * k, 54f * k); close()
        }
        scale(playScale, pivot = p(54f, 54f)) {
            drawPath(tri, Brand.Violet, style = Fill)
            drawPath(tri, Brand.Violet, style = Stroke(3f * k, join = StrokeJoin.Round))
        }
        if (cutAlpha > 0f) {
            val blades = listOf(p(58f, 62f) to p(76f, 72f), p(62f, 58f) to p(72f, 76f))
            blades.forEach { (a, b) -> drawLine(haloColor, a, b, 6f * k, StrokeCap.Round, alpha = cutAlpha) }
            blades.forEach { (a, b) -> drawLine(Color.White, a, b, 2.4f * k, StrokeCap.Round, alpha = cutAlpha) }
            drawCircle(Color.White, 3f * k, p(78.6f, 73.5f), alpha = cutAlpha, style = Stroke(2.2f * k))
            drawCircle(Color.White, 3f * k, p(73.5f, 78.6f), alpha = cutAlpha, style = Stroke(2.2f * k))
        }
    }
}

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    val shape = RoundedCornerShape(20.dp)
    if (onClick != null) {
        Card(onClick = onClick, modifier = modifier.fillMaxWidth(), shape = shape, colors = colors, border = border) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Card(modifier = modifier.fillMaxWidth(), shape = shape, colors = colors, border = border) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

/** Primary action. Always give it fillMaxWidth() or weight() from the caller. */
@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
) {
    val brush: Brush = if (enabled) {
        Brush.horizontalGradient(listOf(Brand.Violet, Brand.VioletSoft))
    } else {
        SolidColor(MaterialTheme.colorScheme.outline)
    }
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 52.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        contentColor = if (enabled) Color.White else Brand.TextSecondary,
    ) {
        Row(
            Modifier.fillMaxWidth().background(brush).padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text(text, style = MaterialTheme.typography.labelLarge, maxLines = 1)
        }
    }
}

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 52.dp),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = MaterialTheme.typography.labelLarge, maxLines = 1)
    }
}

@Composable
fun StatusPill(text: String, color: Color, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = color,
        style = MaterialTheme.typography.labelMedium,
        maxLines = 1,
        modifier = modifier
            .background(color.copy(alpha = 0.14f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = modifier)
}

@Composable
fun ScreenHeader(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
            }
            Spacer(Modifier.width(4.dp))
        }
        Column {
            Text(title, style = MaterialTheme.typography.headlineMedium)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 24.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(64.dp).background(Brand.Violet.copy(alpha = 0.14f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = Brand.Violet, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(16.dp))
            SecondaryButton(actionLabel, onAction)
        }
    }
}

@Composable
fun VideoThumbnail(bitmap: Bitmap?, modifier: Modifier = Modifier) {
    val image = remember(bitmap) { bitmap?.asImageBitmap() }
    Box(modifier.background(MaterialTheme.colorScheme.surface), contentAlignment = Alignment.Center) {
        if (image != null) {
            Image(image, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Rounded.Movie, contentDescription = null, tint = Brand.TextSecondary, modifier = Modifier.size(32.dp))
        }
    }
}

/** Explains why something isn't available yet and, when possible, offers a working alternative. */
@Composable
fun FeatureUnavailableDialog(
    title: String,
    message: String,
    onDismiss: () -> Unit,
    confirmLabel: String? = null,
    onConfirm: (() -> Unit)? = null,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            if (confirmLabel != null && onConfirm != null) {
                TextButton(onClick = { onDismiss(); onConfirm() }) { Text(confirmLabel) }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
