package com.aiclip.hunter.engine.vision

import android.content.Context
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Samples one tiny frame every [stepSec] seconds and measures how much it differs from the
 * previous one (0..1). Big jumps mean scene cuts or lots of motion. Only one small frame is in memory at a time.
 */
class SceneAnalyzer(private val context: Context) {

    suspend fun analyze(uri: Uri, durationMs: Long, stepSec: Int, onProgress: (Float) -> Unit): FloatArray? =
        withContext(Dispatchers.Default) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                val steps = (durationMs / 1000 / stepSec).toInt() + 1
                val diffs = FloatArray(steps)
                var previous: IntArray? = null
                var decoded = 0
                for (i in 0 until steps) {
                    ensureActive()
                    val frame = retriever.getScaledFrameAtTime(
                        i.toLong() * stepSec * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST, 64, 36,
                    )
                    if (frame != null) {
                        val w = frame.width
                        val h = frame.height
                        val pixels = IntArray(w * h)
                        frame.getPixels(pixels, 0, w, 0, 0, w, h)
                        frame.recycle()
                        val prev = previous
                        if (prev != null && prev.size == pixels.size) {
                            var sum = 0L
                            for (k in pixels.indices) sum += abs(luma(pixels[k]) - luma(prev[k]))
                            diffs[i] = sum / (pixels.size * 255f)
                        }
                        previous = pixels
                        decoded++
                    }
                    onProgress((i + 1f) / steps)
                }
                if (decoded < 2) null else diffs
            } finally {
                retriever.release()
            }
        }

    private fun luma(c: Int): Int = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
}
