package com.aiclip.hunter.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.aiclip.hunter.domain.models.AppSettings
import com.aiclip.hunter.domain.models.AspectOption
import com.aiclip.hunter.domain.models.ExportQuality
import com.aiclip.hunter.domain.models.ScoreWeights
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val clipDuration = intPreferencesKey("clip_duration_sec")
        val quality = stringPreferencesKey("quality")
        val aspect = stringPreferencesKey("aspect")
        val subtitles = booleanPreferencesKey("subtitles_default")
        val wChat = intPreferencesKey("w_chat")
        val wAudio = intPreferencesKey("w_audio")
        val wSpeech = intPreferencesKey("w_speech")
        val wVisual = intPreferencesKey("w_visual")
        val wRetention = intPreferencesKey("w_retention")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val d = AppSettings()
            AppSettings(
                clipDurationSec = p[Keys.clipDuration] ?: d.clipDurationSec,
                quality = ExportQuality.entries.firstOrNull { it.name == p[Keys.quality] } ?: d.quality,
                defaultAspect = AspectOption.entries.firstOrNull { it.name == p[Keys.aspect] } ?: d.defaultAspect,
                subtitlesDefault = p[Keys.subtitles] ?: d.subtitlesDefault,
                weights = ScoreWeights(
                    chat = p[Keys.wChat] ?: d.weights.chat,
                    audio = p[Keys.wAudio] ?: d.weights.audio,
                    speech = p[Keys.wSpeech] ?: d.weights.speech,
                    visual = p[Keys.wVisual] ?: d.weights.visual,
                    retention = p[Keys.wRetention] ?: d.weights.retention,
                ),
            )
        }

    suspend fun save(s: AppSettings) {
        context.settingsDataStore.edit { p ->
            p[Keys.clipDuration] = s.clipDurationSec
            p[Keys.quality] = s.quality.name
            p[Keys.aspect] = s.defaultAspect.name
            p[Keys.subtitles] = s.subtitlesDefault
            p[Keys.wChat] = s.weights.chat
            p[Keys.wAudio] = s.weights.audio
            p[Keys.wSpeech] = s.weights.speech
            p[Keys.wVisual] = s.weights.visual
            p[Keys.wRetention] = s.weights.retention
        }
    }
}
