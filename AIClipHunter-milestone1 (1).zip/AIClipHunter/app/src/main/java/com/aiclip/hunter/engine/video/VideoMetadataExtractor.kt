package com.aiclip.hunter.engine.video

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.aiclip.hunter.domain.models.SourceVideo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Reads real metadata from a local video using Android framework APIs.
 * Only a single frame is decoded for the thumbnail, so memory use stays small.
 */
class VideoMetadataExtractor(private val context: Context) {

    suspend fun extract(uri: Uri): Result<SourceVideo> = withContext(Dispatchers.IO) {
        try {
            Result.success(read(uri))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(IllegalStateException(e.message ?: "This file couldn't be read as a video.", e))
        }
    }

    private fun read(uri: Uri): SourceVideo {
        val (name, size) = queryNameAndSize(uri)
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            check(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes") {
                "This file doesn't contain a video track."
            }
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            check(durationMs > 0) { "The video length couldn't be read." }
            var w = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rotation == 90 || rotation == 270) { val t = w; w = h; h = t }
            val hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
            val frame = retriever.getFrameAtTime(durationMs * 1000L / 10, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            return SourceVideo(uri, name, size, durationMs, w, h, frameRate(uri), hasAudio, frame?.let { downscale(it, 720) })
        } finally {
            retriever.release()
        }
    }

    private fun frameRate(uri: Uri): Float? {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(context, uri, null)
            (0 until extractor.trackCount).firstNotNullOfOrNull { i ->
                val f = extractor.getTrackFormat(i)
                val isVideo = f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true
                if (isVideo && f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                    runCatching { f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }
                        .getOrElse { runCatching { f.getFloat(MediaFormat.KEY_FRAME_RATE) }.getOrNull() }
                } else null
            }
        } catch (e: Exception) {
            null
        } finally {
            extractor.release()
        }
    }

    private fun downscale(src: Bitmap, maxWidth: Int): Bitmap {
        if (src.width <= maxWidth) return src
        val h = (src.height * (maxWidth.toFloat() / src.width)).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, maxWidth, h, true).also { if (it !== src) src.recycle() }
    }

    private fun queryNameAndSize(uri: Uri): Pair<String, Long?> {
        context.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null,
        )?.use { c ->
            if (c.moveToFirst()) {
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                val name = if (nameIdx >= 0) c.getString(nameIdx) else null
                val size = if (sizeIdx >= 0 && !c.isNull(sizeIdx)) c.getLong(sizeIdx) else null
                return (name ?: uri.lastPathSegment ?: "Video") to size
            }
        }
        return (uri.lastPathSegment ?: "Video") to null
    }
}
