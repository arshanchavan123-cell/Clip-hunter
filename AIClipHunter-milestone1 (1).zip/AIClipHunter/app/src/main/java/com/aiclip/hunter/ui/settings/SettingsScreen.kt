package com.aiclip.hunter.ui.settings

import android.content.Context
import android.os.StatFs
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.domain.models.AspectOption
import com.aiclip.hunter.domain.models.ExportQuality
import com.aiclip.hunter.domain.models.ScoreWeights
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.SecondaryButton
import com.aiclip.hunter.ui.components.SectionTitle
import com.aiclip.hunter.ui.components.StatusPill
import com.aiclip.hunter.ui.theme.Brand
import com.aiclip.hunter.utils.formatBytes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private data class StorageInfo(val freeBytes: Long, val totalBytes: Long, val cacheBytes: Long)

private fun readStorage(context: Context): StorageInfo {
    val stat = StatFs(context.filesDir.path)
    val cache = context.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    return StorageInfo(stat.availableBytes, stat.totalBytes, cache)
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    var storage by remember { mutableStateOf<StorageInfo?>(null) }
    LaunchedEffect(refresh) { storage = withContext(Dispatchers.IO) { readStorage(context) } }

    val w = settings.weights
    val versionName = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "0.1.0"
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ScreenHeader("Settings") }

        item {
            AppCard {
                SectionTitle("Clip defaults")
                Spacer(Modifier.height(12.dp))
                Label("Default clip length")
                ChoiceRow(listOf(15, 30, 45, 60), settings.clipDurationSec, { "${it}s" }) { n ->
                    vm.updateSettings { it.copy(clipDurationSec = n) }
                }
                Spacer(Modifier.height(12.dp))
                Label("Default format")
                ChoiceRow(AspectOption.entries.toList(), settings.defaultAspect, { it.label }) { a ->
                    vm.updateSettings { it.copy(defaultAspect = a) }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Subtitles on by default", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = settings.subtitlesDefault, onCheckedChange = { on -> vm.updateSettings { it.copy(subtitlesDefault = on) } })
                }
            }
        }

        item {
            AppCard {
                SectionTitle("Export")
                Spacer(Modifier.height(12.dp))
                Label("Video quality")
                ChoiceRow(ExportQuality.entries.toList(), settings.quality, { it.label }) { q ->
                    vm.updateSettings { it.copy(quality = q) }
                }
                Spacer(Modifier.height(8.dp))
                Hint("Applied when exporting clips (Milestone 5). Clips will be saved to your Movies folder as MP4.")
            }
        }

        item {
            AppCard {
                SectionTitle("Highlight scoring")
                Spacer(Modifier.height(4.dp))
                Hint("Starting weights are heuristics, not predictions of what goes viral. Signals that are missing for a video are dropped and the rest are rebalanced.")
                Spacer(Modifier.height(8.dp))
                WeightSlider("Chat activity", w.chat, w.percent(w.chat)) { v -> vm.updateSettings { it.copy(weights = it.weights.copy(chat = v)) } }
                WeightSlider("Audio excitement", w.audio, w.percent(w.audio)) { v -> vm.updateSettings { it.copy(weights = it.weights.copy(audio = v)) } }
                WeightSlider("Speech and reactions", w.speech, w.percent(w.speech)) { v -> vm.updateSettings { it.copy(weights = it.weights.copy(speech = v)) } }
                WeightSlider("Visual activity", w.visual, w.percent(w.visual)) { v -> vm.updateSettings { it.copy(weights = it.weights.copy(visual = v)) } }
                WeightSlider("Audience retention", w.retention, w.percent(w.retention)) { v -> vm.updateSettings { it.copy(weights = it.weights.copy(retention = v)) } }
                TextButton(onClick = { vm.updateSettings { it.copy(weights = ScoreWeights()) } }) { Text("Reset to defaults") }
            }
        }

        item {
            AppCard {
                SectionTitle("AI models")
                Spacer(Modifier.height(8.dp))
                ModelRow("Speech recognition (whisper.cpp)")
                ModelRow("Scene detection (OpenCV)")
                ModelRow("Optional models (LiteRT / ONNX Runtime)")
                Spacer(Modifier.height(8.dp))
                Hint("No models are installed yet. They arrive with the analysis engine in Milestone 3 and are free and open source.")
            }
        }

        item {
            AppCard {
                SectionTitle("Storage")
                Spacer(Modifier.height(8.dp))
                val s = storage
                if (s == null) {
                    Hint("Checking storage…")
                } else {
                    Text("${formatBytes(s.freeBytes)} free of ${formatBytes(s.totalBytes)}", style = MaterialTheme.typography.bodyMedium)
                    Text("App cache: ${formatBytes(s.cacheBytes)}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(12.dp))
                SecondaryButton(
                    "Clear cache",
                    onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { context.cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
                            refresh++
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Rounded.Delete,
                )
            }
        }

        item {
            AppCard {
                SectionTitle("About")
                Spacer(Modifier.height(8.dp))
                Text("AI Clip Hunter $versionName (Milestone 1)", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(4.dp))
                Hint("Built with free and open-source libraries. Analysis is designed to run on your phone with no paid services. Online and live sources will only use access that platforms permit.")
            }
        }
    }
}

@Composable
private fun Label(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun <T> ChoiceRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            FilterChip(selected = option == selected, onClick = { onSelect(option) }, label = { Text(label(option)) })
        }
    }
}

@Composable
private fun WeightSlider(label: String, value: Int, percent: Int, onCommit: (Int) -> Unit) {
    var local by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text("$percent% effective", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(
            value = local,
            onValueChange = { local = it },
            onValueChangeFinished = { onCommit(local.roundToInt()) },
            valueRange = 0f..100f,
        )
    }
}

@Composable
private fun ModelRow(name: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(name, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.width(8.dp))
        StatusPill("Not installed", Brand.TextSecondary)
    }
}
