package com.aiclip.hunter.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.FeatureUnavailableDialog
import com.aiclip.hunter.ui.components.GradientButton
import com.aiclip.hunter.ui.components.LogoMark
import com.aiclip.hunter.ui.components.SecondaryButton
import com.aiclip.hunter.ui.components.SectionTitle
import com.aiclip.hunter.ui.components.StatusPill
import com.aiclip.hunter.ui.components.VideoThumbnail
import com.aiclip.hunter.ui.theme.Brand
import com.aiclip.hunter.utils.formatTime
import com.aiclip.hunter.utils.isWebUrl

private data class QuickAction(val label: String, val icon: ImageVector, val onClick: () -> Unit)

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onImport: () -> Unit,
    onOpenLive: () -> Unit,
    onOpenAnalysis: () -> Unit,
    onOpenHighlights: () -> Unit,
    onOpenEditor: () -> Unit,
) {
    val importState by vm.importState.collectAsStateWithLifecycle()
    val clips by vm.clips.collectAsStateWithLifecycle()
    val highlights by vm.highlights.collectAsStateWithLifecycle()

    var url by rememberSaveable { mutableStateOf("") }
    var urlError by rememberSaveable { mutableStateOf<String?>(null) }
    var showUnsupported by rememberSaveable { mutableStateOf(false) }

    val analyse = {
        val text = url.trim()
        urlError = when {
            text.isEmpty() -> "Paste a video link first."
            !isWebUrl(text) -> "Enter a full link that starts with http:// or https://."
            else -> null
        }
        if (urlError == null) showUnsupported = true
    }

    val actions = listOf(
        QuickAction("Import video", Icons.Rounded.VideoFile, onImport),
        QuickAction("Highlights", Icons.Rounded.AutoAwesome, onOpenHighlights),
        QuickAction("Clip editor", Icons.Rounded.ContentCut, onOpenEditor),
        QuickAction("Live analysis", Icons.Rounded.Sensors, onOpenLive),
    )

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LogoMark(logoSize = 48.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Welcome to AI Clip Hunter", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Find the moments worth clipping.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        item {
            AppCard {
                SectionTitle("Analyse a video link")
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; urlError = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    placeholder = { Text("Paste a video URL") },
                    leadingIcon = { Icon(Icons.Rounded.Link, contentDescription = null) },
                    isError = urlError != null,
                    supportingText = urlError?.let { msg -> { Text(msg) } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { analyse() }),
                )
                Spacer(Modifier.height(12.dp))
                GradientButton("Analyse link", onClick = { analyse() }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.AutoAwesome)
                Spacer(Modifier.height(8.dp))
                SecondaryButton("Import a video from your phone", onClick = onImport, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.VideoFile)
            }
        }

        item {
            AppCard(onClick = onOpenLive) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).background(Brand.Cyan.copy(alpha = 0.14f), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Sensors, contentDescription = null, tint = Brand.Cyan) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Live stream analysis", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Watch an authorized stream for highlights as it happens.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    StatusPill("Coming soon", Brand.Cyan)
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Clips generated", clips.size.toString(), Modifier.weight(1f))
                StatCard("Highlights found", highlights.size.toString(), Modifier.weight(1f))
            }
        }

        item { SectionTitle("Quick actions") }
        actions.chunked(2).forEach { pair ->
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { QuickActionCard(it, Modifier.weight(1f)) }
                }
            }
        }

        item { SectionTitle("Recent projects") }
        item {
            val video = importState.video
            when {
                importState.loading -> AppCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Reading video details…", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                video != null -> AppCard(onClick = onOpenAnalysis) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        VideoThumbnail(video.thumbnail, Modifier.size(width = 96.dp, height = 54.dp).clip(RoundedCornerShape(12.dp)))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(video.displayName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${formatTime(video.durationMs)} • ${video.width}×${video.height} • Not analysed yet",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                else -> Text(
                    "No projects yet. Import a video to start one. Projects last until the app closes in this version.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }

    if (showUnsupported) {
        FeatureUnavailableDialog(
            title = "Online links aren't supported yet",
            message = "Link analysis arrives in Milestone 6 and will only work with sources that permit access. " +
                "Nothing was downloaded or analysed. You can import a video file from your phone now.",
            onDismiss = { showUnsupported = false },
            confirmLabel = "Import video",
            onConfirm = onImport,
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    AppCard(modifier) {
        Text(value, style = MaterialTheme.typography.headlineMedium)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun QuickActionCard(action: QuickAction, modifier: Modifier = Modifier) {
    AppCard(modifier, onClick = action.onClick) {
        Icon(action.icon, contentDescription = null, tint = Brand.Violet)
        Spacer(Modifier.height(12.dp))
        Text(action.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
    }
}
