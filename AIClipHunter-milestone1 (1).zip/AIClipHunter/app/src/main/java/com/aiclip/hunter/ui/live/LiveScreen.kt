package com.aiclip.hunter.ui.live

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.FeatureUnavailableDialog
import com.aiclip.hunter.ui.components.GradientButton
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.SecondaryButton
import com.aiclip.hunter.ui.components.SectionTitle
import com.aiclip.hunter.ui.components.StatusPill
import com.aiclip.hunter.ui.theme.Brand
import com.aiclip.hunter.utils.isWebUrl

@Composable
fun LiveScreen(onBack: () -> Unit) {
    var url by rememberSaveable { mutableStateOf("") }
    var urlError by rememberSaveable { mutableStateOf<String?>(null) }
    var showUnavailable by rememberSaveable { mutableStateOf(false) }

    val connect = {
        val text = url.trim()
        urlError = when {
            text.isEmpty() -> "Enter the address of a stream you're allowed to analyse."
            !isWebUrl(text) -> "Enter a full link that starts with http:// or https://."
            else -> null
        }
        if (urlError == null) showUnavailable = true
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ScreenHeader("Live analysis", onBack = onBack) }
        item {
            AppCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("Authorized stream")
                    StatusPill("Coming soon", Brand.Cyan)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Use a stream you own or have permission to analyse. Private, protected or login-only streams are never bypassed.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; urlError = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    placeholder = { Text("Stream URL") },
                    leadingIcon = { androidx.compose.material3.Icon(Icons.Rounded.Link, contentDescription = null) },
                    isError = urlError != null,
                    supportingText = urlError?.let { msg -> { Text(msg) } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { connect() }),
                )
                Spacer(Modifier.height(12.dp))
                GradientButton("Connect", onClick = { connect() }, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Sensors)
            }
        }
        item {
            AppCard {
                SectionTitle("Status")
                Spacer(Modifier.height(8.dp))
                IndicatorRow("Connection", "Disconnected", Brand.TextSecondary)
                IndicatorRow("Live analysis", "Idle", Brand.TextSecondary)
                IndicatorRow("Chat activity", "No data", Brand.TextSecondary)
            }
        }
        item {
            AppCard {
                SectionTitle("Highlight feed")
                Spacer(Modifier.height(4.dp))
                Text(
                    "Moments detected during a live stream will appear here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            AppCard {
                SectionTitle("Automatic clips")
                Spacer(Modifier.height(4.dp))
                Text(
                    "Clips generated from live highlights will be listed here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            SecondaryButton("Stop analysis", onClick = {}, modifier = Modifier.fillMaxWidth(), icon = Icons.Rounded.Stop, enabled = false)
        }
    }

    if (showUnavailable) {
        FeatureUnavailableDialog(
            title = "Live analysis isn't available yet",
            message = "No connection was made. Live stream analysis arrives in Milestone 7 and will need an authorized source: " +
                "a stream you control, a permitted platform API, or a media URL you have the right to access.",
            onDismiss = { showUnavailable = false },
        )
    }
}

@Composable
private fun IndicatorRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = color)
    }
}
