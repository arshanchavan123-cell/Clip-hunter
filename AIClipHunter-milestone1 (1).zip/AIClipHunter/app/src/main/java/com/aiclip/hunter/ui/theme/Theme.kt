package com.aiclip.hunter.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Brand {
    val Background = Color(0xFF090B12)
    val Surface = Color(0xFF111522)
    val Card = Color(0xFF171D2B)
    val Outline = Color(0xFF262E42)
    val Violet = Color(0xFF8B5CF6)
    val VioletSoft = Color(0xFF6D7CF5)
    val Cyan = Color(0xFF22D3EE)
    val Success = Color(0xFF22C55E)
    val Warning = Color(0xFFF59E0B)
    val TextSecondary = Color(0xFF9CA3AF)
}

private val DarkColors = darkColorScheme(
    primary = Brand.Violet,
    onPrimary = Color.White,
    secondary = Brand.Cyan,
    onSecondary = Brand.Background,
    tertiary = Brand.Success,
    background = Brand.Background,
    onBackground = Color.White,
    surface = Brand.Surface,
    onSurface = Color.White,
    surfaceVariant = Brand.Card,
    onSurfaceVariant = Brand.TextSecondary,
    surfaceContainer = Brand.Surface,
    surfaceContainerHigh = Brand.Card,
    surfaceContainerHighest = Brand.Card,
    outline = Brand.Outline,
    outlineVariant = Brand.Outline,
    error = Color(0xFFF87171),
)

private val Sans = FontFamily.SansSerif

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = Sans, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 14.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 12.sp),
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun AIClipHunterTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, typography = AppTypography, shapes = AppShapes, content = content)
}
