package com.aiclip.hunter.ui.analyzer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.domain.models.StageStatus
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.EmptyState
import com.aiclip.hunter.ui.components.GradientButton
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.SecondaryButton
import com.aiclip.hunter.ui.components.StatusPill
import com.aiclip.hunter.ui.components.VideoThumbnail
import com.aiclip.hunter.ui.theme.Brand
import com.aiclip.hunter.utils.formatBytes
import com.aiclip.hunter.utils.formatTime

@Composable
fun AnalysisScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onImport: () -> Unit,
    onOpenEditor: () -> Unit,
    onOpenHighlights: () -> Unit,
) {
    val state by vm.importState.collectAsStateWithLifecycle()
    val analysis by vm.analysis.collectAsStateWithLifecycle()
    val highlights by vm.highlights.collectAsStateWithLifecycle()
    val video = state.video
    val error = state.error

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ScreenHeader("Video analysis", onBack = onBack) }

        when {
            state.loading -> item {
                Column(Modifier.fillMaxWidth().padding(48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text("Reading video details…", style = MaterialTheme.typography.bodyMedium)
                }
            }
            error != null -> item {
                EmptyState(
                    Icons.Rounded.ErrorOutline, "This video can't be opened", error,
                    actionLabel = "Choose another video", onAction = onImport,
                )
            }
            video == null -> item {
                EmptyState(
                    Icons.Rounded.VideoFile, "No video selected",
                    "Import a video from your phone to analyse it.",
                    actionLabel = "Import video", onAction = onImport,
                )
            }
            else -> {
                item {
                    Box {
                        VideoThumbnail(video.thumbnail, Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(20.dp)))
                        StatusPill(
                            formatTime(video.durationMs), Color.White,
                            Modifier.align(Alignment.BottomEnd).padding(10.dp).background(Color(0x99000000), RoundedCornerShape(50)),
                        )
                    }
                }
                item {
                    Column {
                        Text(video.displayName, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        val details = listOfNotNull(
                            "${video.width}×${video.height}",
                            video.frameRate?.let { "${it.toInt()} fps" },
                            video.sizeBytes?.let { formatBytes(it) },
                            if (video.hasAudio) "Has audio" else "No audio track",
                        )
                        Text(
                            details.joinToString(" • "),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                item {
                    AppCard {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Analysis progress", style = MaterialTheme.typography.titleMedium)
                            when {
                                analysis.running -> StatusPill("Running", Brand.Cyan)
                                analysis.finished -> StatusPill("Finished", Brand.Success)
                                else -> StatusPill("Not started", Brand.TextSecondary)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { analysis.progress },
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)),
                            color = Brand.Violet,
                            trackColor = MaterialTheme.colorScheme.outline,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Current stage: ${analysis.stage}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(12.dp))
                        StageRow(Icons.Rounded.GraphicEq, "Audio analysis", statusText(analysis.audio, "No audio track"))
                        StageRow(Icons.Rounded.Visibility, "Visual analysis", statusText(analysis.visual, "Skipped"))
                        StageRow(Icons.Rounded.RecordVoiceOver, "Speech analysis", "Not built yet")
                        StageRow(Icons.Rounded.Forum, "Chat analysis", "Live streams only")
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Detected highlights", style = MaterialTheme.typography.bodyMedium)
                            Text(highlights.size.toString(), style = MaterialTheme.typography.titleMedium)
                        }
                        val problem = analysis.error
                        if (problem != null) {
                            Spacer(Modifier.height(8.dp))
                            Text(problem, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (analysis.running) {
                            SecondaryButton("Cancel analysis", onClick = { vm.cancelAnalysis() }, modifier = Modifier.fillMaxWidth())
                        } else {
                            GradientButton(
                                if (analysis.finished) "Analyse again" else "Start analysis",
                                onClick = { vm.startAnalysis() },
                                modifier = Modifier.fillMaxWidth(),
                                icon = Icons.Rounded.AutoAwesome,
                            )
                        }
                        if (highlights.isNotEmpty()) {
                            GradientButton("View ${highlights.size} highlights", onClick = onOpenHighlights, modifier = Modifier.fillMaxWidth())
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            SecondaryButton("Open in editor", onOpenEditor, Modifier.weight(1f))
                            SecondaryButton("Remove video", onClick = { vm.clearVideo(); onBack() }, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

private fun statusText(status: StageStatus, skippedText: String): String = when (status) {
    StageStatus.Waiting -> "Waiting"
    StageStatus.Running -> "Running…"
    StageStatus.Done -> "Done"
    StageStatus.Skipped -> skippedText
    StageStatus.Failed -> "Couldn't analyse"
}

@Composable
private fun StageRow(icon: ImageVector, title: String, status: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = Brand.TextSecondary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
