package com.aiclip.hunter.ui.components

import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay

/** Plays only the part of the video between [startMs] and [endMs]. Tap to pause or resume. */
@Composable
fun RangePlayer(uri: Uri, startMs: Long, endMs: Long, modifier: Modifier = Modifier) {
    val holder = remember { arrayOfNulls<VideoView>(1) }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            VideoView(context).apply {
                setVideoURI(uri)
                setOnPreparedListener {
                    seekTo(startMs.toInt())
                    start()
                }
                setOnClickListener { if (isPlaying) pause() else start() }
                holder[0] = this
            }
        },
    )

    LaunchedEffect(startMs, endMs) {
        while (true) {
            delay(200)
            val v = holder[0] ?: continue
            if (v.isPlaying && v.currentPosition >= endMs) {
                v.pause()
                v.seekTo(startMs.toInt())
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose { holder[0]?.stopPlayback() }
    }
}

@Composable
fun RangePlayerDialog(uri: Uri, startMs: Long, endMs: Long, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Column(Modifier.padding(12.dp)) {
                RangePlayer(uri, startMs, endMs, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                Spacer(Modifier.height(8.dp))
                Text(
                    "Tap the video to pause or play.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        }
    }
}
