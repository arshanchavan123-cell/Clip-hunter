package com.aiclip.hunter.ui.discover

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.SectionTitle
import com.aiclip.hunter.ui.components.StatusPill
import com.aiclip.hunter.ui.theme.Brand

private enum class Availability(val label: String, val color: Color) {
    Available("Available", Brand.Success),
    Soon("Coming soon", Brand.Cyan),
}

private data class Capability(
    val icon: ImageVector,
    val title: String,
    val detail: String,
    val availability: Availability,
    val onClick: (() -> Unit)? = null,
)

@Composable
fun DiscoverScreen(onImport: () -> Unit, onOpenLive: () -> Unit) {
    val sources = listOf(
        Capability(Icons.Rounded.VideoFile, "Video from your phone", "Import a file you own. It stays on your device.", Availability.Available, onImport),
        Capability(Icons.Rounded.Public, "Online video link", "Only sources that permit access. Milestone 6.", Availability.Soon),
        Capability(Icons.Rounded.Sensors, "Authorized live stream", "Analyse a stream you have rights to. Milestone 7.", Availability.Soon, onOpenLive),
        Capability(Icons.Rounded.Forum, "Live stream chat", "Spot chat activity spikes through permitted APIs. Milestone 7.", Availability.Soon),
    )
    val signals = listOf(
        Capability(Icons.Rounded.GraphicEq, "Audio energy", "Loud moments and sudden changes. Milestone 3.", Availability.Soon),
        Capability(Icons.Rounded.Visibility, "Scene changes", "Cuts and big visual shifts. Milestone 3.", Availability.Soon),
        Capability(Icons.Rounded.RecordVoiceOver, "Speech", "On-device transcripts with timestamps. Planned.", Availability.Soon),
        Capability(Icons.Rounded.AutoAwesome, "Highlight scoring", "Ranks moments from 0 to 100 with weights you can adjust. Milestone 4.", Availability.Soon),
    )

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenHeader("Discover", subtitle = "What AI Clip Hunter can work with") }
        item { SectionTitle("Where videos come from") }
        sources.forEach { item { CapabilityCard(it) } }
        item { SectionTitle("What it looks for", Modifier.padding(top = 8.dp)) }
        signals.forEach { item { CapabilityCard(it) } }
    }
}

@Composable
private fun CapabilityCard(c: Capability) {
    AppCard(onClick = c.onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(c.icon, contentDescription = null, tint = c.availability.color, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(c.title, style = MaterialTheme.typography.titleMedium)
                Text(c.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            StatusPill(c.availability.label, c.availability.color)
        }
    }
}
