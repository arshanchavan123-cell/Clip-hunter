package com.aiclip.hunter.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.aiclip.hunter.ui.components.LogoMark
import com.aiclip.hunter.ui.theme.Brand
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val finish by rememberUpdatedState(onFinished)

    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(durationMillis = 1100, easing = FastOutSlowInEasing))
        delay(600)
        finish()
    }

    Column(
        Modifier.fillMaxSize().background(Brand.Background),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        LogoMark(logoSize = 150.dp, progress = progress.value)
        Spacer(Modifier.height(24.dp))
        Text(
            "AI Clip Hunter",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.alpha(progress.value),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Find the moments worth clipping.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.alpha(progress.value),
        )
        Spacer(Modifier.height(32.dp))
        LinearProgressIndicator(
            modifier = Modifier.width(120.dp).clip(CircleShape),
            color = Brand.Violet,
            trackColor = Brand.Card,
        )
    }
}
