package com.aiclip.hunter

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.StatFs
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aiclip.hunter.clipping.ClipExporter
import com.aiclip.hunter.data.clips.ClipRepository
import com.aiclip.hunter.data.settings.SettingsRepository
import com.aiclip.hunter.domain.models.AnalysisState
import com.aiclip.hunter.domain.models.AppSettings
import com.aiclip.hunter.domain.models.AspectOption
import com.aiclip.hunter.domain.models.Clip
import com.aiclip.hunter.domain.models.ExportState
import com.aiclip.hunter.domain.models.Highlight
import com.aiclip.hunter.domain.models.SourceVideo
import com.aiclip.hunter.domain.models.StageStatus
import com.aiclip.hunter.engine.audio.AudioAnalyzer
import com.aiclip.hunter.engine.scoring.HighlightDetector
import com.aiclip.hunter.engine.video.VideoMetadataExtractor
import com.aiclip.hunter.engine.vision.SceneAnalyzer
import com.aiclip.hunter.utils.formatTime
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.ceil

/** App-level state holder. Analysis and export run while the app is open and can be cancelled. */
class AppViewModel(application: Application) : AndroidViewModel(application) {

    data class ImportState(
        val loading: Boolean = false,
        val video: SourceVideo? = null,
        val error: String? = null,
    )

    private val extractor = VideoMetadataExtractor(application)
    private val audioAnalyzer = AudioAnalyzer(application)
    private val sceneAnalyzer = SceneAnalyzer(application)
    private val exporter = ClipExporter(application)
    private val clipRepository = ClipRepository(application)
    private val settingsRepository = SettingsRepository(application)

    private val _importState = MutableStateFlow(ImportState())
    val importState: StateFlow<ImportState> = _importState.asStateFlow()

    private val _analysis = MutableStateFlow(AnalysisState())
    val analysis: StateFlow<AnalysisState> = _analysis.asStateFlow()

    private val _highlights = MutableStateFlow<List<Highlight>>(emptyList())
    val highlights: StateFlow<List<Highlight>> = _highlights.asStateFlow()

    private val _clips = MutableStateFlow<List<Clip>>(emptyList())
    val clips: StateFlow<List<Clip>> = _clips.asStateFlow()

    private val _export = MutableStateFlow(ExportState())
    val exportState: StateFlow<ExportState> = _export.asStateFlow()

    /** Start/end (ms) chosen from a highlight, picked up by the clip editor. */
    private val _editorRange = MutableStateFlow<Pair<Long, Long>?>(null)
    val editorRange: StateFlow<Pair<Long, Long>?> = _editorRange.asStateFlow()

    /** Cuts chosen for one montage clip, joined in this order. Empty means "use the slider range". */
    private val _segments = MutableStateFlow<List<Pair<Long, Long>>>(emptyList())
    val segments: StateFlow<List<Pair<Long, Long>>> = _segments.asStateFlow()

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private companion object {
        const val MAX_CUTS = 10
    }

    private var importJob: Job? = null
    private var analysisJob: Job? = null
    private var exportJob: Job? = null

    init {
        refreshClips()
    }

    // ---------- Import ----------

    fun importVideo(uri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        resetProject()
        _importState.value = ImportState(loading = true)
        importJob = viewModelScope.launch {
            extractor.extract(uri).fold(
                onSuccess = { _importState.value = ImportState(video = it) },
                onFailure = { _importState.value = ImportState(error = it.message ?: "This file couldn't be read.") },
            )
        }
    }

    fun clearVideo() {
        importJob?.cancel()
        resetProject()
        _importState.value = ImportState()
    }

    private fun resetProject() {
        analysisJob?.cancel()
        exportJob?.cancel()
        _analysis.value = AnalysisState()
        _highlights.value = emptyList()
        _editorRange.value = null
        _segments.value = emptyList()
        _export.value = ExportState()
    }

    // ---------- Analysis ----------

    fun startAnalysis() {
        val video = _importState.value.video ?: return
        if (_analysis.value.running) return
        val weights = settings.value.weights
        val clipSec = settings.value.clipDurationSec

        analysisJob = viewModelScope.launch {
            _highlights.value = emptyList()
            _analysis.value = AnalysisState(running = true, stage = "Analysing audio", audio = StageStatus.Running)

            var audio: FloatArray? = null
            var audioStatus = StageStatus.Skipped
            if (video.hasAudio) {
                audio = try {
                    audioAnalyzer.analyze(video.uri, video.durationMs) { p ->
                        _analysis.update { it.copy(progress = p * 0.5f) }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    null
                }
                audioStatus = if (audio != null) StageStatus.Done else StageStatus.Failed
            }

            _analysis.update {
                it.copy(progress = 0.5f, stage = "Analysing scenes", audio = audioStatus, visual = StageStatus.Running)
            }
            val stepSec = ceil(video.durationMs / 1000.0 / 300.0).toInt().coerceAtLeast(1)
            val visual = try {
                sceneAnalyzer.analyze(video.uri, video.durationMs, stepSec) { p ->
                    _analysis.update { it.copy(progress = 0.5f + p * 0.5f) }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            val visualStatus = if (visual != null) StageStatus.Done else StageStatus.Failed

            _analysis.update { it.copy(stage = "Scoring moments") }
            val found = if (audio == null && visual == null) {
                emptyList()
            } else {
                HighlightDetector.detect(video.durationMs, audio, visual, stepSec, weights, clipSec)
            }
            _highlights.value = found

            _analysis.value = AnalysisState(
                finished = true,
                progress = 1f,
                stage = when {
                    audio == null && visual == null -> "Couldn't analyse this video"
                    found.isEmpty() -> "No clear highlights found"
                    else -> "Done"
                },
                audio = audioStatus,
                visual = visualStatus,
                error = if (audio == null && visual == null) "Neither audio nor video frames could be read from this file." else null,
            )
        }
    }

    fun cancelAnalysis() {
        analysisJob?.cancel()
        _analysis.value = AnalysisState(stage = "Cancelled")
    }

    fun addSegment(startMs: Long, endMs: Long) {
        if (endMs - startMs < 1000 || _segments.value.size >= MAX_CUTS) return
        _segments.update { it + (startMs to endMs) }
    }

    fun removeSegment(index: Int) {
        _segments.update { list -> list.filterIndexed { i, _ -> i != index } }
    }

    fun clearSegments() {
        _segments.value = emptyList()
    }

    fun toggleHighlight(h: Highlight) {
        val range = h.startMs to h.endMs
        if (_segments.value.contains(range)) _segments.update { it - range } else addSegment(h.startMs, h.endMs)
    }

    fun openHighlight(h: Highlight) {
        _editorRange.value = h.startMs to h.endMs
    }

    // ---------- Export ----------

    fun exportClips(parts: List<Pair<Long, Long>>, aspect: AspectOption) {
        val video = _importState.value.video ?: return
        if (_export.value.running || parts.isEmpty() || parts.any { it.second - it.first < 1000 }) return
        val startMs = parts.first().first
        val totalMs = parts.sumOf { it.second - it.first }
        val app = getApplication<Application>()

        exportJob = viewModelScope.launch {
            if (StatFs(app.cacheDir.path).availableBytes < 300L * 1024 * 1024) {
                _export.value = ExportState(error = "Not enough free storage. Free up at least 300 MB and try again.")
                return@launch
            }
            _export.value = ExportState(running = true, message = "Exporting…")
            val temp = File(app.cacheDir, "export_${System.currentTimeMillis()}.mp4")
            try {
                val result = exporter.export(video.uri, parts, aspect, settings.value.quality, temp) { p ->
                    _export.update { it.copy(progress = p) }
                }
                if (result.isSuccess) {
                    val base = video.displayName.substringBeforeLast('.')
                    val suffix = if (parts.size > 1) "montage ${parts.size} cuts" else formatTime(startMs).replace(':', '-')
                    val name = "$base $suffix".replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    val clip = clipRepository.save(temp, name, totalMs)
                    _clips.value = listOf(clip) + _clips.value
                    _export.value = ExportState(message = "Saved to Movies/AIClipHunter. Find it in your Library.")
                } else {
                    _export.value = ExportState(error = result.exceptionOrNull()?.message ?: "Export failed.")
                }
            } catch (e: CancellationException) {
                _export.value = ExportState(message = "Export cancelled.")
                throw e
            } catch (e: Exception) {
                _export.value = ExportState(error = e.message ?: "Export failed.")
            } finally {
                temp.delete()
            }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
    }

    // ---------- Library ----------

    fun refreshClips() {
        viewModelScope.launch {
            val list = try {
                clipRepository.list()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (list != null) _clips.value = list
        }
    }

    fun renameClip(clip: Clip, title: String) {
        val clean = title.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (clean.isEmpty()) return
        viewModelScope.launch {
            runCatching { clipRepository.rename(clip, clean) }
            refreshClips()
        }
    }

    fun deleteClip(clip: Clip) {
        viewModelScope.launch {
            runCatching { clipRepository.delete(clip) }
            _clips.value = _clips.value.filterNot { it.id == clip.id }
        }
    }

    // ---------- Settings ----------

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepository.save(transform(settings.value)) }
    }
}
