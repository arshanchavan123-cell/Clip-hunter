package com.aiclip.hunter.engine.scoring

import com.aiclip.hunter.domain.models.Highlight
import com.aiclip.hunter.domain.models.HighlightCategory
import com.aiclip.hunter.domain.models.ScoreWeights
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Turns the measured signals into ranked highlight candidates.
 *
 * Signals that weren't measured (no audio, chat, speech, retention data) are dropped and the
 * remaining weights are renormalised. The weights are heuristics, not a prediction of virality.
 */
object HighlightDetector {

    fun detect(
        durationMs: Long,
        audioRms: FloatArray?,
        visualDiff: FloatArray?,
        visualStepSec: Int,
        weights: ScoreWeights,
        clipSec: Int,
        maxResults: Int = 10,
    ): List<Highlight> {
        val seconds = ((durationMs + 999) / 1000).toInt()
        if (seconds < 1) return emptyList()

        val audio = audioRms?.let { audioSignal(it, seconds) }
        val visual = visualDiff?.let { visualSignal(it, seconds, visualStepSec) }

        val wa = if (audio != null) weights.audio else 0
        val wv = if (visual != null) weights.visual else 0
        val total = wa + wv
        if (total <= 0) return emptyList()

        val raw = FloatArray(seconds) { s ->
            ((audio?.get(s) ?: 0f) * wa + (visual?.get(s) ?: 0f) * wv) / total
        }
        val score = smooth(raw, 2)

        val len = clipSec.coerceIn(5, 120).coerceAtMost(seconds)
        val minScore = maxOf(0.25f, percentile(score, 0.80f))
        val chosen = mutableListOf<Int>()
        for (i in score.indices.sortedByDescending { score[it] }) {
            if (score[i] < minScore || chosen.size >= maxResults) break
            if (chosen.none { abs(it - i) < len }) chosen += i // combine nearby moments, avoid duplicates
        }

        return chosen.mapIndexed { n, peak ->
            val start = (peak - (len * 0.4f).toInt()).coerceIn(0, maxOf(0, seconds - len)) // context before the peak
            val end = minOf(seconds, start + len)
            val a = (audio?.get(peak) ?: 0f) * wa
            val v = (visual?.get(peak) ?: 0f) * wv
            val sum = a + v
            val category = when {
                sum <= 0f -> HighlightCategory.Combined
                a / sum > 0.65f -> HighlightCategory.Audio
                v / sum > 0.65f -> HighlightCategory.Visual
                else -> HighlightCategory.Combined
            }
            Highlight(
                id = "h${n + 1}",
                startMs = start * 1000L,
                endMs = minOf(end * 1000L, durationMs),
                score = (score[peak] * 100).roundToInt().coerceIn(0, 100),
                category = category,
            )
        }.sortedByDescending { it.score }
    }

    private fun audioSignal(rms: FloatArray, seconds: Int): FloatArray? {
        val p95 = percentile(rms, 0.95f)
        if (p95 < 1e-4f) return null // silent audio carries no information
        return FloatArray(seconds) { s ->
            val now = rms.getOrElse(s) { 0f }
            val level = (now / p95).coerceIn(0f, 1f)
            var sum = 0f
            var n = 0
            for (i in maxOf(0, s - 8) until s) { sum += rms.getOrElse(i) { 0f }; n++ }
            val before = if (n > 0) sum / n else now
            val rise = ((now - before) / p95).coerceIn(0f, 1f) // sudden jumps in loudness
            0.6f * level + 0.4f * rise
        }
    }

    private fun visualSignal(diff: FloatArray, seconds: Int, step: Int): FloatArray? {
        val p95 = percentile(diff, 0.95f)
        if (p95 < 1e-4f) return null
        return FloatArray(seconds) { s -> (diff.getOrElse(s / step) { 0f } / p95).coerceIn(0f, 1f) }
    }

    private fun smooth(values: FloatArray, radius: Int): FloatArray = FloatArray(values.size) { i ->
        val from = maxOf(0, i - radius)
        val to = minOf(values.lastIndex, i + radius)
        var sum = 0f
        for (k in from..to) sum += values[k]
        sum / (to - from + 1)
    }

    private fun percentile(values: FloatArray, p: Float): Float {
        if (values.isEmpty()) return 0f
        val sorted = values.sortedArray()
        return sorted[((sorted.size - 1) * p).toInt()]
    }
}
