package com.aiclip.hunter.ui.highlights

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aiclip.hunter.AppViewModel
import com.aiclip.hunter.domain.models.Highlight
import com.aiclip.hunter.ui.components.AppCard
import com.aiclip.hunter.ui.components.EmptyState
import com.aiclip.hunter.ui.components.GradientButton
import com.aiclip.hunter.ui.components.RangePlayerDialog
import com.aiclip.hunter.ui.components.ScreenHeader
import com.aiclip.hunter.ui.components.SecondaryButton
import com.aiclip.hunter.ui.components.StatusPill
import com.aiclip.hunter.ui.theme.Brand
import com.aiclip.hunter.utils.formatTime

@Composable
fun HighlightsScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onImport: () -> Unit,
    onOpenEditor: () -> Unit,
) {
    val highlights by vm.highlights.collectAsStateWithLifecycle()
    val importState by vm.importState.collectAsStateWithLifecycle()
    val segments by vm.segments.collectAsStateWithLifecycle()
    var previewing by remember { mutableStateOf<Highlight?>(null) }
    var byScore by rememberSaveable { mutableStateOf(true) }
    val sorted = remember(highlights, byScore) {
        if (byScore) highlights.sortedByDescending { it.score } else highlights.sortedBy { it.startMs }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ScreenHeader("Highlights", subtitle = "${highlights.size} detected", onBack = onBack) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = byScore, onClick = { byScore = true }, label = { Text("Highest score") })
                FilterChip(selected = !byScore, onClick = { byScore = false }, label = { Text("Timeline") })
            }
        }
        if (segments.isNotEmpty()) {
            item {
                GradientButton(
                    "Make montage from ${segments.size} cuts",
                    onClick = onOpenEditor,
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Rounded.ContentCut,
                )
            }
        }
        if (sorted.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.AutoAwesome, "No highlights yet",
                    "Import a video and run the analysis. Highlights found in the loud and fast-changing moments appear here.",
                    actionLabel = "Import video", onAction = onImport,
                )
            }
        } else {
            items(sorted, key = { it.id }) { h ->
                HighlightCard(
                    h,
                    selected = segments.contains(h.startMs to h.endMs),
                    onToggle = { vm.toggleHighlight(h) },
                    onPreview = { previewing = h },
                    onGenerate = { vm.openHighlight(h); onOpenEditor() },
                )
            }
        }
    }

    val playing = previewing
    val video = importState.video
    if (playing != null && video != null) {
        RangePlayerDialog(video.uri, playing.startMs, playing.endMs) { previewing = null }
    }
}

@Composable
private fun HighlightCard(h: Highlight, selected: Boolean, onToggle: () -> Unit, onPreview: () -> Unit, onGenerate: () -> Unit) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { h.score / 100f },
                    modifier = Modifier.size(56.dp),
                    color = Brand.Violet,
                    trackColor = MaterialTheme.colorScheme.outline,
                    strokeWidth = 4.dp,
                )
                Text(h.score.toString(), style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("${formatTime(h.startMs)} – ${formatTime(h.endMs)}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                StatusPill(h.category.label, Brand.Cyan)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton("Preview", onPreview, Modifier.weight(1f), icon = Icons.Rounded.PlayArrow)
            GradientButton("Generate clip", onGenerate, Modifier.weight(1f), icon = Icons.Rounded.ContentCut)
        }
        Spacer(Modifier.height(8.dp))
        FilterChip(
            selected = selected,
            onClick = onToggle,
            label = { Text(if (selected) "In montage" else "Add to montage") },
        )
    }
}
