package com.aiclip.hunter.data.clips

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.aiclip.hunter.domain.models.Clip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Exported clips live in the phone's gallery under Movies/AIClipHunter. The app can list, rename
 * and delete the files it created without any storage permission, and they survive app restarts.
 */
class ClipRepository(private val context: Context) {

    private val collection: Uri = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)

    suspend fun list(): List<Clip> = withContext(Dispatchers.IO) {
        val result = mutableListOf<Clip>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_ADDED,
        )
        context.contentResolver.query(
            collection,
            projection,
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
            arrayOf("$RELATIVE_PATH%"),
            "${MediaStore.Video.Media.DATE_ADDED} DESC",
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val dateCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                result += Clip(
                    id = id.toString(),
                    title = c.getString(nameCol).substringBeforeLast('.'),
                    uri = ContentUris.withAppendedId(collection, id).toString(),
                    durationMs = c.getLong(durCol),
                    createdAtMs = c.getLong(dateCol) * 1000L,
                )
            }
        }
        result
    }

    suspend fun save(file: File, title: String, durationMs: Long): Clip = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "$title.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, RELATIVE_PATH)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: error("Couldn't create the file in your gallery.")
        try {
            resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                ?: error("Couldn't write the clip.")
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        Clip(ContentUris.parseId(uri).toString(), title, uri.toString(), durationMs, System.currentTimeMillis())
    }

    suspend fun rename(clip: Clip, title: String) = withContext(Dispatchers.IO) {
        val values = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, "$title.mp4") }
        context.contentResolver.update(Uri.parse(clip.uri), values, null, null)
    }

    suspend fun delete(clip: Clip) = withContext(Dispatchers.IO) {
        context.contentResolver.delete(Uri.parse(clip.uri), null, null)
    }

    private companion object {
        const val RELATIVE_PATH = "Movies/AIClipHunter"
    }
}
