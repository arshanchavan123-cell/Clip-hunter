package com.aiclip.hunter.engine.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.sqrt

/**
 * Decodes the audio track in small buffers (never the whole file in memory) and measures
 * loudness (RMS, 0..1) for every second of the video.
 */
class AudioAnalyzer(private val context: Context) {

    /** Returns one loudness value per second, or null when the file has no audio track. */
    suspend fun analyze(uri: Uri, durationMs: Long, onProgress: (Float) -> Unit): FloatArray? =
        withContext(Dispatchers.Default) {
            val extractor = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                extractor.setDataSource(context, uri, null)
                val track = (0 until extractor.trackCount).firstOrNull { i ->
                    extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
                } ?: return@withContext null
                extractor.selectTrack(track)
                val format = extractor.getTrackFormat(track)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: return@withContext null

                val decoder = MediaCodec.createDecoderByType(mime)
                codec = decoder
                decoder.configure(format, null, null, 0)
                decoder.start()

                val seconds = ((durationMs + 999) / 1000).toInt().coerceAtLeast(1)
                val sumSq = DoubleArray(seconds)
                val counts = LongArray(seconds)
                var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)

                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false
                var idleRounds = 0
                var lastReportedSecond = -1

                while (!outputDone) {
                    ensureActive()
                    if (!inputDone) {
                        val inIdx = decoder.dequeueInputBuffer(10_000)
                        if (inIdx >= 0) {
                            val inBuf = decoder.getInputBuffer(inIdx)
                            val size = if (inBuf != null) extractor.readSampleData(inBuf, 0) else -1
                            if (size < 0) {
                                decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                decoder.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }

                    val outIdx = decoder.dequeueOutputBuffer(info, 10_000)
                    if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val newFormat = decoder.outputFormat
                        sampleRate = newFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = newFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    } else if (outIdx >= 0) {
                        idleRounds = 0
                        val out = decoder.getOutputBuffer(outIdx)
                        if (out != null && info.size > 0) {
                            out.position(info.offset)
                            out.limit(info.offset + info.size)
                            val pcm = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                            val frames = pcm.remaining() / channels
                            var frame = 0
                            while (frame < frames) {
                                val sec = ((info.presentationTimeUs + frame * 1_000_000L / sampleRate) / 1_000_000L)
                                    .toInt().coerceIn(0, seconds - 1)
                                val v = pcm.get(frame * channels) / 32768.0
                                sumSq[sec] += v * v
                                counts[sec]++
                                frame += 4 // sampling every 4th frame is plenty for loudness
                            }
                        }
                        decoder.releaseOutputBuffer(outIdx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                        val currentSecond = (info.presentationTimeUs / 1_000_000L).toInt()
                        if (currentSecond != lastReportedSecond) {
                            lastReportedSecond = currentSecond
                            onProgress((info.presentationTimeUs / 1000f / durationMs).coerceIn(0f, 1f))
                        }
                    } else if (inputDone) {
                        idleRounds++
                        if (idleRounds > 300) outputDone = true // decoder stopped producing output
                    }
                }

                FloatArray(seconds) { i -> if (counts[i] > 0) sqrt(sumSq[i] / counts[i]).toFloat() else 0f }
            } finally {
                runCatching { codec?.stop() }
                runCatching { codec?.release() }
                extractor.release()
            }
        }
}
