"""Generates ai_clip_hunter_logo.svg and .png from one set of coordinates (108-unit grid)."""
from pathlib import Path
from PIL import Image, ImageDraw

OUT = Path(__file__).parent
CYAN, VIOLET, BG = "#22D3EE", "#8B5CF6", "#090B12"
VB = (12, 12, 84)  # x, y, size of the square crop of the 108 grid

svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="{VB[0]} {VB[1]} {VB[2]} {VB[2]}" width="1024" height="1024">
  <title>AI Clip Hunter</title>
  <defs><linearGradient id="bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#111522"/><stop offset="1" stop-color="{BG}"/></linearGradient></defs>
  <rect x="12" y="12" width="84" height="84" rx="19" fill="url(#bg)"/>
  <g fill="none" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="54" cy="54" r="25" stroke="{CYAN}" stroke-width="3.5"/>
    <path d="M54 22V35M54 73V86M22 54H35M73 54H86" stroke="{CYAN}" stroke-width="3.5"/>
    <path d="M45 41V67L68 54Z" fill="{VIOLET}" stroke="{VIOLET}" stroke-width="3"/>
    <path d="M58 62L76 72M62 58L72 76" stroke="{BG}" stroke-width="6"/>
    <path d="M58 62L76 72M62 58L72 76" stroke="#FFFFFF" stroke-width="2.4"/>
    <circle cx="78.6" cy="73.5" r="3" stroke="#FFFFFF" stroke-width="2.2"/>
    <circle cx="73.5" cy="78.6" r="3" stroke="#FFFFFF" stroke-width="2.2"/>
  </g>
</svg>
'''
(OUT / "ai_clip_hunter_logo.svg").write_text(svg)

W = 2048  # draw at 2x, then downsample for smooth edges
k = W / VB[2]
def P(x, y): return ((x - VB[0]) * k, (y - VB[1]) * k)

grad = Image.linear_gradient("L").resize((W, W))
bg = Image.composite(Image.new("RGB", (W, W), (9, 11, 18)), Image.new("RGB", (W, W), (17, 21, 34)), grad).convert("RGBA")
mask = Image.new("L", (W, W), 0)
ImageDraw.Draw(mask).rounded_rectangle([0, 0, W - 1, W - 1], radius=19 * k, fill=255)

fg = Image.new("RGBA", (W, W), (0, 0, 0, 0))
d = ImageDraw.Draw(fg)

def line(a, b, w, fill):
    (x1, y1), (x2, y2) = P(*a), P(*b)
    d.line([(x1, y1), (x2, y2)], fill=fill, width=round(w * k))
    r = w * k / 2
    for x, y in ((x1, y1), (x2, y2)):
        d.ellipse([x - r, y - r, x + r, y + r], fill=fill)

def ring(c, r, w, fill):
    cx, cy = P(*c)
    d.ellipse([cx - r * k, cy - r * k, cx + r * k, cy + r * k], outline=fill, width=round(w * k))

ring((54, 54), 25, 3.5, CYAN)
for a, b in (((54, 22), (54, 35)), ((54, 73), (54, 86)), ((22, 54), (35, 54)), ((73, 54), (86, 54))):
    line(a, b, 3.5, CYAN)
tri = [(45, 41), (45, 67), (68, 54)]
d.polygon([P(*p) for p in tri], fill=VIOLET)
for i in range(3):
    line(tri[i], tri[(i + 1) % 3], 3, VIOLET)
blades = [((58, 62), (76, 72)), ((62, 58), (72, 76))]
for a, b in blades:            # transparent halo cuts the scissors out of the ring
    line(a, b, 6, (0, 0, 0, 0))
for a, b in blades:
    line(a, b, 2.4, "#FFFFFF")
ring((78.6, 73.5), 3, 2.2, "#FFFFFF")
ring((73.5, 78.6), 3, 2.2, "#FFFFFF")

out = Image.alpha_composite(bg, fg)
out.putalpha(mask)
out.resize((1024, 1024), Image.LANCZOS).save(OUT / "ai_clip_hunter_logo.png")
print("ok")
